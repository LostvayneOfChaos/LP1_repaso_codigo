/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Cola.hpp
 * Author: AXEL
 *
 * Created on 9 de noviembre de 2023, 05:25 PM
 */
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>
using namespace std;
#ifndef COLA_HPP
#define COLA_HPP

#include "Nodo.hpp"


class Cola {
public:
    Cola();
    Cola(const Cola& orig);
    virtual ~Cola();
    void leerPedidos(ifstream &);
    void encolar(class Nodo* &);
    void imprimirPedidos(ofstream &);
private:
    Nodo* cabeza;
    Nodo* fin;
    int totalPedidos;
    
};

#endif /* COLA_HPP */

