/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Nodo.hpp
 * Author: AXEL
 *
 * Created on 9 de noviembre de 2023, 05:25 PM
 */

#ifndef NODO_HPP
#define NODO_HPP
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>
using namespace std;
#include "Pedido.hpp"


class Nodo {
public:
    Nodo();
    Nodo(const Nodo& orig);
    virtual ~Nodo();
    friend class Cola;
private:
    Pedido datoPedido;
    Nodo* sig;
};

#endif /* NODO_HPP */

