/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Almacen.cpp
 * Author: AXEL
 * 
 * Created on 9 de noviembre de 2023, 05:24 PM
 */

#include "Almacen.hpp"

Almacen::Almacen() {
}

Almacen::Almacen(const Almacen& orig) {
}

Almacen::~Almacen() {
}

void Almacen::leerDatos(){
    ifstream inPedidos("Pedidos.csv",ios::in);
    if (!inPedidos) {
        cout<<"error al abrir el archivo";
        exit(1);
    }
    
    while (1) {
        cola.leerPedidos(inPedidos);
        if(inPedidos.eof()) break;
    }

    
    
    
    inPedidos.close();
}

void Almacen::imprimirDatos(){
    ofstream outPedidos("reporte.txt",ios::out);
    if (!outPedidos) {
        cout<<"error al abrir el archivo";
        exit(1);
    }
    
    cola.imprimirPedidos(outPedidos);

    
    
    
    
    outPedidos.close();
}