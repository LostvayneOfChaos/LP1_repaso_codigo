/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Pedido.hpp
 * Author: AXEL
 *
 * Created on 9 de noviembre de 2023, 05:25 PM
 */

#ifndef PEDIDO_HPP
#define PEDIDO_HPP
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>
using namespace std;
class Pedido {
public:
    Pedido();
    Pedido(const Pedido& orig);
    virtual ~Pedido();
    void SetCantidad(int cantidad);
    int GetCantidad() const;
    void SetDni(int dni);
    int GetDni() const;
    void SetFecha(int fecha);
    int GetFecha() const;
private:
    int fecha;
    int dni;
    int cantidad;
    
};

#endif /* PEDIDO_HPP */

