/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Cola.cpp
 * Author: AXEL
 * 
 * Created on 9 de noviembre de 2023, 05:25 PM
 */

#include "Cola.hpp"

Cola::Cola() {
    cabeza=nullptr;
    fin=nullptr;
    totalPedidos=0;
}

Cola::Cola(const Cola& orig) {
}

Cola::~Cola() {
}

void Cola::leerPedidos(ifstream &inPedidos){
    //aca lees primer caracter para ver que tipo es
    char cod[10];
    char aux;
    int dni,fecha,dia,mes,anio,cant;
    inPedidos.getline(cod,10,',');
    if (inPedidos.eof()) {
        return;
    }
    inPedidos>>dni>>aux>>cant>>aux>>dia>>aux>>mes>>aux>>anio;
    fecha=anio*10000+mes*100+dia;
    Nodo*nuevo=new class Nodo;
    nuevo->datoPedido.SetCantidad(cant);
    nuevo->datoPedido.SetDni(dni);
    nuevo->datoPedido.SetFecha(fecha);
    
    
    encolar(nuevo);
}

void Cola::encolar(class Nodo* &nodo){
    
    if(cabeza==nullptr){
        cabeza=nodo;
        fin=nodo;
        
    }
    else{
        fin->sig=nodo;
        fin=nodo;
        
    }
    
    totalPedidos+=1;
}


void Cola::imprimirPedidos(ofstream & out){
    
    Nodo* ptr= cabeza;
    while (ptr) {
        out<<setw(2)<<ptr->datoPedido.GetCantidad()
                <<setw(10)<<ptr->datoPedido.GetDni()
        <<setw(10)<<ptr->datoPedido.GetFecha()<<endl;
        
        ptr=ptr->sig;
        
    }

    
    
    
    
}