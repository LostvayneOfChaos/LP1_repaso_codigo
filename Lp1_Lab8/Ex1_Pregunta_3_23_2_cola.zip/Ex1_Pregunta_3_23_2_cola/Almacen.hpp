/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Almacen.hpp
 * Author: AXEL
 *
 * Created on 9 de noviembre de 2023, 05:24 PM
 */
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>
using namespace std;
#ifndef ALMACEN_HPP
#define ALMACEN_HPP
#include "Cola.hpp"

class Almacen {
public:
    Almacen();
    Almacen(const Almacen& orig);
    virtual ~Almacen();
    void leerDatos();
    void imprimirDatos();
private:
    class Cola cola;
};

#endif /* ALMACEN_HPP */

