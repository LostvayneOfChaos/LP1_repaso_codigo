/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   PedidoEspecial.cpp
 * Author: RODRIGO
 * 
 * Created on 5 de noviembre de 2023, 17:30
 */

#include "PedidoEspecial.h"

PedidoEspecial::PedidoEspecial() {
    this->descuento=0;
}

PedidoEspecial::PedidoEspecial(const PedidoEspecial& orig) {
}

PedidoEspecial::~PedidoEspecial() {
}

void PedidoEspecial::SetDescuento(double descuento) {
    this->descuento = descuento;
}

double PedidoEspecial::GetDescuento() const {
    return descuento;
}
void PedidoEspecial::lee(ifstream& archivo,int cod){
    archivo>>descuento;
    archivo.get();
    this->Pedido::lee(archivo,cod);
}
void PedidoEspecial::imprime(ofstream& archivo){
    archivo.fixed;
    archivo.precision(2);
    this->Pedido::imprime(archivo);
    archivo<<"Monto Total:"<<setw(5)<<" "<<this->Pedido::GetTotal()*
            this->Pedido::GetCantidad()*(1-this->descuento/100)<<endl;
    archivo<<"Descuento:"<<setw(10)<<this->descuento<<"%"<<endl;
}
void PedidoEspecial::actualiza(){
    
}