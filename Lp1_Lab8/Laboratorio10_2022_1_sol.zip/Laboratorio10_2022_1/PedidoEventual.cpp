/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   PedidoEventual.cpp
 * Author: RODRIGO
 * 
 * Created on 5 de noviembre de 2023, 17:34
 */

#include "PedidoEventual.h"

PedidoEventual::PedidoEventual() {
}

PedidoEventual::PedidoEventual(const PedidoEventual& orig) {
}

PedidoEventual::~PedidoEventual() {
}

void PedidoEventual::SetFlete(double flete) {
    this->flete = flete;
}

double PedidoEventual::GetFlete() const {
    return flete;
}
void PedidoEventual::lee(ifstream& archivo,int cod){
    archivo>>this->flete;
    archivo.get();
    this->Pedido::lee(archivo,cod);
}
void PedidoEventual::imprime(ofstream& archivo){
    archivo<<fixed;
    archivo.precision(2);
    this->Pedido::imprime(archivo);
    archivo<<"Monto Total:"<<setw(5)<<" "<<this->Pedido::GetTotal()*
            this->Pedido::GetCantidad()*(1+this->flete/100)<<endl;
    archivo<<"Flete:"<<setw(15)<<this->flete<<"%"<<endl;
    archivo<<endl;
}
void PedidoEventual::actualiza(){
    this->flete=0;
}