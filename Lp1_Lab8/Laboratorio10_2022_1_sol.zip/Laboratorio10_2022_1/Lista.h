/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Lista.h
 * Author: RODRIGO
 *
 * Created on 5 de noviembre de 2023, 17:35
 */

#ifndef LISTA_H
#define LISTA_H
#include"Nodo.h"
class Lista {
public:
    Lista();
    Lista(const Lista& orig);
    virtual ~Lista();
    void CargarPedidos(ifstream&archivo);
    void insertarNodo(Nodo*nuevoNodo);
    void imprimeDatosLista(ofstream&archivo);
    void actualizarPedido(int codigo,int fecha);
private:
    Nodo*lini;
    Nodo*lfin;
};

#endif /* LISTA_H */

