/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   PedidoUsual.cpp
 * Author: RODRIGO
 * 
 * Created on 5 de noviembre de 2023, 17:31
 */

#include "PedidoUsual.h"

PedidoUsual::PedidoUsual() {
}

PedidoUsual::PedidoUsual(const PedidoUsual& orig) {
}

PedidoUsual::~PedidoUsual() {
}

void PedidoUsual::SetFlete(double flete) {
    this->flete = flete;
}

double PedidoUsual::GetFlete() const {
    return flete;
}

void PedidoUsual::SetDescuento(double descuento) {
    this->descuento = descuento;
}

double PedidoUsual::GetDescuento() const {
    return descuento;
}
void PedidoUsual::lee(ifstream& archivo,int cod){
    archivo>>this->descuento;
    archivo.get();
    archivo>>this->flete;
    archivo.get();
    this->Pedido::lee(archivo,cod);
}
void PedidoUsual::imprime(ofstream& archivo){
    archivo<<fixed;
    archivo.precision(2);
    this->Pedido::imprime(archivo);
    archivo<<"Monto Total:  "<<this->Pedido::GetTotal()*this->Pedido::GetCantidad()*
            (1+this->flete/100)*(1-this->descuento/100)<<endl;
    archivo<<"Descuento:"<<setw(10)<<this->descuento<<"%"<<endl;
    archivo<<"Flete:"<<setw(15)<<this->flete<<"%"<<endl;
    archivo<<endl;
}

void PedidoUsual::actualiza(){
    this->flete=0;
                              }