/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Pedido.cpp
 * Author: RODRIGO
 * 
 * Created on 5 de noviembre de 2023, 17:27
 */

#include "Pedido.h"

Pedido::Pedido() {
    this->cantidad=0;
    this->codigo=0;
    this->dni=0;
    this->nombre=nullptr;
    this->total=0;
}

Pedido::Pedido(const Pedido& orig) {
}

Pedido::~Pedido() {
    if(this->nombre!=nullptr)delete this->nombre;
}

void Pedido::SetTotal(double total) {
    this->total = total;
}

double Pedido::GetTotal() const {
    return total;
}

void Pedido::SetFecha(int fecha) {
    this->fecha = fecha;
}

int Pedido::GetFecha() const {
    return fecha;
}

void Pedido::SetDni(int dni) {
    this->dni = dni;
}

int Pedido::GetDni() const {
    return dni;
}

void Pedido::SetCantidad(int cantidad) {
    this->cantidad = cantidad;
}

int Pedido::GetCantidad() const {
    return cantidad;
}

void Pedido::SetNombre(char*cadena) {
    if(this->nombre!=nullptr)delete this->nombre;
    this->nombre=new char[strlen(cadena)+1];
    strcpy(this->nombre,cadena);
}

void Pedido::GetNombre(char*cadena) const {
    if(this->nombre==nullptr)cadena[0]=0;
    else strcpy(cadena,this->nombre);
}

void Pedido::SetCodigo(int codigo) {
    this->codigo = codigo;
}

int Pedido::GetCodigo() const {
    return codigo;
}
void Pedido::lee(ifstream& archivo,int cod){
    char cadena[100];
    archivo.getline(cadena,100,',');
    archivo>>this->cantidad;
    archivo.get();
    archivo>>this->total;
    archivo.get();
    archivo>>this->dni;
    archivo.get();
    int dd,mm,aa;
    char car;
    archivo>>dd>>car>>mm>>car>>aa;
    archivo.get();
    this->fecha=dd+mm*100+aa*10000;
    this->SetNombre(cadena);
    this->SetCodigo(cod);
}
void Pedido::imprime(ofstream& archivo){
    int dd,mm,aa;
    this->obtenerFecha(dd,mm,aa);
    archivo<<dd<<"/"<<mm<<"/"<<aa<<endl;
    archivo<<this->codigo<<setw(5)<<" "<<
            this->nombre<<endl;
    archivo<<"DNI:"<<setw(20)<<this->dni<<endl;
}
void Pedido::obtenerFecha(int& dd, int& mm, int& aa){
    dd=this->fecha%100;
    aa=this->fecha/10000;
    mm=(this->fecha-10000*aa)/100;
}