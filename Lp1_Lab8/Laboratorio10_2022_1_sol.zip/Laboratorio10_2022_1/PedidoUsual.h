/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   PedidoUsual.h
 * Author: RODRIGO
 *
 * Created on 5 de noviembre de 2023, 17:31
 */

#ifndef PEDIDOUSUAL_H
#define PEDIDOUSUAL_H

#include "Pedido.h"
class PedidoUsual:public Pedido {
public:
    PedidoUsual();
    PedidoUsual(const PedidoUsual& orig);
    virtual ~PedidoUsual();
    void SetFlete(double flete);
    double GetFlete() const;
    void SetDescuento(double descuento);
    double GetDescuento() const;
    void lee(ifstream&archivo,int cod);
    void imprime(ofstream&archivo);
    void actualiza();
private:
    double descuento;
    double flete;
};

#endif /* PEDIDOUSUAL_H */

