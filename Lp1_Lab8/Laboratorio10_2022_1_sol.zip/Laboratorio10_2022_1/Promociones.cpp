/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Promociones.cpp
 * Author: RODRIGO
 * 
 * Created on 5 de noviembre de 2023, 17:37
 */

#include "Promociones.h"

Promociones::Promociones() {
}

Promociones::Promociones(const Promociones& orig) {
}

Promociones::~Promociones() {
}
void Promociones::leepedidos(){
    ifstream archivo("pedidos5.csv",ios::in);
    if(not archivo.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo para lectura."<<endl;
        exit(1);
    }
    while(true){
        this->Lpedidos.CargarPedidos(archivo);
        if(archivo.eof())break;
    }
}
void Promociones::imprimepedidos(){
    ofstream archivo("Reporte.txt",ios::out);
    if(not archivo.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo para escritura"<<endl;
        exit(1);
    }
    this->Lpedidos.imprimeDatosLista(archivo);
}
void Promociones::actualizarpedidos(){
    ifstream archivo("Promocion.csv",ios::in);
    if(not archivo.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo para lectura."<<endl;
        exit(1);
    }
    int codigo,dd,mm,aa,fecha;
    char car;
    while(true){
        archivo>>codigo;
        if(archivo.eof())break;
        archivo.get();
        archivo>>dd>>car>>mm>>car>>aa;
        archivo.get();
        fecha=dd+mm*100+aa*10000;
        this->Lpedidos.actualizarPedido(codigo,fecha);
    }
}