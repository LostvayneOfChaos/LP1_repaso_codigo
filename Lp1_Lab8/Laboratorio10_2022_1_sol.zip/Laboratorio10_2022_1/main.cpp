/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: RODRIGO
 *
 * Created on 5 de noviembre de 2023, 17:26
 */

#include "Promociones.h"

/*
 * 
 */
int main(int argc, char** argv) {
    Promociones pro;
    pro.leepedidos();
    pro.actualizarpedidos();
    pro.imprimepedidos();
    return 0;
}

