/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Lista.cpp
 * Author: RODRIGO
 * 
 * Created on 5 de noviembre de 2023, 17:35
 */

#include "Lista.h"
#include "PedidoEspecial.h"
#include "PedidoUsual.h"
#include "PedidoEventual.h"

Lista::Lista() {
    this->lfin=nullptr;
    this->lini=nullptr;
}

Lista::Lista(const Lista& orig) {
}

Lista::~Lista() {
}
void Lista::CargarPedidos(ifstream& archivo){
    int codigo;
    archivo>>codigo;
    if(archivo.eof())return;;
    archivo.get();
    Nodo*nuevoNodo=new Nodo;
    if(codigo<400000)
        nuevoNodo->ped=new PedidoEspecial;
    else if(codigo>=400000 && codigo<=600000)
        nuevoNodo->ped=new PedidoUsual;
    else nuevoNodo->ped=new PedidoEventual;
    nuevoNodo->ped->lee(archivo,codigo);
    insertarNodo(nuevoNodo);
}
void Lista::insertarNodo(Nodo*nuevoNodo){
    if(this->lini==nullptr){
        this->lini=nuevoNodo;
        this->lfin=nuevoNodo;
    }
    else if(this->lini->ped->GetDni()>=nuevoNodo->ped->GetDni()
            || (this->lini->ped->GetDni()==nuevoNodo->ped->GetDni()
            && this->lini->ped->GetFecha()>=nuevoNodo->ped->GetFecha())){
        nuevoNodo->sig=this->lini;
        this->lini->ant=nuevoNodo;
        this->lini=nuevoNodo;
    } 
    else if(this->lfin->ped->GetDni()<=nuevoNodo->ped->GetDni()
            || (this->lfin->ped->GetDni()==nuevoNodo->ped->GetDni()
            && this->lfin->ped->GetFecha()<=nuevoNodo->ped->GetFecha())){
        nuevoNodo->ant=this->lfin;
        this->lfin->sig=nuevoNodo;
        this->lfin=nuevoNodo;
    }
    else{
        Nodo*actual=this->lini;
        while (actual->sig!=nullptr and
                (actual->sig->ped->GetDni()<nuevoNodo->ped->GetDni()
                || (actual->sig->ped->GetDni()==nuevoNodo->ped->GetDni()
                && actual->sig->ped->GetFecha()<nuevoNodo->ped->GetFecha())))
            actual=actual->sig;
        nuevoNodo->sig=actual->sig;
        nuevoNodo->ant=actual;
        actual->sig->ant=nuevoNodo;
        actual->sig=nuevoNodo;
    }
    
}

void Lista::imprimeDatosLista(ofstream& archivo){
    Nodo*cabeza=this->lini;
    while(cabeza!=nullptr){
        cabeza->ped->imprime(archivo);
        cabeza=cabeza->sig;
    }
}
void Lista::actualizarPedido(int codigo, int fecha){
    Nodo*ultimo=this->lfin;
    while(ultimo){
        if(ultimo->ped->GetDni()==codigo && ultimo->ped->GetFecha()==fecha){
            ultimo->ped->actualiza();
        }
        ultimo=ultimo->ant;
    }
}