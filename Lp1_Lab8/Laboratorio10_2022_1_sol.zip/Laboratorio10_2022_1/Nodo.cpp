/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Nodo.cpp
 * Author: RODRIGO
 * 
 * Created on 5 de noviembre de 2023, 17:34
 */

#include "Nodo.h"

Nodo::Nodo() {
    this->ped=nullptr;
    this->sig=nullptr;
    this->ant=nullptr;
}

Nodo::Nodo(const Nodo& orig) {
}

Nodo::~Nodo() {
}

