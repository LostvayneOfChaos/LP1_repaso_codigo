/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Promociones.h
 * Author: RODRIGO
 *
 * Created on 5 de noviembre de 2023, 17:37
 */

#ifndef PROMOCIONES_H
#define PROMOCIONES_H

#include "Lista.h"

class Promociones {
public:
    Promociones();
    Promociones(const Promociones& orig);
    virtual ~Promociones();
    void leepedidos();
    void imprimepedidos();
    void actualizarpedidos();
private:
    Lista Lpedidos;
};

#endif /* PROMOCIONES_H */

