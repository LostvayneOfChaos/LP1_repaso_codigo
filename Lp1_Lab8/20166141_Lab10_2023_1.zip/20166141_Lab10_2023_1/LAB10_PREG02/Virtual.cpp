/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Virtual.cpp
 * Author: AXEL
 * 
 * Created on 7 de noviembre de 2023, 11:26 AM
 */

#include "Virtual.hpp"

Virtual::Virtual() {
    licencia=nullptr;
}

Virtual::Virtual(const Virtual& orig) {
}

Virtual::~Virtual() {
}

void Virtual::SetTotal(double total) {
    this->total = total;
}

double Virtual::GetTotal() const {
    return total;
}

void Virtual::SetLicencia(char* licencia) {
    if(this->licencia !=nullptr) delete this->licencia;
    this->licencia = new char[strlen(licencia)+1];
    strcpy(this->licencia,licencia);
}

void Virtual::GetLicencia(char* cadena) const {
    if(licencia ==  nullptr) cadena[0]=0;
    strcpy(cadena,licencia);
    
}

void Virtual::leer(ifstream & in ){
    Alumno::leer(in);
    char LICENCIA[50];
    in.getline(LICENCIA,50,'\n');
    SetLicencia(LICENCIA);
    SetTotal(0);
}
void Virtual::imprime(ofstream &out){
    Alumno::imprime(out);
    char LICENCIA[50];
    GetLicencia(LICENCIA);
    out<<setw(12)<<LICENCIA<<setw(10)<<GetTotal()<<endl;
    
}

void Virtual::actualiza(class Escala*lescala){
     
     Alumno::actualiza(lescala);
    double monto;
    monto=Alumno::GetTotal();
    if(licencia !=nullptr){
        SetTotal(100+monto);
        Alumno::SetTotal(100+monto);
        
    }
    else{
        SetTotal(monto);
        Alumno::SetTotal(monto);
    }
    
     
     
 }