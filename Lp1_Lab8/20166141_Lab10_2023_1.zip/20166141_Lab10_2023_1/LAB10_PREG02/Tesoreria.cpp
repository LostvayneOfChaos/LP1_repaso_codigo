/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Tesoreria.cpp
 * Author: AXEL
 * 
 * Created on 7 de noviembre de 2023, 11:27 AM
 */

#include "Tesoreria.hpp"

Tesoreria::Tesoreria() {
}

Tesoreria::Tesoreria(const Tesoreria& orig) {
}

Tesoreria::~Tesoreria() {
}


void Tesoreria::cargaalumnos(){
    
    ifstream inAlumnos("alumnos.csv",ios::in);
    if (!inAlumnos) {
        cout<<"error al abrir el archivo";
        exit(1);
    }
    
    
    while (1) {
        this->aboleta.leerDatos(inAlumnos);
        if(inAlumnos.eof()) break;
    }
    inAlumnos.close();
}


void Tesoreria::imprimeboleta(){
    
    ofstream outAlumnos("reporteAlumnos.txt",ios::out);
    if (!outAlumnos) {
        cout<<"error al abrir el archivo";
        exit(1);
    }
    
    aboleta.en_orden(outAlumnos);
    
    
    outAlumnos.close();
}


void Tesoreria::actualizaboleta(){
    ifstream inEscalas("escalas.csv",ios::in);
    if (!inEscalas) {
        cout<<"error al abrir el archivo";
        exit(1);
    }
    aboleta.actualizarEscalas(inEscalas);
    
    
    
    
    
    
    inEscalas.close();
}