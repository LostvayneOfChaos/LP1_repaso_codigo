/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Escala.cpp
 * Author: AXEL
 * 
 * Created on 7 de noviembre de 2023, 11:26 AM
 */

#include "Escala.hpp"

Escala::Escala() {
}

Escala::Escala(const Escala& orig) {
}

Escala::~Escala() {
}

void Escala::SetPrecio(double precio) {
    this->precio = precio;
}

double Escala::GetPrecio() const {
    return precio;
}

void Escala::SetCodigo(int codigo) {
    this->codigo = codigo;
}

int Escala::GetCodigo() const {
    return codigo;
}

void operator >>(ifstream & in,
        class Escala & ESCALA){
    
    int valor;
    char aux;
    double costo;
    in>>valor;
    if(in.eof()) return;
    in>>aux>>costo;
    in.get();
    
    ESCALA.SetCodigo(valor);
    ESCALA.SetPrecio(costo);
    
    
    
}