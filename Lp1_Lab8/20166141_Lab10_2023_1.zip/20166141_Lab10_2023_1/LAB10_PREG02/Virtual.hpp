/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Virtual.hpp
 * Author: AXEL
 *
 * Created on 7 de noviembre de 2023, 11:26 AM
 */
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>
using namespace std;
#ifndef VIRTUAL_HPP
#define VIRTUAL_HPP
#include "Alumno.hpp"
class Virtual : public Alumno{
public:
    Virtual();
    Virtual(const Virtual& orig);
    virtual ~Virtual();
    void SetTotal(double total);
    double GetTotal() const;
    void SetLicencia(char* licencia);
    void GetLicencia(char* cadena) const;
    void leer(ifstream &);
     void imprime(ofstream &);
     void actualiza(class Escala*lescala);
private:
    char* licencia;
    double total;
    
};

#endif /* VIRTUAL_HPP */

