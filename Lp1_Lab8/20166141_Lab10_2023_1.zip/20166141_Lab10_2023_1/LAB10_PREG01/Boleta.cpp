/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Boleta.cpp
 * Author: AXEL
 * 
 * Created on 7 de noviembre de 2023, 11:26 AM
 */
#include "Presencial.hpp"
#include "Semipresencial.hpp"
#include "Virtual.hpp"
#include "Boleta.hpp"

Boleta::Boleta() {
}

Boleta::Boleta(const Boleta& orig) {
}

Boleta::~Boleta() {
}

void Boleta::asignar(char tipo){
    if (tipo=='P') {
        pboleta=new class Presencial;
    } 
    else if (tipo=='V') {
        pboleta=new class Virtual;
    }
    else if (tipo=='S') {
        pboleta=new class Semipresencial;
    }
    
}
void Boleta::leer(ifstream & inAlumnos){
    
    pboleta->leer(inAlumnos);
    
    
}
void Boleta::imprimir(ofstream & out){
    
    
    pboleta->imprime(out);
    
    
}
bool  Boleta::operator >(const class Boleta & bolet){
    
    char nombre1[50];
    char nombre2[50];
    pboleta->GetNombre(nombre1);
    bolet.pboleta->GetNombre(nombre2);
    
    return strcmp(nombre1,nombre2)>0;
    
}