/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Nodo.cpp
 * Author: AXEL
 * 
 * Created on 7 de noviembre de 2023, 11:26 AM
 */

#include "Nodo.hpp"

Nodo::Nodo() {
}

Nodo::Nodo(const Nodo& orig) {
}

Nodo::~Nodo() {
}

