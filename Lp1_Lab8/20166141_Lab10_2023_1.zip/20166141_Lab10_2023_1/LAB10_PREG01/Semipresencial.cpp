/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Semipresencial.cpp
 * Author: AXEL
 * 
 * Created on 7 de noviembre de 2023, 11:26 AM
 */

#include "Semipresencial.hpp"

Semipresencial::Semipresencial() {
    
}

Semipresencial::Semipresencial(const Semipresencial& orig) {
}

Semipresencial::~Semipresencial() {
}

void Semipresencial::SetTotal(double total) {
    this->total = total;
}

double Semipresencial::GetTotal() const {
    return total;
}

void Semipresencial::SetDescuento(double descuento) {
    this->descuento = descuento;
}

double Semipresencial::GetDescuento() const {
    return descuento;
}
void Semipresencial::leer(ifstream & in ){
    Alumno::leer(in);
    in>>descuento;
    in.get();
    SetDescuento(descuento);
    SetTotal(0);
    
    
}
void Semipresencial::imprime(ofstream &out){
    Alumno::imprime(out);
    out<<setw(21)<<Alumno::GetTotal()<<endl;
}

