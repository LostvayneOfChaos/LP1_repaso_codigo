/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Tesoreria.hpp
 * Author: AXEL
 *
 * Created on 7 de noviembre de 2023, 11:27 AM
 */
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>
using namespace std;
#ifndef TESORERIA_HPP
#define TESORERIA_HPP
#include "Arbol.hpp"
class Tesoreria {
public:
    Tesoreria();
    Tesoreria(const Tesoreria& orig);
    virtual ~Tesoreria();
    void cargaalumnos();
    void imprimeboleta();
private:
    class Arbol aboleta;
    
};

#endif /* TESORERIA_HPP */

