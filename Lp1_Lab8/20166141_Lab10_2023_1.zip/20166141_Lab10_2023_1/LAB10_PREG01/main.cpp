/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: AXEL
 *
 * Created on 7 de noviembre de 2023, 11:24 AM
 */
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>
using namespace std;
#include "Tesoreria.hpp"
using namespace std;
int main(int argc, char** argv) {
    
    Tesoreria ABoleta;
    ABoleta.cargaalumnos();
    //ABoleta.actualizaboleta();
    //ABoleta.imprimeboleta();
    
    return 0;
}
