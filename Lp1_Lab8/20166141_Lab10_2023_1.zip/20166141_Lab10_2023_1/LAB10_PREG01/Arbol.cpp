/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Arbol.cpp
 * Author: AXEL
 * 
 * Created on 7 de noviembre de 2023, 11:26 AM
 */

#include "Arbol.hpp"

Arbol::Arbol() {
    raiz=nullptr;
}

Arbol::Arbol(const Arbol& orig) {
}

Arbol::~Arbol() {
}


void Arbol::leerDatos(ifstream& inAlumnos){
    //aca lees e insertas en el arbol
    
    char tipo;
    char aux;
    tipo=inAlumnos.get();
    if(inAlumnos.eof()) return;
    inAlumnos>>aux;
    class Nodo* nuevo=new class Nodo;
    nuevo->dboleta.asignar(tipo);
    nuevo->dboleta.leer(inAlumnos);
    insertarElemento(nuevo);//aca modificas el izq y el der
}
void Arbol::insertarElemento( class Nodo* nuevo){
    insertarElementoRecursivo(this->raiz,nuevo);
}

void Arbol::insertarElementoRecursivo(class Nodo* &raiz, class Nodo* nuevo){
    
    
    if(raiz==nullptr ){
        raiz=nuevo;
        nuevo->izq=nullptr;
        nuevo->der=nullptr;
        return;
    }
    
    //class Boleta bol=nuevo->dboleta;
    
    if((raiz->dboleta)>(nuevo->dboleta))
        insertarElementoRecursivo(raiz->izq,nuevo);
    else
        insertarElementoRecursivo(raiz->der,nuevo);
    
}

void Arbol::en_orden(ofstream & out ){
    
    out<<"Codigo"<<setw(27)<<"Nombre"<<setw(34)<<"Escala"<<
            setw(10)<<"Cred."<<setw(10)<<"Licencia"<<setw(10)<<"Total"<<endl;
    out<<"==============================================================="<<endl;
    en_orden_recursivo(out,raiz);
    out<<endl;
}


void Arbol::en_orden_recursivo(ofstream &out,class Nodo* &raiz){
    
    if(raiz){
        en_orden_recursivo(out,raiz->izq);
        raiz->dboleta.imprimir(out);
        en_orden_recursivo(out,raiz->der);
        
    }
    
}