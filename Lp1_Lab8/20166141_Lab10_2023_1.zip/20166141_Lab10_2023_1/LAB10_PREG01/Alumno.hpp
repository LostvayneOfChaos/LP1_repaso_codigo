/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Alumno.hpp
 * Author: AXEL
 *
 * Created on 7 de noviembre de 2023, 11:26 AM
 */
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>
using namespace std;
#ifndef ALUMNO_HPP
#define ALUMNO_HPP

class Alumno {
public:
    Alumno();
    Alumno(const Alumno& orig);
    virtual ~Alumno();
    void SetTotal(double total);
    double GetTotal() const;
    void SetCreditos(double creditos);
    double GetCreditos() const;
    void SetEscala(int escala);
    int GetEscala() const;
    void SetNombre(char* nombre);
    void GetNombre(char* cadena) const;
    void SetCodigo(int codigo);
    int GetCodigo() const;
private:
    int codigo;
    char* nombre;
    int escala;
    double creditos;
    double total;
    
};

#endif /* ALUMNO_HPP */

