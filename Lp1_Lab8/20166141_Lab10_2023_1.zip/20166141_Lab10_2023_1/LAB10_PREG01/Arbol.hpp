/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Arbol.hpp
 * Author: AXEL
 *
 * Created on 7 de noviembre de 2023, 11:26 AM
 */
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>
using namespace std;
#ifndef ARBOL_HPP
#define ARBOL_HPP
#include "Nodo.hpp"
#include "Escala.hpp"
class Arbol {
public:
    Arbol();
    Arbol(const Arbol& orig);
    virtual ~Arbol();
private:
    class Nodo* raiz;
    class Escala lescala[100];
    
};

#endif /* ARBOL_HPP */

