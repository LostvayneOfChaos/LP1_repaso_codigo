/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Semipresencial.hpp
 * Author: AXEL
 *
 * Created on 7 de noviembre de 2023, 11:26 AM
 */
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>
using namespace std;
#ifndef SEMIPRESENCIAL_HPP
#define SEMIPRESENCIAL_HPP
#include "Alumno.hpp"
class Semipresencial : public Alumno{
public:
    Semipresencial();
    Semipresencial(const Semipresencial& orig);
    virtual ~Semipresencial();
    void SetTotal(double total);
    double GetTotal() const;
    void SetDescuento(double descuento);
    double GetDescuento() const;
private:
    double descuento;
    double total;
    
    
};

#endif /* SEMIPRESENCIAL_HPP */

