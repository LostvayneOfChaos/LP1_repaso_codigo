/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Arbol.h
 * Author: RODRIGO
 *
 * Created on 4 de noviembre de 2023, 13:24
 */

#ifndef ARBOL_H
#define ARBOL_H

#include "Nodo.h"
class Arbol {
public:
    Arbol();
    Arbol(const Arbol& orig);
    virtual ~Arbol();
    void CargarDatos(ifstream&archivo);
    Nodo* CrearNodo(ifstream&archivo,int tipo);
    void insertarNodo(Nodo*nodo);
    void imprimeArbol(ofstream&archivo);
    void actualizar(ifstream&archivo);
    Nodo*buscarNodo(Nodo*raiz,int codigo);
private:
    Nodo*raiz;
    void insertarNodoRecursivo(Nodo*&cabeza,class Nodo*nodo);
    void imprimeArbolRecursivo(Nodo*cabeza,ofstream&archivo);
};

#endif /* ARBOL_H */

