/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Nodo.h
 * Author: RODRIGO
 *
 * Created on 4 de noviembre de 2023, 13:23
 */

#ifndef NODO_H
#define NODO_H

#include "Medicamento.h"
class Nodo {
public:
    Nodo();
    Nodo(const Nodo& orig);
    virtual ~Nodo();
    friend class Arbol;
private:
    Medicamento *med;
    Nodo*izq;
    Nodo*der;
};

#endif /* NODO_H */

