/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Medicamento.cpp
 * Author: RODRIGO
 * 
 * Created on 4 de noviembre de 2023, 13:23
 */

#include "Medicamento.h"

Medicamento::Medicamento() {
    this->codigo=0;
    this->nombre=nullptr;
    this->precio=0;
    this->stock=0;
}

Medicamento::Medicamento(const Medicamento& orig) {

}

Medicamento::~Medicamento() {
    if(this->nombre!=nullptr)delete this->nombre;
}
void Medicamento::lee(ifstream&archivo){
    char cadena[100];
    archivo>>this->codigo;
    archivo.get();
    archivo.getline(cadena,100,',');
    this->setNombre(cadena);
    archivo>>this->stock;
    archivo.get();
    archivo>>this->precio;
    archivo.get();
}
void Medicamento::imprime(ofstream&archivo){
    archivo<<this->codigo<<setw(4)<<" "<<
            this->nombre<<setw(50-strlen(this->nombre))
            <<this->stock<<setw(7)<<this->precio;
    
}

void Medicamento::setPrecio(double precio) {
    this->precio = precio;
}

double Medicamento::getPrecio() const {
    return precio;
}

void Medicamento::setStock(int stock) {
    this->stock = stock;
}

int Medicamento::getStock() const {
    return stock;
}

void Medicamento::setNombre(char*cadena) {
    if(this->nombre!=nullptr)delete this->nombre;
    this->nombre=new char[strlen(cadena)+1];
    strcpy(this->nombre,cadena);
}

void Medicamento::getNombre(char*cadena) const {
    if(this->nombre==nullptr)cadena[0]=0;
    strcpy(cadena,this->nombre);
}

void Medicamento::setCodigo(int codigo) {
    this->codigo = codigo;
}

int Medicamento::getCodigo() const {
    return codigo;
}