/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Arbol.cpp
 * Author: RODRIGO
 * 
 * Created on 4 de noviembre de 2023, 13:24
 */

#include "Arbol.h"
#include "Generico.h"
#include "Marca.h"

Arbol::Arbol() {
    this->raiz=nullptr;
}

Arbol::Arbol(const Arbol& orig) {
}

Arbol::~Arbol() {
    
}
void Arbol::CargarDatos(ifstream&archivo){
    int tipo;
    archivo>>tipo;
    if(archivo.eof())return;
    archivo.get();
    Nodo*nodo=CrearNodo(archivo,tipo);
    insertarNodo(nodo);
}
void Arbol::insertarNodo(Nodo*nodo){
    insertarNodoRecursivo(this->raiz,nodo);
}
void Arbol::insertarNodoRecursivo(Nodo*&cabeza,Nodo*nodo){
    if(cabeza==nullptr){
        cabeza=nodo;
        return;
    }
    if(cabeza->med->getCodigo()>nodo->med->getCodigo()){
        insertarNodoRecursivo(cabeza->izq,nodo);
    }else{
        insertarNodoRecursivo(cabeza->der,nodo); 
    }
}
Nodo*Arbol::CrearNodo(ifstream&archivo,int tipo){
    Nodo*nuevoNodo=new Nodo;
    if(tipo==0)
        nuevoNodo->med=new Generico;
    else 
        nuevoNodo->med=new Marca;
    nuevoNodo->med->lee(archivo);
    return nuevoNodo;
}
void Arbol::imprimeArbol(ofstream&archivo){
    imprimeArbolRecursivo(this->raiz,archivo);
}
void Arbol::imprimeArbolRecursivo(Nodo* cabeza, ofstream& archivo){
    if(cabeza==nullptr)return;
    imprimeArbolRecursivo(cabeza->izq,archivo);
    cabeza->med->imprime(archivo);
    cout<<cabeza->med->getCodigo()<<endl;
    imprimeArbolRecursivo(cabeza->der,archivo);
}
void Arbol::actualizar(ifstream& archivo){
    int codigo;
    archivo>>codigo;
    Nodo*buscar=buscarNodo(this->raiz,codigo);
    buscar->med->setPrecio(buscar->med->getPrecio()*1.2);
}
Nodo* Arbol::buscarNodo(Nodo*raiz,int codigo){
    if(raiz->med->getCodigo()==codigo)return raiz;
    if(raiz->med->getCodigo()>codigo)return buscarNodo(raiz->izq,codigo);
    else return buscarNodo(raiz->der,codigo);
    
}