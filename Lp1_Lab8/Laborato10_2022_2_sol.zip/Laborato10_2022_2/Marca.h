/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Marca.h
 * Author: RODRIGO
 *
 * Created on 4 de noviembre de 2023, 13:23
 */

#ifndef MARCA_H
#define MARCA_H

#include "Medicamento.h"

class Marca:public Medicamento {
public:
    Marca();
    Marca(const Marca& orig);
    virtual ~Marca();
    void SetLaboratorio(char*cadena);
    void GetLaboratorio(char*cadena) const;
    void SetLote(int lote);
    int GetLote() const;
    void lee(ifstream&archivo);
    void imprime(ofstream&archivo);
private:
    int lote;
    char*laboratorio;
};

#endif /* MARCA_H */

