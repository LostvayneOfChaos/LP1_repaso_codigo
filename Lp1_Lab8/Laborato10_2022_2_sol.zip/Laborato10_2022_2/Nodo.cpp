/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Nodo.cpp
 * Author: RODRIGO
 * 
 * Created on 4 de noviembre de 2023, 13:23
 */

#include "Nodo.h"

Nodo::Nodo() {
    this->der=nullptr;
    this->izq=nullptr;
    this->med=nullptr;
}

Nodo::Nodo(const Nodo& orig) {
}

Nodo::~Nodo() {
}

