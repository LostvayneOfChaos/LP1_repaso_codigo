/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Almacen.cpp
 * Author: RODRIGO
 * 
 * Created on 4 de noviembre de 2023, 13:24
 */

#include "Almacen.h"

Almacen::Almacen() {
}

Almacen::Almacen(const Almacen& orig) {
}

Almacen::~Almacen() {
}
void Almacen::carga(){
    ifstream archivo("medicamentos.csv",ios::in);
    if(not archivo.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo para lectura"<<endl;
        exit(1);
    }
    while(true){
        this->cargarDatos(archivo);
        if(archivo.eof())break;
    }
}
void Almacen::cargarDatos(ifstream&archivo){
    this->arbolalma.CargarDatos(archivo);
}
void Almacen::imprime(){
    ofstream archivo("Reporte.txt",ios::out);
    if(not archivo.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo para escritura."<<endl;
        exit(1);
    }
    this->arbolalma.imprimeArbol(archivo);
}
void Almacen::actualiza(){
    ifstream archivo("recarga.csv",ios::in);
    if(not archivo.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo para lectura."<<endl;
        exit(1);
    }
    while(true){
        this->arbolalma.actualizar(archivo);
        if(archivo.eof())break;
    }
}