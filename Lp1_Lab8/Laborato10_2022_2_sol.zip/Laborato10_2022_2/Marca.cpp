/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Marca.cpp
 * Author: RODRIGO
 * 
 * Created on 4 de noviembre de 2023, 13:23
 */

#include "Marca.h"

Marca::Marca() {
    this->laboratorio=nullptr;
}

Marca::Marca(const Marca& orig) {
}

Marca::~Marca() {
    if(this->laboratorio!=nullptr)delete this->laboratorio;
}

void Marca::SetLaboratorio(char* cadena) {
    if(this->laboratorio!=nullptr)delete this->laboratorio;
    this->laboratorio=new char[strlen(cadena)+1];
    strcpy(this->laboratorio,cadena);
}

void Marca::GetLaboratorio(char*cadena) const {
    if(this->laboratorio==nullptr)cadena[0]=0;
    strcpy(cadena,this->laboratorio);
}

void Marca::SetLote(int lote) {
    this->lote = lote;
}

int Marca::GetLote() const {
    return lote;
}
void Marca::lee(ifstream& archivo){
    char cadena[100];
    this->Medicamento::lee(archivo);
    archivo.getline(cadena,100,',');
    archivo>>this->lote;
    archivo.get();
    this->SetLaboratorio(cadena);
}
void Marca::imprime(ofstream& archivo){
    this->Medicamento::imprime(archivo);
    archivo<<setw(2)<<" "<<this->laboratorio<<
            setw(20-strlen(this->laboratorio))<<" "<<
            this->lote<<endl;
}

