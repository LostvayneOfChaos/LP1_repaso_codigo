/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Medicamento.h
 * Author: RODRIGO
 *
 * Created on 4 de noviembre de 2023, 13:23
 */

#ifndef MEDICAMENTO_H
#define MEDICAMENTO_H
#include<iostream>
#include<iomanip>
#include<fstream>
#include<cstring>
using namespace std;
class Medicamento {
public:
    Medicamento();
    Medicamento(const Medicamento& orig);
    virtual ~Medicamento();
    virtual void lee(ifstream&archivo);
    virtual void imprime(ofstream&archivo);
    void setPrecio(double precio);
    double getPrecio() const;
    void setStock(int stock);
    int getStock() const;
    void setNombre(char*cadena);
    void getNombre(char*cadena) const;
    void setCodigo(int codigo);
    int getCodigo() const;
private:
    int codigo;
    char*nombre;
    int stock;
    double precio;
    
};

#endif /* MEDICAMENTO_H */

