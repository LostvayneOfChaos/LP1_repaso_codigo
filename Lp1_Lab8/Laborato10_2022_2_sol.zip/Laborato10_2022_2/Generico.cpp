/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Generico.cpp
 * Author: RODRIGO
 * 
 * Created on 4 de noviembre de 2023, 13:23
 */

#include "Generico.h"

Generico::Generico() {
    this->pais=nullptr;
}

Generico::Generico(const Generico& orig) {

}

Generico::~Generico() {
    if(this->pais!=nullptr)delete this->pais;
}

void Generico::SetPais(char*cadena) {
    if(this->pais!=nullptr)delete this->pais;
    this->pais=new char[strlen(cadena)+1];
    strcpy(this->pais,cadena);
}

void Generico::GetPais(char*cadena) const {
    if(this->pais==nullptr)cadena[0]=0;
    strcpy(cadena,this->pais);
}
void Generico::lee(ifstream& archivo){
    this->Medicamento::lee(archivo);
    char cadena[100];
    archivo.getline(cadena,100,'\n');
    this->SetPais(cadena);
}
void Generico::imprime(ofstream& archivo){
    this->Medicamento::imprime(archivo);
    archivo<<setw(2)<<" "<<this->pais<<endl;
}
