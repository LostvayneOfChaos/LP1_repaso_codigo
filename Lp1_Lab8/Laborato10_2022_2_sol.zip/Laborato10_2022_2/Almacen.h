/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Almacen.h
 * Author: RODRIGO
 *
 * Created on 4 de noviembre de 2023, 13:24
 */

#ifndef ALMACEN_H
#define ALMACEN_H
#include"Arbol.h"
class Almacen {
public:
    Almacen();
    Almacen(const Almacen& orig);
    virtual ~Almacen();
    void carga();
    void imprime();
    void actualiza();
private:
    void cargarDatos(ifstream&archivo);
    Arbol arbolalma;
};

#endif /* ALMACEN_H */

