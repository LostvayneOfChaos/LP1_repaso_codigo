/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Pedido.hpp
 * Author: AXEL
 *
 * Created on 9 de noviembre de 2023, 02:12 PM
 */
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>

using namespace std;
#ifndef PEDIDO_HPP
#define PEDIDO_HPP

class Pedido {
public:
    Pedido();
    Pedido(const Pedido& orig);
    virtual ~Pedido();
    void SetPeso(double peso);
    double GetPeso() const;
    void SetCantidad(int cantidad);
    int GetCantidad() const;
    void SetDni(int dni);
    int GetDni() const;
    void SetCodigo(char* codigo);
    void GetCodigo(char* cadena) const;
private:
    char*codigo;
    int dni;
    int cantidad;
    double peso;
    
    
};

#endif /* PEDIDO_HPP */

