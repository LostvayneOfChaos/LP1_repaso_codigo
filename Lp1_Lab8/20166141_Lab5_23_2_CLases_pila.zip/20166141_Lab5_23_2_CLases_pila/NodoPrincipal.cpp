/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   NodoPrincipal.cpp
 * Author: AXEL
 * 
 * Created on 9 de noviembre de 2023, 02:07 PM
 */

#include "NodoPrincipal.hpp"

NodoPrincipal::NodoPrincipal() {
}

NodoPrincipal::NodoPrincipal(const NodoPrincipal& orig) {
}

NodoPrincipal::~NodoPrincipal() {
}

void NodoPrincipal::SetPesoTotal(double pesoTotal) {
    this->pesoTotal = pesoTotal;
}

double NodoPrincipal::GetPesoTotal() const {
    return pesoTotal;
}

void NodoPrincipal::SetSig(Nodo* sig) {
    this->sig = sig;
}

Nodo* NodoPrincipal::GetSig() const {
    return sig;
}

