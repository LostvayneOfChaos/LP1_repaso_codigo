/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Flota.cpp
 * Author: AXEL
 * 
 * Created on 9 de noviembre de 2023, 02:00 PM
 */

#include "Flota.hpp"

Flota::Flota() {
    nCamiones=0;
}

Flota::Flota(const Flota& orig) {
}

Flota::~Flota() {
}

void Flota::leerDatos(){
    ifstream inPedidos("pedidos3.csv",ios::in);
    if (!inPedidos) {
        cout<<"error al abrir el archivo";
        exit(1);
    }
    int pesoMaximo=400;
    class Nodo* valor;
    //valor=new class NodoPrincipal;
    while (1) {
        camiones[nCamiones].crearPila(pesoMaximo,valor,nCamiones);
        camiones[nCamiones].leerPed(inPedidos,valor);
        if(inPedidos.eof()) break;
        nCamiones++;
    }
    inPedidos.close();
}


void Flota::imprimirDatos(){
    ofstream  outPedidos("Reporte.txt",ios::out);
    if (!outPedidos) {
        cout<<"error al abrir el archivo";
        exit(1);
    }
    
    for (int i = 0; i < nCamiones; i++) {
        outPedidos<<"Camion "<<i;
        camiones[i].imprimirPila(outPedidos);
    }

    outPedidos.close();
}
void Flota::setNCamiones(int nCamiones) {
    this->nCamiones = nCamiones;
}

int Flota::getNCamiones() const {
    return nCamiones;
}
