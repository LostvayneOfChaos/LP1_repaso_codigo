/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Pedido.cpp
 * Author: AXEL
 * 
 * Created on 9 de noviembre de 2023, 02:12 PM
 */

#include "Pedido.hpp"

Pedido::Pedido() {
    codigo=nullptr;
}

Pedido::Pedido(const Pedido& orig) {
}

Pedido::~Pedido() {
}

void Pedido::SetPeso(double peso) {
    this->peso = peso;
}

double Pedido::GetPeso() const {
    return peso;
}

void Pedido::SetCantidad(int cantidad) {
    this->cantidad = cantidad;
}

int Pedido::GetCantidad() const {
    return cantidad;
}

void Pedido::SetDni(int dni) {
    this->dni = dni;
}

int Pedido::GetDni() const {
    return dni;
}

void Pedido::SetCodigo(char* codigo) {
    if(this->codigo !=nullptr) delete this->codigo;
    this->codigo=new char[strlen(codigo)+1];
    strcpy(this->codigo,codigo);
    
}

void Pedido::GetCodigo(char* cadena) const {
    if(codigo==nullptr) cadena[0]=0;
    strcpy(cadena,codigo);
    
    
}

