/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Pila.hpp
 * Author: AXEL
 *
 * Created on 9 de noviembre de 2023, 02:00 PM
 */
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>

using namespace std;
#ifndef PILA_HPP
#define PILA_HPP

#include "Nodo.hpp"
#include "NodoPrincipal.hpp"

class Pila {
public:
    Pila();
    Pila(const Pila& orig);
    virtual ~Pila();
    void crearPila(int PESOMAX,class Nodo* nuevo,int num);
    void leerPed(ifstream & inPedidos,class Nodo* & );
    void apilarNodo(class Nodo* );
    void imprimirPila(ofstream &);
private:
    NodoPrincipal* pila;
    double totalMax;
};

#endif /* PILA_HPP */

