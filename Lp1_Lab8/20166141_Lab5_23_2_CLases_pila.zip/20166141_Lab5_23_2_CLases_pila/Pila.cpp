/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Pila.cpp
 * Author: AXEL
 * 
 * Created on 9 de noviembre de 2023, 02:00 PM
 */

#include "Pila.hpp"
#include "NodoPrincipal.hpp"
#include "Pedido.hpp"

Pila::Pila() {
    pila=nullptr;
}

Pila::Pila(const Pila& orig) {
}

Pila::~Pila() {
}

void Pila::crearPila(int PESOMAX,class Nodo* valor,int num){
    
    if(pila==nullptr){
        class NodoPrincipal *nuevo = new class NodoPrincipal;
        nuevo->pesoTotal=0;
        nuevo->sig=nullptr;
        pila=nuevo;
        totalMax=PESOMAX;
        if(num!=0){
            apilarNodo(valor);
            double costo=valor->datosPedido.GetPeso();
            nuevo->pesoTotal=((nuevo->pesoTotal)+(costo));
        }
        else{
            class NodoPrincipal *nuevo = new class NodoPrincipal;
            nuevo->pesoTotal=0;
            nuevo->sig=nullptr;
            pila=nuevo;
            totalMax=PESOMAX;
        }
        
        
    }
    
}


void Pila::apilarNodo(class Nodo* valor){
    
    if(pila==nullptr){
        pila->sig=valor;
    }
    else{
        valor->sig=pila->sig;
        pila->sig=valor;
    }
    
    
}
void Pila::leerPed(ifstream & inPedidos,class Nodo* &valor){
    
    //creas nodo e insertas
    char cod[50],aux;
    int DNI;
    int cant;
    double peso;
    while (1) {
        inPedidos.getline(cod,50,',');
        if(inPedidos.eof()) return;
        inPedidos>>DNI>>aux>>cant>>aux>>peso;
        inPedidos.get();
        Nodo* nuevo=new class Nodo;
        nuevo->datosPedido.SetCantidad(cant);
        nuevo->datosPedido.SetCodigo(cod);
        nuevo->datosPedido.SetDni(DNI);
        nuevo->datosPedido.SetPeso(peso);
        //insertas si cumple
        double Total=(pila->pesoTotal)+(peso);
        if(totalMax >= Total){
            apilarNodo(nuevo);
            (pila->pesoTotal)=(pila->pesoTotal+(peso));
            //valor=nullptr;
        }
        else{
            valor=nuevo;
            return ;
        }
    }

}


void Pila::imprimirPila(ofstream &outPedidos){
    outPedidos<<"      Peso : "<<pila->pesoTotal<<endl;
    
    class Nodo* ptr=pila->sig;
    
    while (ptr) {
        char name[50]{};
        ptr->datosPedido.GetCodigo(name);
        outPedidos<<setw(30)<<name<<setw(10)<<
                ptr->datosPedido.GetCantidad()<<
                setw(15)<<ptr->datosPedido.GetPeso()<<endl;
        
        ptr=ptr->sig;
        
    }

    
    
}
