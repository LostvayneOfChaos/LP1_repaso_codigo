/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   NodoPrincipal.hpp
 * Author: AXEL
 *
 * Created on 9 de noviembre de 2023, 02:07 PM
 */
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>

using namespace std;
#ifndef NODOPRINCIPAL_HPP
#define NODOPRINCIPAL_HPP

#include "Nodo.hpp"


class NodoPrincipal {
public:
    NodoPrincipal();
    NodoPrincipal(const NodoPrincipal& orig);
    virtual ~NodoPrincipal();
    void SetPesoTotal(double pesoTotal);
    double GetPesoTotal() const;
    void SetSig(Nodo* sig);
    Nodo* GetSig() const;
    friend class Pila;
private:
    Nodo* sig;
    double pesoTotal;
};

#endif /* NODOPRINCIPAL_HPP */

