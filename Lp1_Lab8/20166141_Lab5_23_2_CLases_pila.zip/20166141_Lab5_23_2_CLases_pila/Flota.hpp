/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Flota.hpp
 * Author: AXEL
 *
 * Created on 9 de noviembre de 2023, 02:00 PM
 */
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>

using namespace std;
#ifndef FLOTA_HPP
#define FLOTA_HPP

#include "Pila.hpp"

class Flota {
public:
    Flota();
    Flota(const Flota& orig);
    virtual ~Flota();
    void imprimirDatos();
    void leerDatos();
    void setNCamiones(int nCamiones);
    int getNCamiones() const;
private:
    class Pila camiones[700];
    int nCamiones;
};

#endif /* FLOTA_HPP */

