/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Nodo.hpp
 * Author: AXEL
 *
 * Created on 9 de noviembre de 2023, 01:59 PM
 */
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>

using namespace std;
#ifndef NODO_HPP
#define NODO_HPP
#include "Pedido.hpp"


class Nodo {
public:
    Nodo();
    Nodo(const Nodo& orig);
    virtual ~Nodo();
    friend class Pila;
private:
    class Pedido datosPedido;
    class Nodo* sig;
};

#endif /* NODO_HPP */

