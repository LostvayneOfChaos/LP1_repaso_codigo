/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: AXEL
 *
 * Created on 31 de agosto de 2023, 08:13 PM
 */

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
#include "AperturaDeArchivos.h"
#include "Estructuras.h"
#include "Sobrecargas.h"
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    ifstream inCliente,inProductos,inPedidos;
    StCliente cliente;
    StProducto producto;
    StPedido pedido;
    bool resultado;
    AperturaDeUnArchivoDeTextosParaLeer(inCliente,"Clientes.csv");
    AperturaDeUnArchivoDeTextosParaLeer(inProductos,"Productos.csv");
    AperturaDeUnArchivoDeTextosParaLeer(inPedidos,"Pedidos.csv");
    /*ifstream inCliente("Clientes.csv");
    if (!inCliente) {
        cout<<"error al abrir clientes.csv"<<endl;
        exit (1);
    }
    ifstream inProductos("Productos.csv");
    if (!inProductos) {
        cout<<"error al abrir Productos.csv"<<endl;
        exit (1);
    }
    ifstream inPedidos("Pedidos.csv");
    if (!inPedidos) {
        cout<<"error al abrir Pedidos.csv"<<endl;
        exit (1);
    }*/
    
    
    
    resultado=inCliente>>cliente;
    cout<<cliente.dni<<' '<<cliente.nombre<<' '<<cliente.categoria<<endl;
    
    resultado=inProductos>>producto;
    cout<<producto.codigo<<' '<<producto.descripcion<<' '<<producto.descuento<<endl;
    
    resultado=inPedidos>>pedido;
    cout<<pedido.dniCliente<<' '<<pedido.codigoProducto<<endl;
    
    
    
    
    return 0;
}

