/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
#include "AperturaDeArchivos.h"
#include "Estructuras.h"
#include "Sobrecargas.h"
using namespace std;


bool operator >>(ifstream &in,StCliente &cliente){
    
    char extra,cadena[50];
    int longitud;
    in>>cliente.dni;
    if(in.eof()) return false;
    extra=in.get();
    in.getline(cadena,50,',');
    longitud=strlen(cadena);
    cliente.categoria=cadena[longitud-1];
    cadena[longitud-2]=0;
    strcpy(cliente.nombre,cadena);
    in.ignore(100,'\n');
    return true;
    
}


bool operator >>(ifstream &in,StProducto &producto){
    int descuento;
    char extra,cadena[50];
    in>>producto.codigo;
    if(in.eof()) return false;
    extra=in.get();
    in.getline(producto.descripcion,100,',');
    in>>producto.precioUnitario;
    extra=in.get();
    in>>descuento;
    if (in.fail()) {
        in.clear();
        extra=in.get();
        in>>producto.descuento;
        extra=in.get();
        in>>producto.stock;
        extra=in.get();
    }
    else{
        producto.descuento=0;
        producto.stock=descuento;
        extra=in.get();
    }
    
    return true;
    
    
}



bool operator >>(ifstream &in,StPedido &pedido){
    
    char extra,cadena[50];
    int dia,mes,anio;
    in>>pedido.dniCliente;
    if(in.eof()) return false;
    extra=in.get();
    in>>pedido.codigoProducto;
    extra=in.get();
    in>>pedido.cantidad;
    extra=in.get();
    in>>dia;
    extra=in.get();
    in>>mes;
    extra=in.get();
    in>>anio;
    pedido.fecha=(anio*10000+mes*100+dia);
    extra=in.get();
    return true;
    
}