/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Sobrecargas.h
 * Author: AXEL
 *
 * Created on 31 de agosto de 2023, 07:36 PM
 */

#ifndef SOBRECARGAS_H
#define SOBRECARGAS_H

bool operator >>(ifstream &in,StCliente &cliente);
bool operator >>(ifstream &in,StProducto &producto);
bool operator >>(ifstream &in,StPedido &pedido);


#endif /* SOBRECARGAS_H */

