/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Estructuras.h
 * Author: Adrian Fujiki
 *
 * Created on 30 de agosto de 2023, 11:23 AM
 */

#ifndef ESTRUCTURAS_H
#define ESTRUCTURAS_H
#include <iostream>
#include <iomanip>
using namespace std;
#include "Estructuras.h"

struct StPedido{
    int dniCliente;
    int codigoProducto;
    int cantidad;
    int fecha; //EN FORMATO AAAAMMDD
};

struct StPedidoCliente{
    int codigoProducto;
    int cantidad;
    int fecha; //EN FORMATO AAAAMMDD
    char descripcion[100];
    double precioProducto;
    double descuento;
    double total;
    char estado; //E: A ENTREGAR     F: FALTA STOCK
};

struct StCliente{
    int dni;
    char nombre[50];
    char categoria;
    struct StPedidoCliente pedidos[20];
    int numeroDePedidos;
    double totalGastado;
};

struct StProducto{
    int codigo;
    char descripcion[100];
    double precioUnitario;
    double descuento;
    int stock;
};

#endif /* ESTRUCTURAS_H */

