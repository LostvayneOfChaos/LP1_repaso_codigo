/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: AXEL
 *
 * Created on 30 de agosto de 2023, 09:51 PM
 */

#include <iomanip>
#include <iostream>
#include <fstream>
#include <cstring>
#include "AperturaDeArchivos.h"
#include "Estructuras.h"
#include "Sobrecargas.h"

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    
    ifstream inCliente;
    ofstream outCliente,outArreglo;
    Estructura_PedidoRealizado pedido;
    Estructura_ProductosEnAlmacen producto,productos[20];
    Estructura_ClienteRegistrado cliente1,cliente2,clientes[20];
    AperturaDeUnArchivoDeTextosParaLeer(inCliente,"Clientes.txt");
    AperturaDeUnArchivoDeTextosParaEscribir(outCliente,"ReporteClientes.txt");
    AperturaDeUnArchivoDeTextosParaEscribir(outArreglo,"ReporteArreglo.txt");
    
    //lectura
    //71984468   IPARRAGUIRRE_VILLEGAS_NICOLAS_EDILBERTO-B      935441620
    inCliente>>cliente1>>cliente2;
    cout<<cliente1.dni<<' '<<cliente1.nombre<<' '<<cliente1.categoria<<endl;
    cout<<cliente2.dni<<' '<<cliente2.nombre<<' '<<cliente2.categoria<<endl;
    //Agregación
    //DOB245   LECHE_LALA_SEMI_DESLACTOSADA_1LT  1.78  16.98    71378466  26/10/2020
    (productos[0].codigo[0]='X');
    (productos[0].codigo[1]=0);
    strcpy(producto.codigo,"DOB245");
    strcpy(producto.descripcion,"LECHE_LALA_SEMI_DESLACTOSADA_1LT");
    producto.descuento=2.0;
    producto.precioUnitario=16.98;
    productos+=producto;
    cout<<productos[0].codigo<<' '<<productos[0].descuento<<' '<<productos[0].descripcion<<productos[1].codigo<<endl;
    //2
    pedido.cantidad=1.87;
    pedido.fecha=20210828;
    strcpy(pedido.codigo,"DOB245");
    cliente1 += pedido;
    cout<<cliente1.pedidosRealizados[cliente1.numeroDePedidos-1].cantidad<<' '<<cliente1.pedidosRealizados[cliente1.numeroDePedidos-1].codigo<<endl;
    //1
    clientes[0].dni=0;
    clientes+=cliente1;
    cout<<clientes[0].dni<<' '<<clientes[0].categoria<<' '<<clientes[0].nombre<<clientes[1].dni<<endl;
    //impresion
    outCliente<<cliente1;
    outArreglo<<productos;
    return 0;
}

