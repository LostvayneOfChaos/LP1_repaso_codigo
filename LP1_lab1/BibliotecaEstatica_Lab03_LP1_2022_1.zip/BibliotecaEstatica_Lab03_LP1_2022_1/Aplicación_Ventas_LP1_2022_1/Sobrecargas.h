/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Sobrecargas.h
 * Author: AXEL
 *
 * Created on 30 de agosto de 2023, 09:56 PM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;

#ifndef SOBRECARGAS_H
#define SOBRECARGAS_H

ifstream & operator >>(ifstream& in,
        Estructura_ClienteRegistrado &cliente);
void guardarDatos(Estructura_ClienteRegistrado &cliente,char*cadena,char*nombre,int indicador);
void operator +=(Estructura_ClienteRegistrado &cliente,
        Estructura_PedidoRealizado & pedido);

void operator +=(Estructura_ProductosEnAlmacen *productos,
        Estructura_ProductosEnAlmacen & producto);
void operator +=(Estructura_ClienteRegistrado *clientes,
        Estructura_ClienteRegistrado & cliente);
void operator <<(ofstream& out ,Estructura_ClienteRegistrado &cliente);
void operator <<(ofstream& out ,Estructura_ProductosEnAlmacen *productos);
#endif /* SOBRECARGAS_H */

