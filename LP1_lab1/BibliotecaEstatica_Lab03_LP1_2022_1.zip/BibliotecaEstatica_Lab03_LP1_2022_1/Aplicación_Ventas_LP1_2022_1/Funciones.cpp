/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include <iomanip>
#include <iostream>
#include <fstream>
#include <cstring>
#include "AperturaDeArchivos.h"
#include "Estructuras.h"
#include "Sobrecargas.h"
#include "Funciones.h"
using namespace std;

void lecturaClientes(ifstream &in,Estructura_ClienteRegistrado &cliente1,
        Estructura_ClienteRegistrado*clientes){
    int i=0;
    in>>ws;
    while (true) {
        in>>cliente1;
        if (in.eof()) break;
        clientes+=cliente1;
    }
    
    
    
}
void guardarCliente(double cantidad,int dni,int fecha,char*codigo,char*descripcion,
                double precioUnitario,double descuento,
        Estructura_ClienteRegistrado * clientes){
    int i=0;
    Estructura_ClienteRegistrado cliente;
    Estructura_PedidoRealizado pedido;
    strcpy(pedido.codigo,codigo);
    pedido.cantidad=cantidad;
    pedido.fecha=fecha;
    while (true) {
        if (clientes[i].dni==0) break;
        if (clientes[i].dni==dni) {
            clientes[i]+=pedido;
            break;
        }
        i++;
        
    }
    
    
    
}
void guardarProducto(double cantidad,int dni,int fecha,char*codigo,char*descripcion,
                double precioUnitario,double descuento,
        Estructura_ProductosEnAlmacen*productos){
    
    Estructura_ProductosEnAlmacen producto;
    
    strcpy(producto.codigo,codigo);
    strcpy(producto.descripcion,descripcion);
    producto.descuento=descuento;
    producto.precioUnitario=precioUnitario;
    
    productos+=producto;
    
}


void lecturaPedidos(ifstream & in,Estructura_ClienteRegistrado *clientes,
        Estructura_ProductosEnAlmacen* productos){
    
    int i=0,dni,fecha,dia,mes,anio;
    char codigo[7],descripcion[80],extra;
    double precioUnitario,descuento,cantidad;
    while (true) {
        in>>ws;
        in.getline(codigo,8,' ');
        if (in.eof()) break;
        in>>ws;
        in.getline(descripcion,81,' ');
        in>>descuento;
        if(in.fail()){
            in.clear();
            extra=in.get();
            in>>descuento;
            in>>cantidad>>precioUnitario>>dni;
        }
        else{
            
            cantidad=descuento;
            descuento=0;
            in>>precioUnitario>>dni;
        }
        in>>dia;
        extra=in.get();
        in>>mes;
        extra=in.get();
        in>>anio;
        fecha=anio*10000+mes*100+dia;
        guardarCliente(cantidad,dni,fecha,codigo,descripcion,
                precioUnitario,descuento,clientes);
        guardarProducto(cantidad,dni,fecha,codigo,descripcion,
                precioUnitario,descuento,productos);
        extra=in.get();
    }
    
}


void imprimirReporte(ofstream &out,Estructura_ProductosEnAlmacen* productos,
        Estructura_ClienteRegistrado * clientes){
    
    out<<productos;
    out<<endl;
    out<<setw(30)<<"PEDIDOS POR CLIENTE"<<endl;
    int i=0;
    while (true) {
        if (clientes[i].dni==0) break;
        out<<clientes[i];
        out<<endl;
        i++;
    }
    
}