/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: AXEL
 *
 * Created on 31 de agosto de 2023, 12:55 AM
 */

#include <iomanip>
#include <iostream>
#include <fstream>
#include <cstring>
#include "AperturaDeArchivos.h"
#include "Estructuras.h"
#include "Sobrecargas.h"
#include "Funciones.h"
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    
    ifstream inCliente,inPedidos;
    ofstream out;
    Estructura_PedidoRealizado pedido;
    Estructura_ProductosEnAlmacen producto,productos[100];
    
    
    productos[0].codigo[0]='X';
    productos[0].codigo[1]='X';
    Estructura_ClienteRegistrado cliente1,cliente2,clientes[100];
    clientes[0].dni=0;
    AperturaDeUnArchivoDeTextosParaLeer(inCliente,"Clientes.txt");
    AperturaDeUnArchivoDeTextosParaLeer(inPedidos,"Pedidos.txt");
    AperturaDeUnArchivoDeTextosParaEscribir(out,"Reporte.txt");
    
    lecturaClientes(inCliente,cliente1,clientes);
    lecturaPedidos(inPedidos,clientes,productos);
    imprimirReporte(out,productos,clientes);
    
    
    return 0;
}

