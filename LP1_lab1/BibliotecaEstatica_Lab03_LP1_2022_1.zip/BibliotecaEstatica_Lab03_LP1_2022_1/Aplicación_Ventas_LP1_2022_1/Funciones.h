/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Funciones.h
 * Author: AXEL
 *
 * Created on 31 de agosto de 2023, 01:17 AM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;
#ifndef FUNCIONES_H
#define FUNCIONES_H

void lecturaClientes(ifstream &inCliente,Estructura_ClienteRegistrado &cliente1,
        Estructura_ClienteRegistrado*clientes);
void lecturaPedidos(ifstream & in,Estructura_ClienteRegistrado *clientes,
        Estructura_ProductosEnAlmacen* productos);
void imprimirReporte(ofstream &out,Estructura_ProductosEnAlmacen* productos,
        Estructura_ClienteRegistrado * clientes);
void guardarCliente(double cantidad,int dni,int fecha,char*codigo,char*descripcion,
                double precioUnitario,double descuento,
        Estructura_ClienteRegistrado * clientes);
void guardarProducto(double cantidad,int dni,int fecha,char*codigo,char*descripcion,
                double precioUnitario,double descuento,
        Estructura_ProductosEnAlmacen*productos);

#endif /* FUNCIONES_H */

