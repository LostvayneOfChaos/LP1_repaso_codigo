/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#include <iomanip>
#include <iostream>
#include <fstream>
#include <cstring>
#include "AperturaDeArchivos.h"
#include "Estructuras.h"
#include "Sobrecargas.h"
#define MAXLEN 140

using namespace std;

void guardarDatos(Estructura_ClienteRegistrado &cliente,char*cadena,char*nombre,int indicador){
    
    int longitud=strlen(cadena);
    int tope;
    if(indicador==1){
        //hasta longitud -2
        tope=longitud-2;
    }
    else{
        tope=longitud;
    }
    int i = 0;
    for (i = 0; i < tope; i++) {
        nombre[i]=cadena[i];
    }
    nombre[i]=0;
    strcpy(cliente.nombre,nombre);
    
    
}






ifstream & operator >>(ifstream& in,Estructura_ClienteRegistrado &cliente){
    int dni,telefono,longitud;
    char cadena[120],nombre[80], categoria[30];
    in>>dni;
    //eof
    cliente.dni=dni;
    in>>ws;
    in.getline(cadena,MAXLEN,' ');
    longitud=strlen(cadena);
    if(cadena[longitud-2]=='-'){ //hay categoria
        categoria[0]=cadena[longitud-1];
        categoria[1]=0;
        guardarDatos(cliente,cadena,nombre,1);
        if(categoria[0] == 'A') strcpy(cliente.categoria,"Cliente muy frecuente");
        else if(categoria[0] == 'B') strcpy(cliente.categoria,"Cliente frecuente");
        else strcpy(cliente.categoria,"Cliente ocasional");
        cliente.montoTotalGastado=0;
        cliente.numeroDePedidos=0;
    }
    else{
        guardarDatos(cliente,cadena,nombre,0);
        cliente.montoTotalGastado=0;
        cliente.numeroDePedidos=0;
    }
    in.ignore(MAXLEN,'\n');
    
    
}
void operator +=(Estructura_ClienteRegistrado &cliente,
        Estructura_PedidoRealizado & pedido){
    
    /*cliente.pedidosRealizados[cliente.numeroDePedidos].cantidad=pedido.cantidad;
    cliente.pedidosRealizados[cliente.numeroDePedidos].fecha=pedido.fecha;
    strcpy(cliente.pedidosRealizados[cliente.numeroDePedidos].codigo,
            pedido.codigo);*/
    cliente.pedidosRealizados[cliente.numeroDePedidos]=pedido;
    cliente.numeroDePedidos=cliente.numeroDePedidos+1;
    //buscarPrecio(pedido.codigo,producto);
    cliente.montoTotalGastado+=pedido.cantidad;
}

void operator +=(Estructura_ProductosEnAlmacen *productos,
        Estructura_ProductosEnAlmacen & producto){
    
    int i=0;
    while (true) {
        if ((productos[i].codigo[0]=='X')){
            productos[i]=producto;
            (productos[i+1].codigo[0]='X');
            (productos[i+1].codigo[1]=0);
            break;
        } 
        if (strcmp(productos[i].codigo,producto.codigo)==0){
            break;
        }
        i++;

    }
    
    
}
void operator +=(Estructura_ClienteRegistrado *clientes,
        Estructura_ClienteRegistrado & cliente){
    
    int i=0;
    while (true) {
        if ((clientes[i].dni==0)){
            clientes[i]=cliente;
            (clientes[i+1].dni=0);
            break;
        } 
        if ((clientes[i].dni==cliente.dni)){
            break;
        }
        i++;

    }
}

void operator <<(ofstream& out ,Estructura_ClienteRegistrado &cliente){
    int dia,mes ,anio,fecha;
    char cadena[120],nombre[80], categoria[30];
    
    out<<setw(10)<<"DNI"<<setw(30)<<"NOMBRE"<<endl;
    out<<setw(10)<<cliente.dni<<setw(60)<<cliente.nombre<<endl;
    out<<cliente.categoria<<endl;
    
    out<<"No."<<setw(10)<<"CODIGO"<<setw(30)<<"CANTIDAD"<<setw(30)<<"FECHA"<<endl;
    for (int i = 0; i < cliente.numeroDePedidos; i++) {
        fecha=cliente.pedidosRealizados[i].fecha;
        anio=fecha/10000;
        fecha=fecha%10000;
        mes=fecha/100;
        dia=fecha%100;
        out<<i+1<<')'<<setw(10)<<cliente.pedidosRealizados[i].codigo
                <<setw(30)<<cliente.pedidosRealizados[i].cantidad
                <<setw(20)<<dia<<'/'<<mes<<'/'<<anio<<endl;
    }
    
    out<<"Monto total comprado:"<<cliente.montoTotalGastado<<endl;
    
    
    
    
}
void operator <<(ofstream& out ,Estructura_ProductosEnAlmacen *productos){
    int dia,mes ,anio,fecha;
    
    out<<setw(30)<<"PRODUCTOS ALMACENADOS"<<endl;
    
    out<<"No."<<setw(10)<<"CODIGO"<<setw(30)<<"Descripcion"<<setw(30)<<"Precio unitario"<<setw(30)<<"Descuento"<<endl;
    int i=0;
    while(true) {
        if(productos[i].codigo[0]=='X') break;
        out<<i+1<<')'<<setw(10)<<productos[i].codigo
                <<setw(40)<<productos[i].descripcion
                <<setw(30)<<productos[i].precioUnitario
                <<setw(10)<<productos[i].descuento<<endl;
        i++;
    }
    
}

