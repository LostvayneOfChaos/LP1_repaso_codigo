/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   MetodoExacto.h
 * Author: AXEL
 *
 * Created on 7 de septiembre de 2023, 04:31 PM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>


using namespace std;

#ifndef METODOEXACTO_H
#define METODOEXACTO_H

void leerCadena(ifstream &inClientes,char*& bufferNombre);
void asignarEspacio(int* &cli_DNI,char ** &cli_Nombre, 
        char* &cli_Categoria,
        char bufferCategoria[],int  bufferDni[],
        char* bufferNombre[],int &nDatos);
void CargaDeClientes (int* &cli_DNI,char ** &cli_Nombre, 
        char*&cli_Categoria);
void ReporteDeClientes (int* &cli_DNI,char ** &cli_Nombre, 
        char* &cli_Categoria);
void insertarOrdenado(char bufferCategoria[],int  bufferDni[],
        char* bufferNombre[],int &nDatos);
void CargaDePedidosYProductos(int* &cli_DNI, int* &pro_Codigo,
        char** &pro_Descripcion,double *&pro_Descuento,double *& pro_Precio, 
        int** &cli_CodigoProFechaPedido,
        double **&cli_CantidadPedido);
void asignarEspacioCliente(int *&cli_DNI,int **&cli_CodigoProFechaPedido, 
            double**&cli_CantidadPedido);
int buscarPosicion(int codigo,int *bufferCodigo,int nDatos);
void insertarProductoOrdenado(int *bufferCodigo,
        char**bufferDescripcion,
            double*bufferDescuento,
        double*bufferPrecio,int &nDatos);
void insertarProducto(int *bufferCodigo,char**bufferDescripcion,
            double*bufferDescuento,double*bufferPrecio,
            int codigo,char*descripcion,
                    double descuento,double precio,int nDatos);
void actualizarCliente(int* &cli_DNI, int dni,int codigo, int fecha,
            double cantidad, int** &cli_CodigoProFechaPedido, 
           double **& cli_CantidadPedido);

void asignarEspacioProdPedido(int* &cli_DNI,int* &pro_Codigo,
        char** &pro_Descripcion,double *&pro_Descuento,double *& pro_Precio, 
        int** &cli_CodigoProFechaPedido,
        double **&cli_CantidadPedido,
            int *bufferCodigo,char**bufferDescripcion,
            double*bufferDescuento,double*bufferPrecio,int& nDatos,
        int* numeroProductos);
void  ReporteDePedidosYProductos(int* &cli_DNI, int* &pro_Codigo,
        char** &pro_Descripcion,double *&pro_Descuento,double *& pro_Precio, 
        int** &cli_CodigoProFechaPedido,
        double **&cli_CantidadPedido);



#endif /* METODOEXACTO_H */

