/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
#include <cmath>

#include "MetodoExacto.h"
using namespace std;

void leerCadena(ifstream &inClientes,char* &bufferNombre){
    
    char cadena[100];
    inClientes.getline(cadena,100,',');
    char* nombre;
    nombre=new char[strlen(cadena)+1];
    strcpy(nombre,cadena);
    bufferNombre=nombre;
    
}



void asignarEspacio(int* &cli_DNI,char ** &cli_Nombre, 
        char* &cli_Categoria,
        char bufferCategoria[],int  bufferDni[],
        char* bufferNombre[],int &nDatos){
    
    bufferCategoria[nDatos]='<';
    bufferDni[nDatos]=0;
    bufferNombre[nDatos]=nullptr;
    
    nDatos++;
    
    cli_DNI=new int[nDatos];
    cli_Nombre=new char*[nDatos];
    cli_Categoria=new char[nDatos];
    
    for (int i = 0; i < nDatos; i++) {
        cli_Categoria[i]=bufferCategoria[i];
        cli_DNI[i]=bufferDni[i];
        cli_Nombre[i]=bufferNombre[i];
    }

    
    
    
    
}
void insertarOrdenado(char bufferCategoria[],int  bufferDni[],
        char* bufferNombre[],int &nDatos){
    int dni=bufferDni[nDatos-1];
    char*nombre=bufferNombre[nDatos-1];
    char categoria=bufferCategoria[nDatos-1];
    int i=0,j=0;
    for (i = 0; i < nDatos-1; i++) {
        if(bufferDni[i]>dni) break;
    }
    for (j=nDatos-2; j >=i; j--) {
        bufferDni[j+1]=bufferDni[j];
        bufferNombre[j+1]=bufferNombre[j];
        bufferCategoria[j+1]=bufferCategoria[j];
    }
    bufferDni[i]=dni;
    bufferNombre[i]=nombre;
    bufferCategoria[i]=categoria;
    
    
}




void CargaDeClientes (int* &cli_DNI,char ** &cli_Nombre, 
        char*&cli_Categoria){
    //71984468,IPARRAGUIRRE VILLEGAS NICOLAS EDILBERTO ,B,935441620
    //DNI, Nombre Categoria, Teléfono
    ifstream inClientes("Clientes.csv",ios::in);
    if (!inClientes) {
        cout<<"error al abrir archivo "<<endl;
        exit (1);
    }
    int bufferDni[100],nDatos=0,telefono;
    //int bufferTelefono[100];
    char* bufferNombre[100],bufferCategoria[100],categoria;
    while (true) {
        inClientes>>bufferDni[nDatos];
        if (inClientes.eof()) break;
        inClientes.get();
        leerCadena(inClientes,bufferNombre[nDatos]);
        inClientes>>telefono;
        if (inClientes.fail()) {
            inClientes.clear();
            bufferCategoria[nDatos]=inClientes.get();
            inClientes.get();
            inClientes>>telefono;
        } 
        else {
            bufferCategoria[nDatos]='N';
        }
        
         inClientes.get();       
         nDatos++;
         insertarOrdenado(bufferCategoria,bufferDni,bufferNombre,nDatos);
    }
    
    //reservar memoria
    asignarEspacio(cli_DNI, cli_Nombre, cli_Categoria,
            bufferCategoria,bufferDni,bufferNombre,nDatos);

    inClientes.close();
}


void ReporteDeClientes (int* &cli_DNI,char ** &cli_Nombre, 
        char* &cli_Categoria){
    
    ofstream outClientes("ReporteClientesPrueba.txt",ios::out);
    if (!outClientes) {
        cout<<"error al abrir archivo "<<endl;
        exit (1);
    }
    
    outClientes<<fixed;
    outClientes<<setprecision(2);
    for (int i = 0;cli_DNI[i] !=0; i++) {
        outClientes<<left<<setw(10)<<cli_DNI[i];
        outClientes<<right<<setw(50)<<cli_Nombre[i];
        outClientes<<right<<setw(3)<<cli_Categoria[i]<<endl;
    }

    outClientes.close();
}
    

void asignarEspacioCliente(int *&cli_DNI,int **&cli_CodigoProFechaPedido, 
            double**&cli_CantidadPedido,int*numeroProductos){
    
    int nDatos=0;
    for (nDatos = 0; cli_DNI[nDatos]; nDatos++) {
    }
    cli_CodigoProFechaPedido=new int*[nDatos];
    cli_CantidadPedido=new double*[nDatos];
    
    cli_CodigoProFechaPedido[0]=nullptr;
    cli_CantidadPedido[0]=nullptr;
    
    for (int i = 0; i < nDatos; i++) {
        numeroProductos[i]=0;
    }

}


int buscarPosicion(int codigo,int *bufferCodigo,int nDatos){
    
    int i=0;
    for (i = 0; i<nDatos; i++) {
        if (codigo==bufferCodigo[i]) {
            return i;
        }
    }
    return -1;
    
}
void insertarProductoOrdenado(int *bufferCodigo,
        char**bufferDescripcion,
            double*bufferDescuento,
        double*bufferPrecio,int &nDatos){
    
    int codigo=bufferCodigo[nDatos-1];
    char*descripcion=bufferDescripcion[nDatos-1];
    double descuento=bufferDescuento[nDatos-1];
    double precio=bufferPrecio[nDatos-1];
    int i=0,j=0;
    for (i = 0; i < nDatos-1; i++) {
        if(bufferCodigo[i]>codigo) break;
    }
    for (j=nDatos-2; j >=i; j--) {
        bufferCodigo[j+1]=bufferCodigo[j];
        bufferDescripcion[j+1]=bufferDescripcion[j];
        bufferDescuento[j+1]=bufferDescuento[j];
        bufferPrecio[j+1]=bufferPrecio[j];
    }
    bufferCodigo[i]=codigo;
    bufferDescripcion[i]=descripcion;
    bufferDescuento[i]=descuento;
    bufferPrecio[i]=precio;
    
    
}

void insertarProducto(int *bufferCodigo,char**bufferDescripcion,
            double*bufferDescuento,double*bufferPrecio,
            int codigo,char*descripcion,
                    double descuento,double precio,int nDatos){
    
    bufferCodigo[nDatos]=codigo;
    bufferDescripcion[nDatos]=descripcion;
    bufferDescuento[nDatos]=descuento;
    bufferPrecio[nDatos]=precio;
    
    
}

void actualizarCliente(int* &cli_DNI, int dni,int codigo, int fecha,
            double cantidad, int** &cli_CodigoProFechaPedido, 
           double **& cli_CantidadPedido,int*numeroProductos){
    
    int i=0,pos=-1,*arregloCodigo;
    double *arregloCantidad;
    for (i = 0; cli_DNI[i]!=0; i++) {
        if (dni==cli_DNI[i]) {
            pos= i;
            break;
        }
    }
    if (pos==-1) {
        return ;//dni debe estar en el arreglo dinamico
    } else {
        if (numeroProductos[pos]==0) {
            cli_CodigoProFechaPedido[pos]=new int[200];
            cli_CantidadPedido[pos]=new double[200];
            
        }
        arregloCodigo=cli_CodigoProFechaPedido[pos];
        arregloCantidad=cli_CantidadPedido[pos];
        
        arregloCodigo[2*numeroProductos[pos]]=codigo;
        arregloCodigo[2*numeroProductos[pos]+1]=fecha;
        arregloCantidad[numeroProductos[pos]]=cantidad;
        numeroProductos[pos]++;
        //tope
        arregloCodigo[2*numeroProductos[pos]]=0;
        arregloCodigo[2*numeroProductos[pos]+1]=0;
        arregloCantidad[numeroProductos[pos]]=-1;
        
    }
    
    
}


void asignarEspacioProdPedido(int* &cli_DNI,int* &pro_Codigo,
        char** &pro_Descripcion,double *&pro_Descuento,double *& pro_Precio, 
        int** &cli_CodigoProFechaPedido,
        double **&cli_CantidadPedido,
            int *bufferCodigo,char**bufferDescripcion,
            double*bufferDescuento,double*bufferPrecio,int& nDatos,
        int* numeroProductos){
    
    bufferCodigo[nDatos]=0;
    bufferDescuento[nDatos]=0.0;
    bufferPrecio[nDatos]=0.0;
    bufferDescripcion[nDatos]=nullptr;
    nDatos++;
    
    
    
    int i=0;
    for (i = 0; cli_DNI[i]!=0; i++) {
        
    }
    cli_CodigoProFechaPedido[i]=nullptr;
    cli_CantidadPedido[i]=nullptr;
    numeroProductos[i]=-1;
    
    pro_Codigo=new int[nDatos];
    pro_Descuento=new double[nDatos];
    pro_Precio=new double[nDatos];
    pro_Descripcion=new char*[nDatos];
    
    for (int j = 0; j < nDatos; j++) {
        pro_Codigo[j]=bufferCodigo[j];
        pro_Descripcion[j]=bufferDescripcion[j];
        pro_Descuento[j]=bufferDescuento[j];
        pro_Precio[j]=bufferPrecio[j];
    }

    
    
}

void CargaDePedidosYProductos(int* &cli_DNI, int* &pro_Codigo,
        char** &pro_Descripcion,double *&pro_Descuento,double *& pro_Precio, 
        int** &cli_CodigoProFechaPedido,
        double **&cli_CantidadPedido){
    
    //397718,LECHE LALA SEMI DESLACTOSADA 1LT,
    //1.78,16.98,71378466,26/10/2020
    //código,Descripción,Descuento(si lo tiene),cantidad,
    //precio unitario,DNI del cliente,Fecha del pedido
    ifstream inPedidos("Pedidos.csv",ios::in);
    if (!inPedidos) {
        cout<<"error al abrir archivo "<<endl;
        exit (1);
    }
    int numeroProductos[100];
    int pos,bufferCodigo[200],nDatos=0,dni,dia,mes,anio,fecha,codigo;
    double precio,bufferDescuento[200],bufferPrecio[200],descuento,cantidad;
    char* bufferDescripcion[200],*descripcion;
    asignarEspacioCliente(cli_DNI,cli_CodigoProFechaPedido, 
            cli_CantidadPedido,numeroProductos);
    while (true) {
        inPedidos>>codigo;
        if (inPedidos.eof()) break;
        inPedidos.get();
        leerCadena(inPedidos,descripcion);
        inPedidos>>cantidad;
        if (inPedidos.fail()) {
            inPedidos.clear();
            inPedidos.get();
            inPedidos>>descuento;
            inPedidos.get();
            inPedidos>>cantidad;
        }
        else descuento=0;
        inPedidos.get();
        inPedidos>>precio;
        inPedidos.get();
        inPedidos>>dni;
        inPedidos.get();
        inPedidos>>dia;
        inPedidos.get();
        inPedidos>>mes;
        inPedidos.get();
        inPedidos>>anio;
        fecha=anio*10000+mes*100+dia;
        inPedidos.get();       
        pos=buscarPosicion(codigo,bufferCodigo,nDatos);
        if (pos==-1) {
            insertarProducto(bufferCodigo,bufferDescripcion,
            bufferDescuento,bufferPrecio,codigo,descripcion,
                    descuento,precio,nDatos);
            nDatos++;
            insertarProductoOrdenado(bufferCodigo,bufferDescripcion,
            bufferDescuento,bufferPrecio,nDatos);
            
        }
        /*insertarOrdenado(bufferCodigo,bufferDescripcion,
            bufferDescuento,bufferPrecio,nDatos);*/
        actualizarCliente(cli_DNI, dni,codigo, fecha,
            cantidad, cli_CodigoProFechaPedido, 
            cli_CantidadPedido,numeroProductos);
    }
    //reservar memoria y agregar tope al buffer de producto
    asignarEspacioProdPedido( cli_DNI,pro_Codigo, pro_Descripcion,
            pro_Descuento, pro_Precio, cli_CodigoProFechaPedido, 
            cli_CantidadPedido,
            bufferCodigo,bufferDescripcion,
            bufferDescuento,bufferPrecio,nDatos,numeroProductos);
    
    inPedidos.close();
}


void ReporteDePedidosYProductos(int* &cli_DNI, int* &pro_Codigo,
        char** &pro_Descripcion,double *&pro_Descuento,double *& pro_Precio, 
        int** &cli_CodigoProFechaPedido,
        double **&cli_CantidadPedido){
    
    ofstream out("ReportePedidosProductosPrueba.txt",ios::out);
    if (!out) {
        cout<<"error al abrir archivo "<<endl;
        exit (1);
    }
    
    out<<fixed;
    out<<setprecision(2);
    for (int i = 0;pro_Codigo[i] !=0; i++) {
        out<<left<<setw(10)<<pro_Codigo[i];
        out<<right<<setw(50)<<pro_Descripcion[i];
        out<<right<<setw(10)<< pro_Descuento[i];
        out<<right<<setw(10)<< pro_Precio[i]<<endl;
    }
    int *arregloCodigo;
    double*arregloCantidad;
    for (int i = 0;cli_DNI[i] !=0; i++) {
        out<<left<<setw(10)<<"dni es :"<<cli_DNI[i]<<endl;
        arregloCodigo=cli_CodigoProFechaPedido[i];
        arregloCantidad=cli_CantidadPedido[i];
        for (int j = 0; arregloCodigo[j]!=0 ; j+=2) {//ste j=j+2 es lo que me hace salir de rango
            out<<left<<setw(10)<<arregloCodigo[j]<<right<<setw(10)<<arregloCodigo[j+1]/*<<setw(10)<<arregloCantidad[j]*/<<endl;
        }
        for (int j = 0; arregloCantidad[j]!=-1 ; j++) {
            out<<left<<arregloCantidad[j]<<endl;
        }
    }
    
    
    out.close();
    
    
}
