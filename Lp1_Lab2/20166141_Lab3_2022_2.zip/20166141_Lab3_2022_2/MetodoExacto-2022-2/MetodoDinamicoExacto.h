/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   MetodoDinamicoExacto.h
 * Author: alulab14
 *
 * Created on 5 de septiembre de 2023, 03:40 PM
 */

#ifndef METODODINAMICOEXACTO_H
#define METODODINAMICOEXACTO_H
#include <iomanip>
#include <iostream>
#include <fstream>
#include <cstring>

using namespace std;

void lecturaDeMedicos (const char* nombreArchivo,int* &med_Codigo,
        char** &med_Nombre,char** &med_Especialidad,double* & med_Tarifa);
void leer_Nombre_Especialidad(ifstream &in,
        char** bufferNombre,char** bufferEspecialidad,int nDatos);
void asignarValoresMedicos(int* &med_Codigo,
        char** &med_Nombre,char** &med_Especialidad,double* & med_Tarifa,
            int nDatos,int*bufferCodigo,double*bufferTarifa,
        char**bufferNombre,char** bufferEspecialidad);
void pruebaDeLecturaDeMedicos (const char* nombreArchivo,int* &med_Codigo,
        char** &med_Nombre,char** &med_Especialidad,double* & med_Tarifa);
int existeDni(int dni,int* bufferDni,int nDatos);

char* leeCadena(ifstream & in);
int posicionFinal(int*paciente);
void lecturaDeCitas (const char* nombreArchivo,
        int*pac_Dni, char**pac_Nombre, int**pac_Citas);

void asignarEspacio(int*bufferDni,char**bufferNombre,int**bufferCitas,
        int nDatos,int*pac_Dni, char**pac_Nombre, int**pac_Citas);
void pruebaDeLecturaDeCitas (const char* nombreArchivo,
        int*pac_Dni, char**pac_Nombre, int**pac_Citas);
#endif /* METODODINAMICOEXACTO_H */

