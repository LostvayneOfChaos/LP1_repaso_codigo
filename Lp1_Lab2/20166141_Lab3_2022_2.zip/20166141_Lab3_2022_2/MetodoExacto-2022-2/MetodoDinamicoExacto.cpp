/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#include <iomanip>
#include <iostream>
#include <fstream>
#include <cstring>
#include "MetodoDinamicoExacto.h"
using namespace std;

void leer_Nombre_Especialidad(ifstream &in,
        char** bufferNombre,char** bufferEspecialidad,int nDatos){
    char* pos;
    char cadena[100];
    in.getline(cadena,100,',');
    pos=strrchr(cadena,' ');
    char *nombre=new char[pos-cadena+1];
    int i=0;
    for (i = 0; i < (pos-cadena+1); i++) {
        nombre[i]=cadena[i];
    }
    nombre[i]='\0';
    bufferNombre[nDatos]=nombre;
    
    int cantCaracEsp=0,cantCarac=strlen(cadena),total,inicioNombre;
    total=cantCarac;
    while(cadena[cantCarac]!=' '){
        cantCarac--;
        cantCaracEsp++;
    }
    char *especialidad=new char[cantCaracEsp];
    inicioNombre=total-cantCaracEsp;
    for (i = 0; i < cantCaracEsp; i++,inicioNombre++) 
        especialidad[i]=cadena[inicioNombre+1];
    
    especialidad[i]='\0';
    bufferEspecialidad[nDatos]=especialidad;
    
}


void asignarValoresMedicos(int* &med_Codigo,
        char** &med_Nombre,char** &med_Especialidad,double* & med_Tarifa,
            int nDatos,int*bufferCodigo,double*bufferTarifa,
        char**bufferNombre,char** bufferEspecialidad){
    
    for (int i = 0; i < nDatos; i++) {
        med_Codigo[i]=bufferCodigo[i]; 
        med_Especialidad[i]=bufferEspecialidad[i]; 
        med_Nombre[i]=bufferNombre[i]; 
        med_Tarifa[i]=bufferTarifa[i];  
    }
    
}

void lecturaDeMedicos (const char* nombreArchivo,int* &med_Codigo,
        char** &med_Nombre,char** &med_Especialidad,double* & med_Tarifa){
    
    ifstream in(nombreArchivo,ios::in);
    if (!in){
        cout<<"error al abrir el archivo"<<endl;
        exit(1);
    }
    int bufferCodigo[100],nDatos=0;
    double bufferTarifa[100];
    char *bufferNombre[100],*bufferEspecialidad[100];
    while (true) {
        in>>bufferCodigo[nDatos];
        if (in.eof()) break;
        in.get();
        leer_Nombre_Especialidad(in,bufferNombre,bufferEspecialidad,nDatos);
        in>>bufferTarifa[nDatos];
        in.get();
        nDatos++;
    }
    bufferCodigo[nDatos]=0;
    (bufferNombre[nDatos]="XXX");
    (bufferEspecialidad[nDatos]="XXX");
    bufferTarifa[nDatos]=0;
    nDatos++;
    med_Codigo=new int[nDatos];
    med_Especialidad=new char*[nDatos];
    med_Nombre=new char*[nDatos];
    med_Tarifa=new double[nDatos];
    
    asignarValoresMedicos(med_Codigo, med_Nombre, med_Especialidad, med_Tarifa,
            nDatos,bufferCodigo,bufferTarifa,bufferNombre,bufferEspecialidad);
    in.close();
}





void pruebaDeLecturaDeMedicos (const char* nombreArchivo,int* &med_Codigo,
        char** &med_Nombre,char** &med_Especialidad,double* & med_Tarifa){
    
    ofstream out(nombreArchivo,ios::out);
    if (!out){
        cout<<"error al abrir el archivo"<<endl;
        exit(1);
    }
    out<<fixed;
    out<<setprecision(2);
    
    for (int i = 0; med_Codigo[i]!=0; i++) {
        out<<left<<setw(10)<<med_Codigo[i];
        out<<right<<setw(20)<< med_Nombre[i];
        out<<right<<setw(40)<<med_Especialidad[i];
        out<<right<<setw(10)<<med_Tarifa[i]<<endl;
    }
    out.close();
}


int existeDni(int dni,int* bufferDni,int nDatos){
    
    for (int i = 0; i < nDatos; i++) {
        if (dni==bufferDni[i]) {
            return i;
        }
        else return 0;
    }
}

char* leeCadena(ifstream & in){
    
    char cadena[100];
    char *nombre;
    in.getline(cadena,100,',');
    nombre=new char[strlen(cadena)+1];
    strcpy(nombre,cadena);
    return nombre;
    
    
}

int posicionFinal(int*paciente){
    
    int inicio=paciente[0];
    int j=0;
    for (int i = paciente[j];paciente[j]!=0; j++) {
        if (paciente[j]==0) {
            break;
        }
    }
}

void asignarEspacio(int*bufferDni,char**bufferNombre,int**bufferCitas,
        int nDatos,int*pac_Dni, char**pac_Nombre, int**pac_Citas){
    
    bufferCitas[nDatos]=0;
    bufferDni[nDatos]=0;
    (bufferNombre[nDatos]="XXX");
    nDatos++;
    
    pac_Dni=new int[nDatos];
    pac_Nombre=new char*[nDatos];
    pac_Citas=new int*[nDatos];
    
    //guardar en datos exactos y remover los bufferDetalles
    int i = 0;
    for (i = 0; i < nDatos; i++) {
        pac_Dni[i]=bufferDni[i];
        if(i!=nDatos-1)strcpy(pac_Nombre[i],bufferNombre[i]);
        else pac_Nombre[i]=bufferNombre[i];
        pac_Citas[i]=bufferCitas[i];
    }
    
    
    
    
    
}

void lecturaDeCitas (const char* nombreArchivo,
        int*pac_Dni, char**pac_Nombre, int**pac_Citas){
    //43704548,Vizcardo/Maribel,732354,9/9/2022
    //Código y nombre del paciente, código del médico, fecha
    ifstream in(nombreArchivo,ios::in);
    if (!in){
        cout<<"error al abrir el archivo"<<endl;
        exit(1);
    }
    int nDatos=0,bufferDni[100],*bufferCitas[100],fecha,dni,cod,dia,
            mes,anio,*bufferDetalles;
    char*bufferNombre[100];
    while (true) {
        in>>dni;
        if (in.eof()) break;
        in.get();
        int valor=existeDni(dni,bufferDni,nDatos);
        int*paciente;
        if(valor==0){
            bufferNombre[nDatos]=leeCadena(in);
            bufferDetalles=new int[100];
            bufferDetalles[nDatos]=0;
            bufferCitas[nDatos]=bufferDetalles;
            paciente=bufferCitas[nDatos];
        }
        else{
            in.ignore(100,',');
            paciente=bufferCitas[valor];
        }
        in>>cod;
        in.get();
        in>>dia;
        in.get();
        in>>mes;
        in.get();
        in>>anio;
        in.get();
        fecha=anio*10000+mes*100+dia;
        int posFinal;
        posFinal=posicionFinal(paciente);
        
        paciente[posFinal]=cod;
        paciente[posFinal+1]=fecha;
        paciente[posFinal+2]=0;
        
    }
    
    asignarEspacio(bufferDni,bufferNombre,bufferCitas,nDatos,
            pac_Dni, pac_Nombre, pac_Citas);
            nDatos++;
    
    
    in.close();
}


void pruebaDeLecturaDeCitas (const char* nombreArchivo,
        int*pac_Dni, char**pac_Nombre, int**pac_Citas){
    
    
    ofstream out(nombreArchivo,ios::out);
    if (!out){
        cout<<"error al abrir el archivo"<<endl;
        exit(1);
    }
    out<<fixed;
    out<<setprecision(2);
    
    for (int i = 0; pac_Dni[i]!=0; i++) {
        out<<left<<setw(10)<<pac_Dni[i];
        out<<right<<setw(20)<< pac_Nombre[i];
        int*recorre=pac_Citas[i];
        int j=0;
        for (int a = recorre[j]; recorre[j]; j++) {
            out<<left<<setw(10)<<' '<<a;
        }
        out<<endl;

    }
    out.close();
    
    
    
}