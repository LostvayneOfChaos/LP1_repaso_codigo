/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   FuncionesAuxiliares.h
 * Author: alulab14
 *
 * Created on 8 de septiembre de 2023, 08:06 AM
 */

#ifndef FUNCIONESAUXILIARES_H
#define FUNCIONESAUXILIARES_H

void lecturaDeProductos(const char*nomArch,char ***&productos,int *&stock,double *&precios);
char **devuelveProd(char *codigo,char *descripcion);
char* leeCadena(ifstream &arch,char delim='\n');
void pruebaDeLecturaDeProductos(const char*nomArch,char ***productos,int *stock,
        double *precios);
void lecturaDePedidos(const char*nomArch,int *&fechaPedidos,char***&codigoPedidos,
        int ***&dniCantPedidos);
void cargaBuffDniCantPedidos(int **&buffDniCantPedidos,int dni,int cantidad,
        int numPed);
void cargaBuffCodigoPedidos(char **&buffCodPedidos,char *codProd,int &numPed);
int buscaPosFecha(int fecha,int *buffFechas,int numFechas);
void pruebaDeLecturaPedidos(const char* nomArch,int *fechaPedidos,
        char***codigoPedidos,int ***dniCantPedidos);
void imprimeLoDemas(ofstream &arch,char *codProd,int *arrDniCant);
void reporteDeEnvioDePedidos(const char*nomArch,char ***productos,int *stock,double *precios,
            int *fechaPedidos,char ***codigoPedidos,int ***dniCantPedidos);
void imprimeLinea(ofstream &arch,int n,char c);
void imprimePedido(ofstream &arch,int num,char *codProd,int *arrDniCant,char **productos,int &stock,
                        double precio);
int BuscaPosProd(char *codProd,char ***productos);
#endif /* FUNCIONESAUXILIARES_H */

