/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <fstream>
using namespace std;
#include <cstring>
#include "FuncionesAuxiliares.h"

void lecturaDeProductos(const char*nomArch,char ***&productos,int *&stock,double *&precios){
    ifstream arch(nomArch,ios::in);
    if(not arch.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nomArch<<endl;
        exit(1);
    }
    //Def. variables
    char *codigo,*descripcion,car;
    double precio;
    int stockFinal,numProd=0;
    //De. buffers
    char **buffProductos[200]{};
    int buffStock[200]{};
    double buffPrecio[200]{};
    while(true){
        //Lectura
        codigo = leeCadena(arch,',');
        if(arch.eof())break;
        descripcion = leeCadena(arch,',');
        arch>>precio>>car>>stockFinal;
        arch.get();//Para comerse el último enter
        //Llenado de buffers
        buffProductos[numProd] = devuelveProd(codigo,descripcion);
        buffStock[numProd] = stockFinal;
        buffPrecio[numProd] = precio;
        numProd++;
    }
    //Pasar de buffer a exacto
    buffProductos[numProd] = nullptr;
    buffStock[numProd] = 0;
    buffPrecio[numProd] = 0.0;
    numProd++;
    
    productos = new char**[numProd]{};
    stock = new int[numProd]{};
    precios = new double[numProd]{};
    
    for(int i=0;i<numProd;i++){
        productos[i]=buffProductos[i];
        stock[i]=buffStock[i];
        precios[i]=buffPrecio[i];
    }
}

char **devuelveProd(char *codigo,char *descripcion){
    char **prod;
    prod = new char*[2];
    prod[0]=codigo;
    prod[1]=descripcion;
    return prod;
}

char* leeCadena(ifstream &arch,char delim){
    char cadena[100],*cad;
    arch.getline(cadena,100,delim);
    if(arch.eof())return nullptr;
    cad = new char[strlen(cadena)+1];
    strcpy(cad,cadena);
    return cad;
}

void pruebaDeLecturaDeProductos(const char*nomArch,char ***productos,int *stock,
        double *precios){
    ofstream arch(nomArch,ios::out);
    if(not arch.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nomArch<<endl;
        exit(1);
    }
    char **aux;
    for(int i=0;productos[i]!=nullptr;i++){
        aux = productos[i];
        arch<<left<<setw(15)<<"Codigo: "<<right<<aux[0]<<endl;
        arch<<left<<setw(15)<<"Descripcion: "<<right<<aux[1]<<endl;
        arch<<left<<setw(15)<<"Stock: "<<right<<stock[i]<<endl;
        arch<<left<<setw(15)<<"Precio: "<<right<<precios[i]<<endl<<endl;
    }
}

void lecturaDePedidos(const char*nomArch,int *&fechaPedidos,char***&codigoPedidos,
        int ***&dniCantPedidos){
    ifstream arch(nomArch,ios::in);
    if(not arch.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nomArch<<endl;
        exit(1);
    }
    //Def. Variables
    char *codProd,car;
    int dni,cantidad,dd,mm,aa,fecha,posFecha,numFechas=0;
    int numPedXFecha[200]{};
    //Def. Buffers
    int buffFechas[200]{};
    char **buffCodPedidos[200]{};
    int **buffDniCantPedidos[200]{};
    while(true){
        //Lectura
        codProd = leeCadena(arch,',');
        if(arch.eof())break;
        arch>>dni>>car>>cantidad>>car>>dd>>car>>mm>>car>>aa;
        arch.get();//Sacando el enter del final de la línea
        fecha = dd+mm*100+aa*10000;
        //Llenar buffers
        posFecha = buscaPosFecha(fecha,buffFechas,numFechas);
        if(posFecha==-1){
            //Acá la fecha es nueva
            buffFechas[numFechas]=fecha;
            cargaBuffCodigoPedidos(buffCodPedidos[numFechas],codProd,numPedXFecha[numFechas]);
            cargaBuffDniCantPedidos(buffDniCantPedidos[numFechas],dni,cantidad,numPedXFecha[numFechas]);
            numPedXFecha[numFechas]++;
            numFechas++;
        }
        else{
            //Acá la fecha es repetida
            cargaBuffCodigoPedidos(buffCodPedidos[posFecha],codProd,numPedXFecha[posFecha]);
            cargaBuffDniCantPedidos(buffDniCantPedidos[posFecha],dni,cantidad,numPedXFecha[posFecha]);
            numPedXFecha[posFecha]++;
        }
    }
    //Pasar de buffers a arreglos exactos
    buffFechas[numFechas]=0;
    buffCodPedidos[numFechas]=nullptr;
    buffDniCantPedidos[numFechas]=nullptr;
    numFechas++;
    
    fechaPedidos = new int[numFechas]{};
    codigoPedidos = new char**[numFechas]{};
    dniCantPedidos = new int**[numFechas]{};
    
    for(int i=0;i<numFechas;i++){
        fechaPedidos[i]=buffFechas[i];
        codigoPedidos[i]=buffCodPedidos[i];
        dniCantPedidos[i]=buffDniCantPedidos[i];
    }
    //Recortar arreglos
    
}

void cargaBuffDniCantPedidos(int **&buffDniCantPedidos,int dni,int cantidad,
        int numPed){
    int *aux;
    if(numPed==0){
        buffDniCantPedidos = new int*[100]{};
    }
    buffDniCantPedidos[numPed] = new int[2]{};
    aux = buffDniCantPedidos[numPed];
    aux[0]=dni;
    aux[1]=cantidad;
}

void cargaBuffCodigoPedidos(char **&buffCodPedidos,char *codProd,int &numPed){
    if(numPed==0){
        buffCodPedidos = new char*[100]{};
    }
    buffCodPedidos[numPed]=codProd;
}

int buscaPosFecha(int fecha,int *buffFechas,int numFechas){
    for(int i=0;i<numFechas;i++){
        if(buffFechas[i]==fecha)return i;
    }
    return -1;
}

void pruebaDeLecturaPedidos(const char* nomArch,int *fechaPedidos,
        char***codigoPedidos,int ***dniCantPedidos){
    ofstream arch(nomArch,ios::out);
    if(not arch.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nomArch<<endl;
        exit(1);
    }
    char **aux1;
    int **aux2;
    for(int i=0;fechaPedidos[i]!=0;i++){
        arch<<"-------------------------------------------------------------------"<<endl;
        arch<<left<<setw(15)<<"Fecha: "<<right<<fechaPedidos[i]<<endl;
        arch<<"Pedidos: "<<endl;
        aux1 = codigoPedidos[i];
        aux2 = dniCantPedidos[i];
        for(int j=0;aux1[j]!=nullptr;j++){//Recorriendo los pedidos de una fecha
            imprimeLoDemas(arch,aux1[j],aux2[j]);
        }
        arch<<endl;
    }
}

void imprimeLoDemas(ofstream &arch,char *codProd,int *arrDniCant){
    arch<<left<<setw(15)<<"     CodProd: "<<right<<codProd<<endl;
    arch<<left<<setw(15)<<"     DNI: "<<right<<arrDniCant[0]<<endl;
    arch<<left<<setw(15)<<"     Cantidad: "<<right<<arrDniCant[1]<<endl<<endl;
}

void reporteDeEnvioDePedidos(const char*nomArch,char ***productos,int *stock,double *precios,
            int *fechaPedidos,char ***codigoPedidos,int ***dniCantPedidos){
    ofstream arch(nomArch,ios::out);
    if(not arch.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nomArch<<endl;
        exit(1);
    }
    arch<<setw(70)<<"REPORTE DE ENTREGA DE PEDIDOS"<<endl;
    char **aux1;
    int **aux2,posProd=0;
    for(int i=0;fechaPedidos[i]!=0;i++){
        imprimeLinea(arch,100,'=');
        arch<<"FECHA: "<<fechaPedidos[i]<<endl;
        imprimeLinea(arch,100,'=');
        arch<<left<<setw(5)<<"No."<<setw(15)<<"DNI"<<setw(30)<<"Producto"<<
                setw(15)<<"Cantidad"<<setw(15)<<"Precio"<<setw(20)<<"Total de ingresos"<<right<<endl;
        imprimeLinea(arch,100,'-');
        aux1 = codigoPedidos[i];
        aux2 = dniCantPedidos[i];
        for(int j=0;aux1[j]!=nullptr;j++){
            posProd = BuscaPosProd(aux1[j],productos);
            if(posProd!=-1)
                imprimePedido(arch,j,aux1[j],aux2[j],productos[posProd],stock[posProd],
                        precios[posProd]);
        }
        arch<<endl;
    }
}

void imprimePedido(ofstream &arch,int num,char *codProd,int *arrDniCant,char **productos,int &stock,
                        double precio){
    arch<<setw(2)<<num<<')'<<setw(12)<<arrDniCant[0]<<setw(10)<<codProd<<setw(60)<<
            productos[1]<<endl;
}

int BuscaPosProd(char *codProd,char ***productos){
    char **aux;
    for(int i=0;productos[i]!=nullptr;i++){
        aux = productos[i];
        if(strcmp(codProd,aux[0])==0)return i;
    }
    return -1;
}

void imprimeLinea(ofstream &arch,int n,char c){
    for(int i=0;i<n;i++)
        arch<<c;
    arch<<endl;
}