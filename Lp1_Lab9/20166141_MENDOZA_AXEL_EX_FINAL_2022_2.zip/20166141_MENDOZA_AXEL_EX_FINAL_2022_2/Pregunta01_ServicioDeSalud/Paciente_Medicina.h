/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Paciente_Medicina.h
 * Author: alulab14
 *
 * Created on 15 de noviembre de 2023, 05:07 PM
 */
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>
#include <map>
#include <list>
using namespace std;
#include "Paciente.h"
#include "Medicina.h"
#include "Medicina_Cantidad.h"
#ifndef PACIENTE_MEDICINA_H
#define PACIENTE_MEDICINA_H

class Paciente_Medicina {
public:
    Paciente_Medicina();
    Paciente_Medicina(const Paciente_Medicina& orig);
    virtual ~Paciente_Medicina();
    void totalizar(map<int, Medicina> );
    void setTotalDeGastos(double totalDeGastos);
    double getTotalDeGastos() const;
    bool operator == (int );
    void insertarPaciente(class Paciente &,class Medicina_Cantidad &);
    void actualizar(int fecha,class Medicina_Cantidad &);
    void imprimir(ofstream &);  
    void operator =(const Paciente_Medicina& orig);
    
private:
    class Paciente paciente;
    list<class Medicina_Cantidad>medicina_cantidad;
    double totalDeGastos;
    
};

#endif /* PACIENTE_MEDICINA_H */

