/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ServicioDeSalud.cpp
 * Author: alulab14
 * 
 * Created on 15 de noviembre de 2023, 05:07 PM
 */

#include "ServicioDeSalud.h"

ServicioDeSalud::ServicioDeSalud() {
    
}

ServicioDeSalud::ServicioDeSalud(const ServicioDeSalud& orig) {
}

ServicioDeSalud::~ServicioDeSalud() {
}

void ServicioDeSalud::leerMedicinas (const char* cadena){
    //Código, Descripción,Precio unitario
    ifstream inMedicinas(cadena,ios::in);
    if (!inMedicinas) {
        cout<<"error al abrir el archivo";
        exit(1);
    }
    class Medicina medic;
    int i=0;
    while (1) {
        inMedicinas>>medic;
        if(inMedicinas.eof()) break;
        medicina[i]=medic;
        i++;
    }
    
    inMedicinas.close();
}
void ServicioDeSalud::imprimirMedicinas (const char* cadena){
    ofstream outMedicinas(cadena,ios::out);
    if (!outMedicinas) {
        cout<<"error al abrir el archivo";
        exit(1);
    }
    outMedicinas<<"Medicinas"<<endl;
    for (map<int,Medicina>::iterator it = medicina.begin();
            it !=medicina.end(); it++) {
        outMedicinas<<it->second;
        outMedicinas<<endl;
    }

    
    
    
    outMedicinas.close();
}
void ServicioDeSalud::leerConsultas (const char* cadena){
    /*Fecha de la consulta,DNI del paciente,
     *  nombre del paciente,
     *  código del médico que lo atendió y la listade medicamentos.
     *  Los medicamentos se identifican 
     * por su codigo y por la cantidad medicada*/
    ifstream inConsultas(cadena,ios::in);
    if (!inConsultas) {
        cout<<"error al abrir el archivo";
        exit(1);
    }
    class Paciente paciente;
    int dni;
    char nombre[50],aux;
    int fechaUltimaConsulta,dia,mes,anio;
    while (1) {
        inConsultas>>dia>>aux>>mes>>aux>>anio;
        if(inConsultas.eof()) break;
        inConsultas>>aux>>dni>>aux;
        inConsultas.getline(nombre,50,',');
        paciente.SetDni(dni);
        fechaUltimaConsulta=anio*100006+mes*100+dia;
        paciente.SetFechaUltimaConsulta(fechaUltimaConsulta);
        paciente.SetNombre(nombre);
        leerListaMedicamentos(inConsultas,paciente);
    }
    
    inConsultas.close();
}

void ServicioDeSalud::leerListaMedicamentos(ifstream &inConsultas,
        class Paciente &paciente){
    char codMedico[10];
    int codMedicina,cantidad;
    char aux;
    class Medicina_Cantidad medic_cant;
    inConsultas.getline(codMedico,10,',');
    class Paciente_Medicina encontrado;
    int indice=0;
    if(paciente_medicina.size()!=0){
        for(Paciente_Medicina i:paciente_medicina){
            
            if(i==(paciente.GetDni())){
                //encontre 
                indice=1;
                //encontrado=i;
                while (1) {
                    inConsultas>>medic_cant;
                    i.actualizar(paciente.GetFechaUltimaConsulta(),
                        medic_cant);
                    aux=inConsultas.get();
                    if (aux == '\n') break;
                }

                break;
            }
        }
        
        if(indice==0){
            //no encontro
            while (1) {
                inConsultas>>medic_cant;
                class Paciente_Medicina pac_medicina;
                pac_medicina.insertarPaciente(paciente,medic_cant);
                paciente_medicina.push_back(pac_medicina);
                aux=inConsultas.get();
                if (aux == '\n') return ;
            }
            
        }
        
    }
    if(indice==0){
            // estaba vacio
            while (1) {
                inConsultas>>medic_cant;
                class Paciente_Medicina pac_medicina;
                pac_medicina.insertarPaciente(paciente,medic_cant);
                paciente_medicina.push_back(pac_medicina);
                aux=inConsultas.get();
                if (aux == '\n') return;
            }
            
    }
    
    /*while (1) {
        inConsultas>>medic_cant;
        if(indice==1){
            encontrado.actualizar(paciente.GetFechaUltimaConsulta(),
                        medic_cant);
        }
        else{
            //no lo encontre al paciente o simplemente esta vacio la lista
            class Paciente_Medicina pac_medicina;
            pac_medicina.insertarPaciente(paciente,medic_cant);
            paciente_medicina.push_back(pac_medicina);
            
        }
        //actualizar(paciente,medic_cant);
        aux=inConsultas.get();
        if (aux == '\n') break;
        
    }*/

}

/*void ServicioDeSalud::actualizar(class Paciente &paciente,
         class Medicina_Cantidad & medic_cant){
    
    if(paciente_medicina.size()!=0){
        for(Paciente_Medicina i:paciente_medicina){
            
            if(i==(paciente.GetDni())){
                //se repite paciente
                i.actualizar(paciente.GetFechaUltimaConsulta(),
                        medic_cant);
                return ;
            }
            
        }
        
        //no se repite paciente
        class Paciente_Medicina pac_medicina;
        pac_medicina.insertarPaciente(paciente,medic_cant);
        paciente_medicina.push_back(pac_medicina);
    }
    else{
        class Paciente_Medicina pac_medicina;
        pac_medicina.insertarPaciente(paciente,medic_cant);
        paciente_medicina.push_back(pac_medicina);
        
    }
    
    
    
}*/


void ServicioDeSalud::totalizar (){
    
    for(Paciente_Medicina i:paciente_medicina){
        i.totalizar(medicina);
    }
    
    
}
void ServicioDeSalud::imprimePacientes (const char* cadena){
    ofstream outReporte(cadena,ios::out);
    if (!outReporte) {
        cout<<"error al abrir el archivo";
        exit(1);
    }
    outReporte<<fixed;
    outReporte<<setprecision(2);
    
    outReporte<<"Pacientes"<<endl;
    for(Paciente_Medicina i:paciente_medicina){
            
        i.imprimir(outReporte);  
            
    }
    
    
    outReporte.close();
}
