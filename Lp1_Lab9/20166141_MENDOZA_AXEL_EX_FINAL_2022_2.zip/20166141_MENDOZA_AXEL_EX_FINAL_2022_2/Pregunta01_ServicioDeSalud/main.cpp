/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: alulab14
 *
 * Created on 15 de noviembre de 2023, 05:04 PM
 */

#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>
#include "ServicioDeSalud.h"

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    
    class ServicioDeSalud servicioDeSalud;
    servicioDeSalud.leerMedicinas("Medicinas-Preg01.csv");
    servicioDeSalud.imprimirMedicinas("PruebaMedicinas.txt");
    servicioDeSalud.leerConsultas("Consultas-Preg01.csv");
    servicioDeSalud.imprimePacientes("PruebaConsultas.txt");
    servicioDeSalud.totalizar();
    servicioDeSalud.imprimePacientes("PruebaConsultasTotal.txt");
    
    
    
    
    return 0;
}

