/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Medicina_Cantidad.cpp
 * Author: alulab14
 * 
 * Created on 15 de noviembre de 2023, 05:07 PM
 */

#include "Medicina_Cantidad.h"

Medicina_Cantidad::Medicina_Cantidad() {
}

Medicina_Cantidad::Medicina_Cantidad(const Medicina_Cantidad& orig) {
}

Medicina_Cantidad::~Medicina_Cantidad() {
}

void Medicina_Cantidad::imprimeMedicina(ofstream & out) const{
    
    out<<fixed;
    out<<setprecision(2);
    out<<setw(5)<<getCodigo()<<setw(5)<<getCantidad()<<endl;
    
}

void Medicina_Cantidad::setCodigo(int codigo) {
    this->codigo = codigo;
}

int Medicina_Cantidad::getCodigo() const {
    return codigo;
}

void Medicina_Cantidad::setCantidad(int cantidad) {
    this->cantidad = cantidad;
}

int Medicina_Cantidad::getCantidad() const {
    return cantidad;
}


void operator >>(ifstream & in,
        class Medicina_Cantidad & medicina_cantidad){
    int cod,cant;
    char aux;
    in>>cod>>aux>>cant;
    medicina_cantidad.setCantidad(cant);
    medicina_cantidad.setCodigo(cod);
    
    
}