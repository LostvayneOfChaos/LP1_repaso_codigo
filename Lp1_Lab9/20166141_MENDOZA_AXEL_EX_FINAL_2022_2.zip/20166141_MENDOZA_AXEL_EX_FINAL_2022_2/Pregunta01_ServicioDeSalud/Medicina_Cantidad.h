/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Medicina_Cantidad.h
 * Author: alulab14
 *
 * Created on 15 de noviembre de 2023, 05:07 PM
 */
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>
#ifndef MEDICINA_CANTIDAD_H
#define MEDICINA_CANTIDAD_H

#include <fstream>


using namespace std;

class Medicina_Cantidad {
public:
    Medicina_Cantidad();
    Medicina_Cantidad(const Medicina_Cantidad& orig);
    virtual ~Medicina_Cantidad();
    void imprimeMedicina(ofstream &) const;
    void setCodigo(int codigo);
    int getCodigo() const;
    void setCantidad(int cantidad);
    int getCantidad() const;
private:
    int cantidad;
    int codigo;
};

void operator >>(ifstream &, class Medicina_Cantidad &);


#endif /* MEDICINA_CANTIDAD_H */

