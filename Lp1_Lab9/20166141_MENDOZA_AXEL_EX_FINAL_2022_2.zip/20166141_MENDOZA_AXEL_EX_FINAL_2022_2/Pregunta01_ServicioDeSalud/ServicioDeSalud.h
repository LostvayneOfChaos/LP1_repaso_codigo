/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ServicioDeSalud.h
 * Author: alulab14
 *
 * Created on 15 de noviembre de 2023, 05:07 PM
 */

#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>
#include <map>
#include <list>
#include "Medicina.h"
#include "Paciente_Medicina.h"
using namespace std;
#ifndef SERVICIODESALUD_H
#define SERVICIODESALUD_H

class ServicioDeSalud {
public:
    ServicioDeSalud();
    ServicioDeSalud(const ServicioDeSalud& orig);
    virtual ~ServicioDeSalud();
    void leerMedicinas (const char*);
    void imprimirMedicinas (const char*);
    void leerConsultas (const char*);
    void totalizar ();
    void imprimePacientes (const char*);
    void leerListaMedicamentos(ifstream &inConsultas,
        class Paciente &paciente);
    void actualizar(class Paciente &paciente,
         class Medicina_Cantidad & medic_cant);
private:
    map<int,Medicina>medicina;
    list<Paciente_Medicina>paciente_medicina;
};

#endif /* SERVICIODESALUD_H */

