/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Paciente_Medicina.cpp
 * Author: alulab14
 * 
 * Created on 15 de noviembre de 2023, 05:07 PM
 */

#include "Paciente_Medicina.h"

Paciente_Medicina::Paciente_Medicina() {
    totalDeGastos=0;
}

void Paciente_Medicina::setTotalDeGastos(double totalDeGastos) {
    this->totalDeGastos = totalDeGastos;
}

double Paciente_Medicina::getTotalDeGastos() const {
    return totalDeGastos;
}

Paciente_Medicina::Paciente_Medicina(const Paciente_Medicina& orig) {
    *this=orig;
    totalDeGastos=0;
}

Paciente_Medicina::~Paciente_Medicina() {
}

bool Paciente_Medicina::operator ==(int dniPaciente){
    
    if (paciente.GetDni() == dniPaciente) {
        return true;
    }
    else 
        return false;
    
    
}


void Paciente_Medicina::insertarPaciente(class Paciente & paciente,
        class Medicina_Cantidad & medic_cant){
    
    this->paciente=paciente;
    setTotalDeGastos(0);
    //aca ya se sobreeentiende que al menos hay una medicina
    if(medicina_cantidad.size()!=0){
        for(Medicina_Cantidad i:medicina_cantidad){
            if(i.getCodigo()==(medic_cant.getCodigo())){
                //se repite medicina
                int cant=i.getCantidad();
                i.setCantidad(cant+(medic_cant.getCantidad()));
                return ;
            }
            
        }
        //no se repite medicina
        medicina_cantidad.push_back(medic_cant);

    }
    
    
    //insertar medicina
    else medicina_cantidad.push_back(medic_cant);
    
    
    
}


void Paciente_Medicina::actualizar(int fecha,
        class Medicina_Cantidad &medic_cant){
    //se repite paciente
    paciente.SetFechaUltimaConsulta(fecha);
    
    for(Medicina_Cantidad i:medicina_cantidad){
            if(i.getCodigo()==(medic_cant.getCodigo())){
                //se repite medicina
                int cant=i.getCantidad();
                i.setCantidad(cant+(medic_cant.getCantidad()));
                return ;
            }
            
    }
    //no se repite medicina
    
    medicina_cantidad.push_back(medic_cant);
}



void Paciente_Medicina::totalizar(map<int, Medicina> med){
    
    double precio;
    for (Medicina_Cantidad i : medicina_cantidad) {
        precio=-1;
        //precio=HallarPrecio(i.getCodigo(),med);
        for (map<int, Medicina>::iterator it=med.begin(); it!=med.end();it++){
            if(((it->second).GetCodigo())==i.getCodigo()){
                precio=(it->second).GetPrecio();
                break;
            }
        }
        
        if(precio != -1){
            //encontro precio
            setTotalDeGastos(getTotalDeGastos()+ (precio* i.getCantidad()));
        }
        
    }

}


void Paciente_Medicina::imprimir(ofstream & out ){
    
    
    char nombre[50];
    paciente.GetNombre(nombre);
    out<<setw(10)<<paciente.GetDni()<<setw(30)<<nombre<<setw(20)
            <<paciente.GetFechaUltimaConsulta()<<endl;
    out<<"Medicinas"<<endl;
    for(Medicina_Cantidad i:medicina_cantidad){
        i.imprimeMedicina(out);
    }
    out<<"Total de gastos : "<< setw(4)<<getTotalDeGastos()<<endl;
    
    out<<"------------------------------------------- "<<endl;
}  


void Paciente_Medicina::operator =(const Paciente_Medicina& orig){
    
    
    
    
    
}