/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   NProductos.cpp
 * Author: AXEL
 * 
 * Created on 16 de noviembre de 2023, 02:35 PM
 */

#include "NProductos.h"

NProductos::NProductos() {
}

NProductos::NProductos(const NProductos& orig) {
    *this=orig;
    
}

NProductos::~NProductos() {
}

void NProductos::asignarCategoria1(){
    prod=new class Categoria1;
}

void NProductos::asignarCategoria2(){
    prod=new class Categoria2;
}

void NProductos::asignarCategoria3(){
    prod=new class Categoria3;
}

void NProductos::leerDatos(ifstream &inProd){
    
    prod->leer(inProd);
    
}


int NProductos::obtenerPrioridad(){
    
    return(prod->sacarPrioridad());
}
int NProductos::obtenerCodigo(){
    return(prod->getCodprod());
    
}

void NProductos::operator=(const NProductos& orig){
    this->prod=orig.prod;
    
    
}


void NProductos::imprimirProd(ofstream &out){
    
    prod->imprime(out);

}