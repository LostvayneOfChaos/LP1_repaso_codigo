/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   NProductos.h
 * Author: AXEL
 *
 * Created on 16 de noviembre de 2023, 02:35 PM
 */
#include<fstream>
#include<iostream>
#include<iomanip>
#include<cstring>
using namespace std;
#ifndef NPRODUCTOS_H
#define NPRODUCTOS_H
#include "Producto.h"
#include "Categoria1.h"
#include "Categoria2.h"
#include "Categoria3.h"
class NProductos {
public:
    NProductos();
    NProductos(const NProductos& orig);
    virtual ~NProductos();
    void leerDatos(ifstream &inProd);
    void asignarCategoria1();
    void asignarCategoria2();
    void asignarCategoria3();
    int obtenerPrioridad();
    int obtenerCodigo();
    void imprimirProd(ofstream &);
    void operator=(const NProductos& orig);
private:
    class Producto* prod;
};

#endif /* NPRODUCTOS_H */

