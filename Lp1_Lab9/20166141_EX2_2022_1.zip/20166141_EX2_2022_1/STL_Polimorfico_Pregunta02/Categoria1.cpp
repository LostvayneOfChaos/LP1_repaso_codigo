/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Categoria1.cpp
 * Author: AXEL
 * 
 * Created on 16 de noviembre de 2023, 02:33 PM
 */

#include "Categoria1.h"

Categoria1::Categoria1() {
}

void Categoria1::setMinimo(int minimo) {
    this->minimo = minimo;
}

int Categoria1::getMinimo() const {
    return minimo;
}

void Categoria1::setPrioridad(int prioridad) {
    this->prioridad = prioridad;
}

int Categoria1::getPrioridad() const {
    return prioridad;
}

Categoria1::Categoria1(const Categoria1& orig) {
}

Categoria1::~Categoria1() {
}

void Categoria1::leer(ifstream & in){
    int prioridad,minimo;
    char aux;
    in>>prioridad>>aux>>minimo>>aux;
    setPrioridad(prioridad);
    setMinimo(minimo);
    Producto::leer(in);
}
void Categoria1::imprime(ofstream & out){
    
    out<<setw(10)<<getPrioridad()
            <<setw(10)<<getMinimo();
    Producto::imprime(out);
}


int Categoria1::sacarPrioridad(){
    
    return(getPrioridad());
}