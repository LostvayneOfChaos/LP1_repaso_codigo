/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Categoria1.h
 * Author: AXEL
 *
 * Created on 16 de noviembre de 2023, 02:33 PM
 */
#include<fstream>
#include<iostream>
#include<iomanip>
#include<cstring>
using namespace std;
#ifndef CATEGORIA1_H
#define CATEGORIA1_H

#include "Producto.h"


class Categoria1:public Producto {
public:
    Categoria1();
    Categoria1(const Categoria1& orig);
    virtual ~Categoria1();
     void leer(ifstream &);
     void imprime(ofstream &);
     void setMinimo(int minimo);
     int getMinimo() const;
     void setPrioridad(int prioridad);
     int getPrioridad() const;
     int sacarPrioridad();
private:
    int prioridad;
    int minimo;
    
    
    
};

#endif /* CATEGORIA1_H */

