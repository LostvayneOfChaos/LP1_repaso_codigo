/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Categoria2.cpp
 * Author: AXEL
 * 
 * Created on 16 de noviembre de 2023, 02:34 PM
 */

#include "Categoria2.h"

Categoria2::Categoria2() {
}

void Categoria2::setDescuento(double descuento) {
    this->descuento = descuento;
}

double Categoria2::getDescuento() const {
    return descuento;
}

void Categoria2::setPrioridad(int prioridad) {
    this->prioridad = prioridad;
}

int Categoria2::getPrioridad() const {
    return prioridad;
}

Categoria2::Categoria2(const Categoria2& orig) {
}

Categoria2::~Categoria2() {
}

void Categoria2::leer(ifstream & in){
    int prioridad;
    double descuento;
    char aux;
    in>>prioridad>>aux>>descuento>>aux;
    setPrioridad(prioridad);
    setDescuento(descuento);
    Producto::leer(in);
    
    
}
void Categoria2::imprime(ofstream & out){
    out<<fixed;
    out<<setprecision(2);
    out<<setw(10)<<getPrioridad()
            <<setw(10)<<getDescuento();
    Producto::imprime(out);
}


int Categoria2::sacarPrioridad(){
    
    return(getPrioridad());
}