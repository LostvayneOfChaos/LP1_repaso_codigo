/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Programa.cpp
 * Author: AXEL
 * 
 * Created on 16 de noviembre de 2023, 02:38 PM
 */

#include "Programa.h"
#include "Pedido.h"

Programa::Programa() {
}

Programa::Programa(const Programa& orig) {
}

Programa::~Programa() {
}

void Programa::cargaProductos(const char * cadena){
    
    ifstream inProd(cadena,ios::in);
    if (!inProd) {
        cout<<"error al abrir el archivo";
        exit(1);
        
    }
    int categoria;
    char aux;
    while (1) {
        class NProductos prod;
        inProd>>categoria>>aux;
        if(inProd.eof()) break;
        if(categoria==1)
            prod.asignarCategoria1();
        if(categoria==2)
            prod.asignarCategoria2();
        if(categoria==3)
            prod.asignarCategoria3();
        
        prod.leerDatos(inProd);
        vproductos.push_back(prod);
        
    }
    inProd.close();
}
void Programa::cargaLista(const char * cadena){
    
    ifstream inPedidos(cadena,ios::in);
    if (!inPedidos) {
        cout<<"error al abrir el archivo";
        exit(1);
        
    }
    char aux;
    int codigo,cant,dni,fecha,dia,mes,anio;
    double monto;
    while (1) {
        class Pedido ped;
        inPedidos>>codigo>>aux;
        if(inPedidos.eof()) break;
        inPedidos>>cant>>aux>>monto>>aux>>dni>>aux>>
                dia>>aux>>mes>>aux>>anio;
        ped.SetCantidad(cant);
        ped.SetTotal(monto);
        ped.SetCodigo(codigo);
        ped.SetDni(dni);
        fecha=anio*10000+mes*100+dia;
        ped.SetFecha(fecha);
        lpedidos.insertarPedido(ped);
        
    }
    
    inPedidos.close();
    
    
}
void Programa::actualiza(){
    
    lpedidos.actualizarPedidos(vproductos);    
    
    
    
}
void Programa::muestra(const char * cadena){
    
    ofstream outReporte(cadena,ios::out);
    if (!outReporte) {
        cout<<"error al abrir el archivo";
        exit(1);
        
    }
    outReporte<<"Pedidos"<<endl;
    imprimeLista(outReporte);
    outReporte<<"Productos"<<endl;
    imprimeProductos(outReporte);
    
    
    
    
    
    
    
    outReporte.close();
    
}
void Programa::imprimeProductos(ofstream & out){
    
    
    for (class NProductos i: vproductos) {
        i.imprimirProd(out);
        out<<endl;
    }

}
void Programa::imprimeLista(ofstream & out){
    
    lpedidos.imprimir(out);
    
    
}
