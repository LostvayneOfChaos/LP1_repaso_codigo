/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Categoria3.cpp
 * Author: AXEL
 * 
 * Created on 16 de noviembre de 2023, 02:35 PM
 */

#include "Categoria3.h"

Categoria3::Categoria3() {
}

void Categoria3::setDescuento(double descuento) {
    this->descuento = descuento;
}

double Categoria3::getDescuento() const {
    return descuento;
}

void Categoria3::setPrioridad(int prioridad) {
    this->prioridad = prioridad;
}

int Categoria3::getPrioridad() const {
    return prioridad;
}

Categoria3::Categoria3(const Categoria3& orig) {
}

Categoria3::~Categoria3() {
}

void Categoria3::leer(ifstream & in){
    int prioridad;
    double descuento;
    char aux;
    in>>prioridad>>aux>>descuento>>aux;
    setPrioridad(prioridad);
    setDescuento(descuento);
    Producto::leer(in);
    
    
}
void Categoria3::imprime(ofstream & out){
    out<<fixed;
    out<<setprecision(2);
    out<<setw(10)<<getPrioridad()
            <<setw(10)<<getDescuento();
    Producto::imprime(out);
    
}

int Categoria3::sacarPrioridad(){
    
    return(getPrioridad());
}