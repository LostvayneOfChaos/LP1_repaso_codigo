/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Producto.h
 * Author: AXEL
 *
 * Created on 16 de noviembre de 2023, 02:32 PM
 */
#include<fstream>
#include<iostream>
#include<iomanip>
#include<cstring>
using namespace std;
#ifndef PRODUCTO_H
#define PRODUCTO_H

class Producto {
public:
    Producto();
    Producto(const Producto& orig);
    virtual ~Producto();
    virtual void leer(ifstream &);
    virtual void imprime(ofstream &);
    void setStock(int stock);
    int getStock() const;
    void setNombre(char* nombre);
    void getNombre(char* cadena) const;
    void setCodprod(int codprod);
    int getCodprod() const;
    virtual int sacarPrioridad()=0;
private:
    int codprod;
    char* nombre;
    int stock;
    
    
};

#endif /* PRODUCTO_H */

