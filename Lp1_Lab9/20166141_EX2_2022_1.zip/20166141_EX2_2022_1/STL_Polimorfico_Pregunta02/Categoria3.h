/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Categoria3.h
 * Author: AXEL
 *
 * Created on 16 de noviembre de 2023, 02:35 PM
 */
#include<fstream>
#include<iostream>
#include<iomanip>
#include<cstring>
using namespace std;
#ifndef CATEGORIA3_H
#define CATEGORIA3_H

#include "Producto.h"


class Categoria3:public Producto {
public:
    Categoria3();
    Categoria3(const Categoria3& orig);
    virtual ~Categoria3();
     void leer(ifstream &);
     void imprime(ofstream &);
     void setDescuento(double descuento);
     double getDescuento() const;
     void setPrioridad(int prioridad);
     int getPrioridad() const;
     int sacarPrioridad();
private:
    int prioridad;
    double descuento;
    
    
};

#endif /* CATEGORIA3_H */

