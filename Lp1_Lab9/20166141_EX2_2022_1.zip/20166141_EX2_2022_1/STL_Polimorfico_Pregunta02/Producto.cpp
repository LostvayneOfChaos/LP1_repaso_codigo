/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Producto.cpp
 * Author: AXEL
 * 
 * Created on 16 de noviembre de 2023, 02:32 PM
 */

#include "Producto.h"

Producto::Producto() {
    nombre=nullptr;
    
}

void Producto::setStock(int stock) {
    this->stock = stock;
}

int Producto::getStock() const {
    return stock;
}

void Producto::setNombre(char* nombre) {
    if(this->nombre!=nullptr) delete(this->nombre);
    this->nombre=new char[strlen(nombre)+1];
    strcpy(this->nombre,nombre);
    
}

void Producto::getNombre(char* cadena) const {
    if(nombre ==nullptr) cadena[0]=0;
    strcpy(cadena,nombre);
    
    
}

void Producto::setCodprod(int codprod) {
    this->codprod = codprod;
}

int Producto::getCodprod() const {
    return codprod;
}

Producto::Producto(const Producto& orig) {
}

Producto::~Producto() {
}


void Producto::leer(ifstream & in){
    char aux;
    int codigo,stock;
    char nombre[50];
    in>>codigo>>aux;
    in.getline(nombre,50,',');
    in>>stock;
    in.get();
    setCodprod(codigo);
    setNombre(nombre);
    setStock(stock);
    
    
}
void Producto::imprime(ofstream & out){
    char cadena[50];
    getNombre(cadena);
    out<<fixed;
    out<<setprecision(2);
    out<<setw(10)<<getCodprod()
            <<setw(40)<<cadena
            <<setw(10)<<getStock();
    
    
    
    
}

