/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Pedido.h
 * Author: AXEL
 *
 * Created on 16 de noviembre de 2023, 02:31 PM
 */
#include<fstream>
#include<iostream>
#include<iomanip>
#include<cstring>
using namespace std;
#ifndef PEDIDO_H
#define PEDIDO_H

class Pedido {
public:
    Pedido();
    Pedido(const Pedido& orig);
    virtual ~Pedido();
    void SetOrden(int orden);
    int GetOrden() const;
    void SetTotal(double total);
    double GetTotal() const;
    void SetFecha(int fecha);
    int GetFecha() const;
    void SetDni(int dni);
    int GetDni() const;
    void SetCantidad(int cantidad);
    int GetCantidad() const;
    void SetCodigo(int codigo);
    int GetCodigo() const;
    void imprimirPed(ofstream &);
private:
    int codigo;
    int cantidad;
    int dni;
    int fecha;
    double total;
    int orden;
    
    
};

#endif /* PEDIDO_H */

