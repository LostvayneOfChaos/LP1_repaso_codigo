/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Programa.h
 * Author: AXEL
 *
 * Created on 16 de noviembre de 2023, 02:38 PM
 */
#include<fstream>
#include<iostream>
#include<iomanip>
#include<cstring>
using namespace std;
#ifndef PROGRAMA_H
#define PROGRAMA_H
#include <vector>
#include "Lista.h"
#include "NProductos.h"
class Programa {
public:
    Programa();
    Programa(const Programa& orig);
    virtual ~Programa();
    void cargaProductos(const char * cadena);
    void cargaLista(const char * cadena);
    void actualiza();
    void muestra(const char * cadena);
    void imprimeProductos(ofstream &);
    void imprimeLista(ofstream &);
private:
    class Lista lpedidos;
    vector<class NProductos> vproductos;
};

#endif /* PROGRAMA_H */

