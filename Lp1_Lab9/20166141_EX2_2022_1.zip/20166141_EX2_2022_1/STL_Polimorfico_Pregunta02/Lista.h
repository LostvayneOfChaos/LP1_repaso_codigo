/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Lista.h
 * Author: AXEL
 *
 * Created on 16 de noviembre de 2023, 02:37 PM
 */
#include<fstream>
#include<iostream>
#include<iomanip>
#include<cstring>
using namespace std;
#ifndef LISTA_H
#define LISTA_H
#include "Nodo.h"
#include <vector>
#include "NProductos.h"
class Lista {
public:
    Lista();
    Lista(const Lista& orig);
    virtual ~Lista();
    void insertarPedido(class Pedido &ped);
    int buscarPrioridad(int ,vector<class NProductos> &
                        );
    void actualizarPedidos(vector<class NProductos> & vproductos); 
    void imprimir(ofstream &);
private:
    class Nodo*lini;
    class Nodo*lfin;
    
    
};

#endif /* LISTA_H */

