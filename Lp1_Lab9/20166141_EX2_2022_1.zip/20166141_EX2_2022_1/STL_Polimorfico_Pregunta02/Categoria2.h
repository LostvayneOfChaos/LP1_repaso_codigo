/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Categoria2.h
 * Author: AXEL
 *
 * Created on 16 de noviembre de 2023, 02:34 PM
 */
#include<fstream>
#include<iostream>
#include<iomanip>
#include<cstring>
using namespace std;
#ifndef CATEGORIA2_H
#define CATEGORIA2_H

#include "Producto.h"


class Categoria2:public Producto {
public:
    Categoria2();
    Categoria2(const Categoria2& orig);
    virtual ~Categoria2();
     void leer(ifstream &);
     void imprime(ofstream &);
     void setDescuento(double descuento);
     double getDescuento() const;
     void setPrioridad(int prioridad);
     int getPrioridad() const;
     int sacarPrioridad();
private:
    int prioridad;
    double descuento;
    
    
};

#endif /* CATEGORIA2_H */

