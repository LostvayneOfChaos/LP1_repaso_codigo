/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Lista.cpp
 * Author: AXEL
 * 
 * Created on 16 de noviembre de 2023, 02:37 PM
 */

#include "Lista.h"
#include "Pedido.h"
#include "NProductos.h"

Lista::Lista() {
    lfin=nullptr;
    lini=nullptr;
}

Lista::Lista(const Lista& orig) {
}

Lista::~Lista() {
}

void Lista::insertarPedido(class Pedido &pedido){
    class Nodo* ptr= this->lini;
    class Nodo* ant=nullptr;
    class Nodo* nuevo;
    nuevo=new class Nodo;
    nuevo->ped=new class Pedido;
    nuevo->insertarDatos(pedido);
    while (ptr) {
        int fechaRecorrido=ptr->ped->GetFecha();
        if(fechaRecorrido >(pedido.GetFecha()))
            break;
        ant=ptr;
        ptr=ptr->sig;
        
    }
    nuevo->sig=ptr;
    if(ant!=nullptr) ant->sig=nuevo;
    else {
        lini=nuevo;
        lfin=nuevo;
    }
}


void Lista::actualizarPedidos(vector<class NProductos> &
                        vproductos){
    
    class Nodo* ptr= this->lini->sig;
    class Nodo*recorre;
    class Nodo*actual;
    class Nodo*ant=this->lini;
    while (ptr) {
        int codigo=ptr->ped->GetCodigo();
        int prioridad;
        prioridad=buscarPrioridad(codigo,vproductos);
        ptr->ped->SetOrden(prioridad);
        if (prioridad==1) {
            recorre=ptr->sig;
            ant->sig=ptr->sig;
            ptr->sig=lini;
            lini=ptr;
            ant=ant;
            ptr=recorre;
        }
        else{
            ant=ptr;
            ptr=ptr->sig;
        }
        
    }
    lfin=ant;
}


int Lista::buscarPrioridad(int codigo,vector<class NProductos> &
                        vproductos){
    for (class NProductos i: vproductos){
        if(i.obtenerCodigo()==codigo){
            return(i.obtenerPrioridad());
        }
    }

    //aca deberia colocar si no hay prioridad
    
}


void Lista::imprimir(ofstream & out){
    
    class Nodo* ptr=lini;
    while (ptr) {
        ptr->ped->imprimirPed(out);
        ptr=ptr->sig;
        out<<endl;
    }

    
}