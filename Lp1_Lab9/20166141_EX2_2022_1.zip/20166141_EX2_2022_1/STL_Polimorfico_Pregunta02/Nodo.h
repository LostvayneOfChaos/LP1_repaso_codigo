/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Nodo.h
 * Author: AXEL
 *
 * Created on 16 de noviembre de 2023, 02:36 PM
 */
#include<fstream>
#include<iostream>
#include<iomanip>
#include<cstring>
using namespace std;
#ifndef NODO_H
#define NODO_H
#include "Pedido.h"
class Nodo {
public:
    Nodo();
    Nodo(const Nodo& orig);
    virtual ~Nodo();
    friend class Lista;
    void insertarDatos(class Pedido& );
private:
    class Pedido* ped;
    class Nodo* sig;
    
};

#endif /* NODO_H */

