/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Camion.cpp
 * Author: AXEL
 * 
 * Created on 4 de diciembre de 2023, 08:26 PM
 */

#include "Camion.h"

Camion::Camion() {
    
}

Camion::Camion(const Camion& orig) {
    *this=orig;
}

Camion::~Camion() {
}

void Camion::SetLlantas(int llantas) {
    this->llantas = llantas;
}

int Camion::GetLlantas() const {
    return llantas;
}

void Camion::SetEjes(int ejes) {
    this->ejes = ejes;
}

int Camion::GetEjes() const {
    return ejes;
}


void Camion::leer(ifstream & inVehiculos){
    Vehiculo::leer(inVehiculos);
    int EJE,LLANTA;
    char aux;
    inVehiculos>>EJE>>aux>>LLANTA;
    inVehiculos.get();
    
    SetEjes(EJE);
    SetLlantas(LLANTA);
    
}
void Camion::imprimir(ofstream & out){
    
    Vehiculo::imprimir(out);
    out<<setw(30)<<"#Ejes: " <<GetEjes()<<endl;
    out<<setw(30)<<"#Llantas: " <<GetLlantas()<<endl;
    out<<setw(30)<<"Pedidos: "<<endl;
    if((mdeposito.size())==0){
        out<<setw(50)<<"No hay pedidos para el cliente "<<endl;
        out<<endl;
    }
    
}

