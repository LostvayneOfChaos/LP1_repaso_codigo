/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   NPedido.h
 * Author: AXEL
 *
 * Created on 4 de diciembre de 2023, 08:26 PM
 */
#include <cstring>
#include <fstream>
#include <iostream>
#include <iomanip>

using namespace std;
#ifndef NPEDIDO_H
#define NPEDIDO_H

class NPedido {
public:
    NPedido();
    NPedido(const NPedido& orig);
    virtual ~NPedido();
    void SetPeso(double peso);
    double GetPeso() const;
    void SetCantidad(int cantidad);
    int GetCantidad() const;
    void SetCodigo(char* codigo);
    void GetCodigo(char*) const;
private:
    char*codigo;
    int cantidad;
    double peso;
};

#endif /* NPEDIDO_H */

