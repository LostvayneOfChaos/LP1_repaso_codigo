/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   NVehiculo.cpp
 * Author: AXEL
 * 
 * Created on 4 de diciembre de 2023, 08:26 PM
 */

#include "NVehiculo.h"
#include "Camion.h"
#include "Furgon.h"

NVehiculo::NVehiculo() {
}

NVehiculo::NVehiculo(const NVehiculo& orig) {
    *this=orig;
}

NVehiculo::~NVehiculo() {
}


void NVehiculo::asignarFurgon(){
    unidad=new class Furgon;
    
    
}
void NVehiculo::asignarCamion(){
    
    unidad=new class Camion;
}
void NVehiculo::leerDatos(ifstream & inVehiculos){
    
    unidad->leer(inVehiculos);
    
}

void NVehiculo::imprimirDatos(ofstream &outVehiculos){
    unidad->imprimir(outVehiculos);
}