/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Vehiculo.cpp
 * Author: AXEL
 * 
 * Created on 4 de diciembre de 2023, 08:26 PM
 */

#include "Vehiculo.h"

Vehiculo::Vehiculo() {
    placa=nullptr;
    actcarga=0;
}

Vehiculo::Vehiculo(const Vehiculo& orig) {
    *this=orig;
}

Vehiculo::~Vehiculo() {
}

void Vehiculo::SetActcarga(double actcarga) {
    this->actcarga = actcarga;
}

double Vehiculo::GetActcarga() const {
    return actcarga;
}

void Vehiculo::SetMaxcarga(double maxcarga) {
    this->maxcarga = maxcarga;
}

double Vehiculo::GetMaxcarga() const {
    return maxcarga;
}

void Vehiculo::SetCliente(int cliente) {
    this->cliente = cliente;
}

int Vehiculo::GetCliente() const {
    return cliente;
}

void Vehiculo::SetPlaca(char* placa) {
    if(this->placa !=nullptr) delete(this->placa);
    this->placa=new char[strlen(placa)+1];
    strcpy(this->placa,placa);
}

void Vehiculo::GetPlaca(char* cadena) const {
    if(placa ==nullptr) cadena[0]=0;
    strcpy(cadena,placa);
    
}


void Vehiculo::leer(ifstream & inVehiculos){
    inVehiculos.get();
    int cod;
    char buffer[20],aux;
    double max;
    inVehiculos>>cod>>aux;
    inVehiculos.getline(buffer,20,',');
    inVehiculos>>max>>aux;
    SetCliente(cod);
    SetMaxcarga(max);
    SetPlaca(buffer);
    
}
void Vehiculo::imprimir(ofstream & out){
    out<<fixed;
    out<<setprecision(2);
    char PLACA[10];
    GetPlaca(PLACA);
    out<<setw(30)<<"Codigo Cliente: " <<GetCliente()<<endl;
    out<<setw(30)<<"Placa: " <<PLACA<<endl;
    out<<setw(30)<<"Carga Maxima: " <<GetMaxcarga()<<endl;
    out<<setw(30)<<"Carga Actual: " <<GetActcarga()<<endl;
    
    
}
