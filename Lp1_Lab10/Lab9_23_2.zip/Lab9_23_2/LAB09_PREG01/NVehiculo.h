/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   NVehiculo.h
 * Author: AXEL
 *
 * Created on 4 de diciembre de 2023, 08:26 PM
 */
#include <cstring>
#include <fstream>
#include <iostream>
#include <iomanip>

using namespace std;
#ifndef NVEHICULO_H
#define NVEHICULO_H
#include "Vehiculo.h"

class NVehiculo {
public:
    NVehiculo();
    NVehiculo(const NVehiculo& orig);
    virtual ~NVehiculo();
    void asignarFurgon();
    void asignarCamion();
    void leerDatos(ifstream &);
    void imprimirDatos(ofstream &);
private:
    class Vehiculo* unidad;
};

#endif /* NVEHICULO_H */

