/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Flota.cpp
 * Author: AXEL
 * 
 * Created on 4 de diciembre de 2023, 08:26 PM
 */

#include <vector>

#include "Flota.h"

Flota::Flota() {
}

Flota::Flota(const Flota& orig) {
    *this=orig;
    
}

Flota::~Flota() {
}



void Flota::cargaflota(){
    ifstream inVehiculos("Vehiculos.csv",ios::in);
    if (!inVehiculos) {
        cout<<"error al abrir el archivo";
        exit(1);
    }
    
    while (1) {
        //F,79464412,K0D-676,300,1,3
        //Tipo de Vehículo, Cliente, Placa, Máxima carga, 
        //Filas/Ejes, Puertas/Llanta
        class NVehiculo nvehiculo;
        char tipo;
        tipo=inVehiculos.get();
        //inVehiculos>>tipo;
        if(inVehiculos.eof()) break;
        if(tipo=='F'){
            nvehiculo.asignarFurgon();
        }
        if(tipo=='C'){
            nvehiculo.asignarCamion();
        }
        nvehiculo.leerDatos(inVehiculos);
        vflota.push_back(nvehiculo);
        
        
    }
    inVehiculos.close();
}
void Flota::cargapedidos(){
    
    
    
    
    
}
void Flota::muestracarga(){
    ofstream outVehiculos("ReporteVehiculos.txt",ios::out);
    if (!outVehiculos) {
        cout<<"error al abrir el archivo";
        exit(1);
    }
    
    
    for(NVehiculo v:vflota){
        v.imprimirDatos(outVehiculos);
        
        
    }
    
    
    
    outVehiculos.close();
}
