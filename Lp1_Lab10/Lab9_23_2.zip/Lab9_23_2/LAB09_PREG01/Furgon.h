/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Furgon.h
 * Author: AXEL
 *
 * Created on 4 de diciembre de 2023, 08:26 PM
 */
#include <cstring>
#include <fstream>
#include <iostream>
#include <iomanip>

using namespace std;
#ifndef FURGON_H
#define FURGON_H

#include "Vehiculo.h"
#include "NPedido.h"
#include <list>

class Furgon:public Vehiculo {
public:
    Furgon();
    Furgon(const Furgon& orig);
    virtual ~Furgon();
    void SetPuertas(int puertas);
    int GetPuertas() const;
    void SetFilas(int filas);
    int GetFilas() const;
    void leer(ifstream &);
     void imprimir(ofstream &);
private:
    int filas;
    int puertas;
    list<NPedido> pdeposito;
    
    
};

#endif /* FURGON_H */

