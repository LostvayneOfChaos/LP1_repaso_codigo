/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   NPedido.cpp
 * Author: AXEL
 * 
 * Created on 4 de diciembre de 2023, 08:26 PM
 */

#include "NPedido.h"

NPedido::NPedido() {
    codigo=nullptr;
}

NPedido::NPedido(const NPedido& orig) {
    *this=orig;
}

NPedido::~NPedido() {
}

void NPedido::SetPeso(double peso) {
    this->peso = peso;
}

double NPedido::GetPeso() const {
    return peso;
}

void NPedido::SetCantidad(int cantidad) {
    this->cantidad = cantidad;
}

int NPedido::GetCantidad() const {
    return cantidad;
}

void NPedido::SetCodigo(char* codigo) {
    if(this->codigo !=nullptr) delete(this->codigo);
    this->codigo=new char[strlen(codigo)+1];
    strcpy(this->codigo,codigo);
}

void NPedido::GetCodigo(char* cadena) const {
    if(codigo ==nullptr) cadena[0]=0;
    strcpy(cadena,codigo);
}

void NPedido::leerDatosPedido(ifstream & in){
    char cod[20],aux;
    int cant;
    double PESO;
    in.getline(cod,20,',');
    in>>cant>>aux>>PESO;
    in.get();
    
    SetCantidad(cant);
    SetPeso(PESO);
    SetCodigo(cod);
}

