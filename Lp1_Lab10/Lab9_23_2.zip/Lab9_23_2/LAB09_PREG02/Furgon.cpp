/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Furgon.cpp
 * Author: AXEL
 * 
 * Created on 4 de diciembre de 2023, 08:26 PM
 */

#include "Furgon.h"
#include <iterator>
#include <algorithm>

Furgon::Furgon() {
    
}

Furgon::Furgon(const Furgon& orig) {
    *this=orig;
}

Furgon::~Furgon() {
}

void Furgon::SetPuertas(int puertas) {
    this->puertas = puertas;
}

int Furgon::GetPuertas() const {
    return puertas;
}

void Furgon::SetFilas(int filas) {
    this->filas = filas;
}

int Furgon::GetFilas() const {
    return filas;
}


void Furgon::leer(ifstream & inVehiculos){
    Vehiculo::leer(inVehiculos);
    int FILA,PUERTA;
    char aux;
    inVehiculos>>FILA>>aux>>PUERTA;
    inVehiculos.get();
    
    SetFilas(FILA);
    SetPuertas(PUERTA);
    
    
    
}
void Furgon::imprimir(ofstream & out){
    
    Vehiculo::imprimir(out);
    out<<setw(30)<<"#Filas: " <<GetFilas()<<endl;
    out<<setw(30)<<"#Puertas: " <<GetPuertas()<<endl;
    out<<setw(30)<<"Pedidos: "<<endl;
    int cant=pdeposito.size();
    if(cant==0){
        out<<setw(50)<<"No hay pedidos para el cliente "<<endl;
        out<<endl;
    }
    else{
        for(NPedido x: pdeposito){
            char buffer[20];
            x.GetCodigo(buffer);
            out<<setw(30)<<buffer;
            out<<setw(5)<<x.GetCantidad()
                    <<setw(10)<<x.GetPeso()<<endl;
        }
        
        
    }
    
}


void Furgon::agregar(class NPedido &ped){
    
    if(pdeposito.size()<5){
        int PESO=ped.GetPeso();
        if((PESO+(GetActcarga()))<=(GetMaxcarga())){
            pdeposito.push_back(ped);
            SetActcarga(PESO+(GetActcarga()));
            
        }
            
    }
    
}
