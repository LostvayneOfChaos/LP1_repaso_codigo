/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Flota.h
 * Author: AXEL
 *
 * Created on 4 de diciembre de 2023, 08:26 PM
 */
#include <cstring>
#include <fstream>
#include <iostream>
#include <iomanip>

using namespace std;
#ifndef FLOTA_H
#define FLOTA_H

#include "NVehiculo.h"
#include <vector>
#include <algorithm>
#include <iterator>

class Flota {
public:
    Flota();
    Flota(const Flota& orig);
    virtual ~Flota();
    void cargaflota();
    void cargapedidos();
    void muestracarga();
    
    
private:
    vector<NVehiculo> vflota;
    vector<NVehiculo>::iterator buscarCliente(int);
};

#endif /* FLOTA_H */

