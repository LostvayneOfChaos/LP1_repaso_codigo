/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Vehiculo.h
 * Author: AXEL
 *
 * Created on 4 de diciembre de 2023, 08:26 PM
 */
#include <cstring>
#include <fstream>
#include <iostream>
#include <iomanip>
#include "NPedido.h"
using namespace std;
#ifndef VEHICULO_H
#define VEHICULO_H

class Vehiculo {
public:
    Vehiculo();
    Vehiculo(const Vehiculo& orig);
    virtual ~Vehiculo();
    void SetActcarga(double actcarga);
    double GetActcarga() const;
    void SetMaxcarga(double maxcarga);
    double GetMaxcarga() const;
    void SetCliente(int cliente);
    int GetCliente() const;
    void SetPlaca(char* placa);
    void  GetPlaca(char* ) const;
    virtual void leer(ifstream &);
    virtual void imprimir(ofstream &);
    virtual void agregar(class NPedido &)=0;
private:
    char*placa;
    int cliente;
    double maxcarga;
    double actcarga;
    
};

#endif /* VEHICULO_H */

