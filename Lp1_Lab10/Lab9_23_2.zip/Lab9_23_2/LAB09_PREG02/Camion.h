/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Camion.h
 * Author: AXEL
 *
 * Created on 4 de diciembre de 2023, 08:26 PM
 */
#include <cstring>
#include <fstream>
#include <iostream>
#include <iomanip>

using namespace std;
#ifndef CAMION_H
#define CAMION_H

#include "Vehiculo.h"
#include "NPedido.h"
#include <map>
#include <iterator>
#include <algorithm>


class Camion:public Vehiculo {
public:
    Camion();
    Camion(const Camion& orig);
    virtual ~Camion();
    void SetLlantas(int llantas);
    int GetLlantas() const;
    void SetEjes(int ejes);
    int GetEjes() const;
     void leer(ifstream &);
     void imprimir(ofstream &);
     void agregar(class NPedido &);
private:
    int ejes;
    int llantas;
    map<int,NPedido> mdeposito;
    
    
};

#endif /* CAMION_H */

