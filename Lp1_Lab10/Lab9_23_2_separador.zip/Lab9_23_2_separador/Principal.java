import java.util.ArrayList;
import java.util.Scanner;


class Principal{
	public static void main(String [] args){
		
		Flota unidades= new Flota();
		Scanner arch = new Scanner(System.in);
		unidades.cargaFlota(arch);
		unidades.cargaPedidos(arch);
		unidades.muestraCarga();
		
		
	}
}