import java.util.ArrayList;
import java.util.Scanner;


abstract class Vehiculo{
	private int cliente;
	private String placa;
	private double maxCarga;
	private double actCarga;
	
	public Vehiculo(){
		this.actCarga =0.0;
	}
	
	public int getCliente(){
		return this.cliente;
	}
	
	public void setCliente(int cliente){
		this.cliente=cliente;
	}
	public String getPlaca(){
		return this.placa;
	}
	
	public void setPlaca(String placa){
		this.placa=placa;
	}
	
	public double getMaxCarga(){
		return this.maxCarga;
	}
	
	public void setMaxCarga(double maxCarga){
		this.maxCarga=maxCarga;
	}
	public double getActCarga(){
		return this.actCarga;
	}
	
	public void setActCarga(double actCarga){
		this.actCarga=actCarga;
	}
	
	
	
	public void lee(Scanner arch){
		this.cliente=arch.nextInt();
		this.placa=arch.next();
		this.maxCarga=arch.nextDouble();
	}
	abstract public void cargadeposito(NPedido ped);
	
	public void imprime(){
		System.out.println("Codigo cliente :"+ getCliente());
		System.out.println("Placa :"+ getPlaca());
		System.out.println("Carga Maxima: "+ getMaxCarga());
		System.out.println("Carga Actual:  "+ getActCarga());
	}
	
	
	
	
	
}