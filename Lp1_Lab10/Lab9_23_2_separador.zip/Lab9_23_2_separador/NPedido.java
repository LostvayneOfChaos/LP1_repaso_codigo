import java.util.ArrayList;
import java.util.Scanner;


class NPedido{
	private String codigo;
	private int cantidad;
	private double peso;
	
	
	public int getCantidad(){
		return this.cantidad;
	}
	
	public void setCantidad(int cantidad){
		this.cantidad=cantidad;
	}
	public String getCodigo(){
		return this.codigo;
	}
	
	public void setCodigo(String codigo){
		this.codigo=codigo;
	}
	
	public double getPeso(){
		return this.peso;
	}
	
	public void setPeso(double peso){
		this.peso=peso;
	}
	
	
	public void leerDatos(Scanner arch){
		this.codigo=arch.next();
		this.cantidad=arch.nextInt();
		this.peso=arch.nextDouble();
	}
	
	
	
	
	
	
}