import java.util.ArrayList;
import java.util.Scanner;


class Camion extends Vehiculo{
	private int ejes;
	private int llantas;
	private ArrayList<NPedido> mdeposito;
	
	
	public void setEjes(int ejes){
		this.ejes=ejes;
	}
	public int getEjes(){
		return this.ejes;
	}
	
	public void setLlantas(int llantas){
		this.llantas=llantas;
	}
	public int getLlantas(){
		return this.llantas;
	}
	
	public Camion(){
		mdeposito=new ArrayList<NPedido>();
	}
	
	@Override
	public void lee(Scanner arch){
		super.lee(arch);
		this.ejes=arch.nextInt();
		this.llantas=arch.nextInt();
		
	}
	
	@Override
	public void cargadeposito(NPedido ped){
		double peso=ped.getPeso();
		int num=mdeposito.size();
		if(num<6){
			double max=super.getMaxCarga();
			double actual=super.getActCarga();
			if((actual+peso)<= max){
				mdeposito.add(ped);
				setActCarga(actual+peso);				
			}
		}
	}
	@Override
	public void imprime(){
		super.imprime();
		System.out.println("ejes:"+ getEjes());
		System.out.println("Llantas :"+ getLlantas());
		System.out.println("Lista de Pedidos:: ");
		int i=1;
		for(NPedido ped: mdeposito){
			System.out.println(i + "   "+ ped.getCodigo()
			+ "  "+ ped.getCantidad()
			+ "  "+ ped.getPeso());
			i=i+1;
		}
	}
	
	
	
}