import java.util.ArrayList;
import java.util.Scanner;


class Furgon extends Vehiculo{
	private int filas;
	private int puertas;
	private ArrayList<NPedido> pdeposito;
	
	public void setFilas(int filas){
		this.filas=filas;
	}
	public int getFilas(){
		return this.filas;
	}
	
	public void setPuertas(int puertas){
		this.puertas=puertas;
	}
	public int getPuertas(){
		return this.puertas;
	}
	
	
	
	public Furgon(){
		pdeposito=new ArrayList<NPedido>();
	}
	
	@Override
	public void lee(Scanner arch){
		super.lee(arch);
		this.filas=arch.nextInt();
		this.puertas=arch.nextInt();
	}
	
	@Override
	public void cargadeposito(NPedido ped){
		double peso=ped.getPeso();
		if(pdeposito.size()<6){
			double max=super.getMaxCarga();
			double actual=super.getActCarga();
			if((actual+peso)<= max){
				pdeposito.add(ped);
				setActCarga(actual+peso);				
			}
		}
		
		
	}
	@Override
	public void imprime(){
		super.imprime();
		System.out.println("ejes:"+ getFilas());
		System.out.println("Llantas :"+ getPuertas());
		System.out.println("Lista de Pedidos:: ");
		int i=1;
		for(NPedido ped: pdeposito){
			System.out.println(i + "   "+ ped.getCodigo()
			+ "  "+ ped.getCantidad()
			+ "  "+ ped.getPeso());
			i=i+1;
		}
	}
	
	
	
	
	
}