import java.util.ArrayList;
import java.util.Scanner;


class Flota{
	private ArrayList<Vehiculo> vflota;
	
	
	public Flota(){
		vflota=new ArrayList<Vehiculo>();
	}
	
	public void cargaFlota(Scanner arch ){
		
		while(arch.hasNext()){
			String cadena;
			char tipo;
			cadena=arch.next();
			if(cadena.equals("0")) break;
			tipo=cadena.charAt(0);
			Vehiculo vehiculo;
			if(tipo =='F'){
				vehiculo = new Furgon();
				vehiculo.lee(arch);
				vflota.add(vehiculo);
			}
			if(tipo =='C'){
				vehiculo = new Camion();
				vehiculo.lee(arch);
				vflota.add(vehiculo);
			}
		}
	}
	
	
	public void cargaPedidos(Scanner arch){
		
		
		while(arch.hasNextInt()){
			NPedido ped= new NPedido();
			int cod=arch.nextInt();
			ped.leerDatos(arch);
			for(Vehiculo v: vflota){
				if((v.getCliente())==cod)
					v.cargadeposito(ped);
			}
			
		}
		
	}
	public void muestraCarga(){
		
		//cabecera
		for(Vehiculo v :vflota){
			
			v.imprime();
		}
		
		
	}
	
	
}