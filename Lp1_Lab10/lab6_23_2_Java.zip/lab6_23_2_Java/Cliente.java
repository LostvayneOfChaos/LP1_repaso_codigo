import java.utils.Scanner;
import java.utils.ArrayList;



public class Cliente{	
	private int dni;
	private String nombre;
	private int telefono;
	private ArrayList<ProductoEntregado> productos_entregados;
	private int cantidad_productos_entregados;
	private double monto_total;
	
	public Cliente(){
		productos_entregados=new ArrayList<ProductoEntregado>();
	}
	
	
	
	
	
}