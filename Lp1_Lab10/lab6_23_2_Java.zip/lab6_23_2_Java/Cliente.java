import java.util.Scanner;
import java.util.ArrayList;



public class Cliente{	
	private int dni;
	private String nombre;
	private int telefono;
	private ArrayList<ProductoEntregado> productos_entregados;
	private int cantidad_productos_entregados;
	private double monto_total;
	
	public Cliente(){
		productos_entregados=new ArrayList<ProductoEntregado>();
		monto_total=0;
		cantidad_productos_entregados=0;
	}
	
	public int getDni(){
		return this.dni;
	}
	public void setDni(int dni){
		this.dni=dni;
	}
	public int getTelefono(){
		return this.telefono;
	}
	public void setTelefono(int telefono){
		this.telefono=telefono;
	}
	public String getNombre(){
		return this.nombre;
	}
	public void setNombre(String nombre){
		this.nombre=nombre;
	}
	public int getCantidad_productos_entregados(){
		return this.cantidad_productos_entregados;
	}
	public void setCantidad_productos_entregados(int cantidad_productos_entregados){
		this.cantidad_productos_entregados=cantidad_productos_entregados;
	}
	public double getMonto_total(){
		return this.monto_total;
	}
	public void setMonto_total(double monto_total){
		this.monto_total=monto_total;
	}
	
	
	public void leerCliente(Scanner arch){
		String cadena= arch.next();
		int valor=arch.nextInt();
		setNombre(cadena);
		setTelefono(valor);
	}
	
	public void agregarPed(Pedido ped){
		ProductoEntregado prod=new ProductoEntregado();
		prod.setPrecio(ped.getPrecio_producto());
		prod.setCodigo(ped.getCodigo());
		
		productos_entregados.add(prod);
		int cant= getCantidad_productos_entregados();
		setCantidad_productos_entregados(cant+1);
		double total= ped.getPrecio_producto();
		setMonto_total(getMonto_total()+total);
		
	}
	
	public void imprime(){
		
		System.out.print(dni + "  "+ nombre + "  " + telefono + "  "
		+ monto_total + "  "+ "Productos entregados:  ");
		for(ProductoEntregado p: productos_entregados){
			System.out.print(p.getCodigo() + "  ");
		}
		System.out.println();
	}
	
}