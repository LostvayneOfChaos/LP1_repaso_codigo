import java.util.Scanner;
import java.util.ArrayList;



public class ProductoEntregado{	
	private double precio;
	private String codigo;
	
	public ProductoEntregado(){
		
	}
	
	public double getPrecio(){
		return this.precio;
	}
	public void setPrecio(double precio){
		this.precio=precio;
	}
	public String getCodigo(){
		return this.codigo;
	}
	public void setCodigo(String codigo){
		this.codigo=codigo;
	}
	
	
	
}