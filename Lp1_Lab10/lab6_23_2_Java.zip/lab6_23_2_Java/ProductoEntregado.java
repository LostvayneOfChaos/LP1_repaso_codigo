import java.utils.Scanner;
import java.utils.ArrayList;



public class ProductoEntregado{	
	private double precio;
	private String codigo;
	
	public ProductoEntregado(){
		
	}
	
	
	
	
	
}