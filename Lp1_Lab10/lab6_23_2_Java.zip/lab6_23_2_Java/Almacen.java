import java.utils.Scanner;
import java.utils.ArrayList;



public class Almacen{	
	private int cantidad_clientes;
	private ArrayList<Cliente> arreglo_clientes;
	private ArrayList<Producto> arreglo_productos;
	private int cantidad_productos;
	
	public Almacen(){
		arreglo_clientes=new ArrayList<Cliente>();
		arreglo_productos=new ArrayList<Producto>();
	}
	public int getCantidadClientes(){
		return this.cantidad_clientes;
	}
	public void setCantidadClientes(int cantidad_clientes){
		this.cantidad_clientes=cantidad_clientes;
	}
	public int getCantidadProductos(){
		return this.cantidad_productos;
	}
	public void setCantidadProductos(int cantidad_productos){
		this.cantidad_productos=cantidad_productos;
	}
	
	
	public void cargarClientes(){
		Scanner arch = new Scanner(System.in);
		
		while(arch.hasNext()){
			
			
			
			
			
		}
		
		
		
	}
	public void cargarProductos(){
		
		
		
		
	}
	public void cargarPedidos(){
		
		
		
		
	}
	public void mostrarDatos(){
		
		
		
		
	}
	
	
	
	
	
}