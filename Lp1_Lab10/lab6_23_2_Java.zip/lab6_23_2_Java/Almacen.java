import java.util.Scanner;
import java.util.ArrayList;



public class Almacen{	
	private int cantidad_clientes;
	private ArrayList<Cliente> arreglo_clientes;
	private ArrayList<Producto> arreglo_productos;
	private int cantidad_productos;
	
	public Almacen(){
		cantidad_clientes=0;
		cantidad_productos=0;
		arreglo_clientes=new ArrayList<Cliente>();
		arreglo_productos=new ArrayList<Producto>();
	}
	public int getCantidadClientes(){
		return this.cantidad_clientes;
	}
	public void setCantidadClientes(int cantidad_clientes){
		this.cantidad_clientes=cantidad_clientes;
	}
	public int getCantidadProductos(){
		return this.cantidad_productos;
	}
	public void setCantidadProductos(int cantidad_productos){
		this.cantidad_productos=cantidad_productos;
	}
	
	
	public void cargarClientes(Scanner arch){
		int cantClientes=getCantidadClientes();
		while(arch.hasNextInt()){
			Cliente cliente= new Cliente();
			int dni=arch.nextInt();
			if(dni==-1)
				return;
			cliente.setDni(dni);
			cliente.leerCliente(arch);
			arreglo_clientes.add(cliente);
			cantClientes++;
		}
		setCantidadClientes(cantClientes);
		
	}
	public void cargarProductos(Scanner arch){
		
		int cantProd= getCantidadProductos();
		while(arch.hasNext()){
			Producto prod= new Producto();
			String cod=arch.next();
			if(cod.equals("-1"))
				return;
			prod.setCodigo(cod);
			prod.leerProducto(arch);
			arreglo_productos.add(prod);
			cantProd++;
		}
		setCantidadProductos(cantProd);
		
		
		
	}
	public void cargarPedidos(Scanner arch){
		
		
		while(arch.hasNext()){
			Pedido ped= new Pedido();
			String cod=arch.next();
			int dni = arch.nextInt();
			ped.setCodigo(cod);
			ped.setDni_cliente(dni);
			double precio=-1;
			for(Producto p : arreglo_productos){
				String codigo=p.getCodigo();
				if(codigo.compareTo(cod)==0){
					precio=p.getPrecio();
					p.agregarPed(ped);
					ped.setPrecio_producto(precio);
					if(Double.compare(precio,-1)!=0){
						//si encontro precio
						for(Cliente c : arreglo_clientes){
							if((c.getDni())==(ped.getDni_cliente())){
								c.agregarPed(ped);
							}
						}
					}
				}
					
			}
			
		}
		
		
	}
	public void mostrarDatos(){
		System.out.println("Clientes :");
		for(Cliente c : arreglo_clientes){
			c.imprime();
		}
		System.out.println("Productos :");
		for(Producto p : arreglo_productos){
			p.imprime();
		}
		
		
		
		
	}
	
	
	
	
	
}