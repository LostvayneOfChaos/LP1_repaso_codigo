import java.util.Scanner;
import java.util.ArrayList;



class MainProblemas{	
	public static void main(String []args ){
		
		Almacen almacen= new Almacen();
		Scanner arch = new Scanner(System.in);
		almacen.cargarClientes(arch);
		almacen.cargarProductos(arch);
		almacen.cargarPedidos(arch);
		almacen.mostrarDatos();
		
		
	}
}