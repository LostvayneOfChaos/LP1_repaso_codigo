import java.utils.Scanner;
import java.utils.ArrayList;



class MainProblemas{	
	public static void main(String []args ){
		
		Almacen almacen= new Almacen();
		
		almacen.cargarClientes();
		almacen.cargarProductos();
		almacen.cargarPedidos();
		almacen.mostrarDatos();
		
		
	}
}