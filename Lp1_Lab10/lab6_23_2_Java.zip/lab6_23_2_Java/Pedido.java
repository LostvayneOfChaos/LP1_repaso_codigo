import java.util.Scanner;
import java.util.ArrayList;



public class Pedido{	
	private String codigo;
	private int dni_cliente ;
	private double precio_producto ;
	
	public Pedido(){
		codigo=null;
		
	}
	
	public String getCodigo(){
		return this.codigo;
	}
	public void setCodigo(String codigo){
		this.codigo=codigo;
	}
	public int getDni_cliente(){
		return this.dni_cliente;
	}
	public void setDni_cliente(int dni_cliente){
		this.dni_cliente=dni_cliente;
	}
	public double getPrecio_producto(){
		return this.precio_producto;
	}
	public void setPrecio_producto(double precio_producto){
		this.precio_producto=precio_producto;
	}
	
	
	
}