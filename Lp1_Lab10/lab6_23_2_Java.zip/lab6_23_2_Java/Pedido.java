import java.utils.Scanner;
import java.utils.ArrayList;



public class Pedido{	
	private String codigo;
	private int dni_cliente ;
	private double precio_producto ;
	
	public Pedido(){
		
		
	}
	
	
	
	
	
}