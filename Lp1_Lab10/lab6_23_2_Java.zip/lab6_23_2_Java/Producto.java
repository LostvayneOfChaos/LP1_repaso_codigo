import java.util.Scanner;
import java.util.ArrayList;



public class Producto{	
	private double precio;
	private String codigo;
	private String descripcion;
	private int stock;
	private ArrayList<Integer> clientes_servidos;
	private ArrayList<Integer> clientes_no_servidos;
	private int cantidad_clientes_servidos;
	private int cantidad_clientes_no_servidos;
	
	public Producto(){
		clientes_servidos=new ArrayList<Integer>();
		clientes_no_servidos=new ArrayList<Integer>();
		
	}
	public double getPrecio(){
		return this.precio;
	}
	public void setPrecio(double precio){
		this.precio=precio;
	}
	public String getCodigo(){
		return this.codigo;
	}
	public void setCodigo(String codigo){
		this.codigo=codigo;
	}
	public String getDescripcion(){
		return this.descripcion;
	}
	public void setDescripcion(String descripcion){
		this.descripcion=descripcion;
	}
	public int getStock(){
		return this.stock;
	}
	public void setStock(int stock){
		this.stock=stock;
	}
	public int getCantidad_clientes_servidos(){
		return this.cantidad_clientes_servidos;
	}
	public void setCantidad_clientes_servidos(int cantidad_clientes_servidos){
		this.cantidad_clientes_servidos=cantidad_clientes_servidos;
	}
	public int getCantidad_clientes_no_servidos(){
		return this.cantidad_clientes_no_servidos;
	}
	public void setCantidad_clientes_no_servidos(int cantidad_clientes_no_servidos){
		this.cantidad_clientes_no_servidos=cantidad_clientes_no_servidos;
	}
	
	public void leerProducto(Scanner arch){
		String desc= arch.next();
		double prec= arch.nextDouble();
		int valor=arch.nextInt();
		setDescripcion(desc);
		setPrecio(prec);
		setStock(valor);
	}
	
	public void agregarPed(Pedido ped){
		
		if (Double.compare(getStock(),0)==1){
			
			clientes_servidos.add(ped.getDni_cliente());
			int nuevo=getStock()-1;
			setStock(nuevo);
		}
		else{
			clientes_no_servidos.add(ped.getDni_cliente());
		}
		
		
	}
	
	
	public void imprime(){
		
		System.out.println(codigo + "  "+ descripcion + "  " + precio + "  "
		+ stock);
		System.out.print("Cilentes atendidos: ");
		for(int c: clientes_servidos){
			System.out.print(c+ "  ");
		}
		System.out.println();
		
		System.out.print("Cilentes no atendidos: ");
		for(int c: clientes_no_servidos){
			System.out.print(c+ "  ");
		}
		System.out.println();
		
		
		
		
	}
	
	
	
}