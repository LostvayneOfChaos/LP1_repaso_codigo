import java.utils.Scanner;
import java.utils.ArrayList;



public class Producto{	
	private double precio;
	private String codigo;
	private String descripcion;
	private int stock;
	private ArrayList<int> clientes_servidos;
	private ArrayList<int> clientes_no_servidos;
	private int cantidad_clientes_servidos;
	private int cantidad_clientes_no_servidos;
	
	public Producto(){
		clientes_servidos=new ArrayList<int>();
		clientes_no_servidos=new ArrayList<int>();
		
	}
	
	
	
	
	
}