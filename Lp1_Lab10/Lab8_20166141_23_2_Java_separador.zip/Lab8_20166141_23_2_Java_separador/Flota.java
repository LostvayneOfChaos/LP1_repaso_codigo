import java.util.Scanner;
import java.util.ArrayList;


class Flota{
	private ArrayList<NVehiculo> LVehiculos;
	
	public Flota(){
		this.LVehiculos=new ArrayList<NVehiculo>();
	}
	
	public void cargaflota(){
		Scanner arch = new Scanner(System.in);
		//Tipo de Vehiculo, Cliente, Placa, Maxima carga, Filas/Ejes, Puertas/Llantas , 
		//Cliente, Codigo producto, cantidad, peso,
		NVehiculo nodo=new NVehiculo();
		while(arch.hasNext()){
			String tipo;
			char palabra;
			tipo=arch.next();
			if(tipo.equals("-1"))
				break;
			palabra=tipo.charAt(0);
			nodo=new NVehiculo();
			nodo.leerDatos(arch,palabra);
			LVehiculos.add(nodo);
			
			
		}		
		//leer archivo pedidos separado por -1
		//Cliente,Codigo producto, cantidad, peso,
		while(arch.hasNext()){
			int cod= arch.nextInt();
			NPedido pedido=new NPedido();
			pedido.leerPedido(arch);
			for(NVehiculo nodovehiculo: LVehiculos){
				int valor =nodovehiculo.copiarCliente();
				if(cod== valor){
					nodovehiculo.agregar(pedido);
					break;
					
				}
				
			}
			
			
		}
		
		
		
		
		
	}
	
	public void muestracarga(){
		for(NVehiculo nodo:LVehiculos){
			System.out.println("  Vehiculo :");
			nodo.imprimirDatos();
		}		
	}
	
	
	
}