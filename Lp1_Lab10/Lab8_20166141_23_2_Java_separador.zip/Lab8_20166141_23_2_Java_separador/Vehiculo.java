import java.util.Scanner;
import java.util.ArrayList;


abstract class Vehiculo{
	private int cliente;
	private String placa;
	private double maxcarga;
	private double actcarga;
	//private ArrayList<NPedido> listaPedidos;
	
	public Vehiculo(){
		//this.listaPedidos=new ArrayList<NPedido>();
		maxcarga=300;
		cliente=0;
		actcarga=0;
		placa=null;
	}
	public Vehiculo(int cliente,String placa, double maxcarga, double actcarga){
		//this.listaPedidos=new ArrayList<NPedido>();
		this.cliente=cliente;
		this.placa=placa;
		this.maxcarga=maxcarga;
		this.actcarga=actcarga;
	}
	
	public int getCliente(){
		return this.cliente;
	}
	public void setCliente(int cliente){
		this.cliente=cliente;
	}
	public String getPlaca(){
		return this.placa;
	}
	public void setPlaca(String placa){
		this.placa=placa;
	}
	public double getMaxcarga(){
		return this.maxcarga;
	}
	public void setMaxcarga(double maxcarga){
		this.maxcarga=maxcarga;
	}
	public double getActcarga(){
		return this.actcarga;
	}
	public void setActcarga(double actcarga){
		this.actcarga=actcarga;
	}
	
	//@Override como no le puse abstract no cuenta
	public void leer(Scanner arch){
		//Tipo de Vehiculo, Cliente, Placa, Maxima carga, Filas/Ejes, Puertas/Llantas , 
		//Cantidad de pedidos, Codigo producto, cantidad, peso,
		this.cliente=arch.nextInt();
		this.placa=arch.next();
		this.maxcarga=arch.nextDouble();
		
	}
	
	
	public void imprime(){
		//Cliente, Placa, Maxima carga, 
		System.out.println("Cliente :"+ cliente + "   Placa: " + placa + "   Maxima carga: " +maxcarga + "   Actual carga: " +actcarga );
		
		
		
	}
	
	
	/*public void imprimirPedidos(){
		
		for(NPedido pedido: listaPedidos)//usa iterator para imprimir en el arrayList
			pedido.imprimirPedido();
		
		
		
		//this.listaPedidos.add(pedido);
		
	}*/
	
	//@Override
	abstract public void agregarPedido(NPedido pedido);
	
	
	
}