import java.util.Scanner;
import java.util.ArrayList;


class Furgon extends Vehiculo{
	private int filas;
	private int puertas;
	private ArrayList<NPedido> listaPedidos;
	
	public Furgon(int filas,int puertas){
		this.filas=filas;
		this.puertas=puertas;
		this.listaPedidos=new ArrayList<NPedido>();
	}
	public Furgon(){
		this.filas=0;
		this.puertas=0;
		this.listaPedidos=new ArrayList<NPedido>();
	}
	public int getFilas(){
		return this.filas;
	}
	public void setFilas(int filas){
		this.filas=filas;
	}
	public int getPuertas(){
		return this.puertas;
	}
	public void setPuertas(int puertas){
		this.puertas=puertas;
	}
	
	@Override
	public void leer(Scanner arch){
		
		//Tipo de Vehiculo, Cliente, Placa, Maxima carga, Filas/Ejes, Puertas/Llantas , 
		//Cantidad de pedidos, Codigo producto, cantidad, peso,
		super.leer(arch);// o podrias leer en Nvehiculos y pasar los paramteros leidos en vez de arch y hacer super(parametros)...
		this.filas=arch.nextInt();
		this.puertas=arch.nextInt();
		//leer pedido
		int cant= arch.nextInt();
		for(int i=0; i<cant; i++){
			NPedido pedido= new NPedido();
			pedido.leerPedido(arch);
			/*if((pedido.getPeso()+ super.getActcarga())<=(super.getMaxcarga())){
				listaPedidos.add(pedido);
				super.setActcarga(pedido.getPeso()+ super.getActcarga());
				cant--;
			}*/
			double maxcarga = super.getMaxcarga();
			double actcarga = super.getActcarga();
			
			if( maxcarga >=  pedido.getPeso() + actcarga){
				actcarga += pedido.getPeso();
				super.setActcarga(actcarga);
				listaPedidos.add(pedido);
			}
		}
		
	}
	
	@Override
	public void imprime( ){
		////Filas/Ejes, Puertas/Llantas , 
		//Filas/Ejes, Puertas/Llantas , 
		super.imprime();
		System.out.println(" Filas :"+ filas + "  Puertas: " + puertas);
		//immprimir pedidos
		System.out.println("  Pedidos :");
		//super.imprimirPedidos();
		for(NPedido pedido: listaPedidos)//usa iterator para imprimir en el arrayList
			pedido.imprimirPedido();
		
		
	}
}