archivo Vehiculos_Pedidos.txt  
-------------------------------
F       16552775         S7E-946    300           2             3            2  AWB.345  6  18   CNN.411  5  300
Tipo de Vehiculo, Cliente, Placa, Maxima carga, Filas/Ejes, Puertas/Llantas , Cantidad de pedidos, Codigo producto, cantidad, peso, ...
