import java.util.Scanner;
import java.util.ArrayList;


class NVehiculo{
	private Vehiculo unidad;
	
	public NVehiculo(){
		unidad=null;
	}
	
	
	public void leerDatos(Scanner arch){
		
			//Vehiculo vehiculo=new Vehiculo();
			String tipo;
			char palabra;
			tipo=arch.next();
			palabra=tipo.charAt(0);
			
			if(palabra=='F')
				unidad=new Furgon(); 
			if(palabra=='C')
				unidad=new Camion(); 
			
			
			//System.out.println("bien");
			unidad.leer(arch);//metodo polimorfico
			
	}
	
	
	
	public void imprimirDatos(){
		
		unidad.imprime();//metodo polimorfico
	}
	
}