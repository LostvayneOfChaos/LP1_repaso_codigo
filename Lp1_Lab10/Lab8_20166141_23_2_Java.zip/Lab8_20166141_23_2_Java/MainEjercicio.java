import java.util.Scanner;
import java.util.ArrayList;


class MainEjercicio{
	public static void main(String [] args){
		
		Flota transporte=new Flota();
		transporte.cargaflota();
	    transporte.muestracarga();
		
	}
	
	
}

 