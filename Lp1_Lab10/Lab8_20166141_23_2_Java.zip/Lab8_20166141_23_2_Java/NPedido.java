import java.util.Scanner;
import java.util.ArrayList;


class NPedido{
	private int cantidad;
	private String codigo;
	private double peso;
	
	public NPedido(){
		this.cantidad=0;
		this.peso=0;
		codigo=null;
	}
	
	
	public NPedido(int cantidad,String codigo, double peso){
		this.cantidad=cantidad;
		this.codigo=codigo;
		this.peso=peso;
	}
	
	
	public int getCantidad(){
		return this.cantidad;
	}
	public void setCantidad(int cantidad){
		this.cantidad=cantidad;
	}
	public String getCodigo(){
		return this.codigo;
	}
	public void setCodigo(String codigo){
		this.codigo=codigo;
	}
	
	
	public double getPeso(){
		return this.peso;
	}
	public void setPeso(double peso){
		this.peso=peso;
	}
	
	public void leerPedido(Scanner arch){
		//Codigo producto, cantidad, peso,
		this.codigo= arch.next();
		this.cantidad= arch.nextInt();
		this.peso= arch.nextDouble();
	}
	
	public void imprimirPedido(){
		//Codigo producto, cantidad, peso,
		System.out.println(" CodigoProducto :"+ codigo + "  Cantidad: " + cantidad + 
		"   Peso: " + peso );
		
		
		
	}
}