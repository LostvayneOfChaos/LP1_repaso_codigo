import java.util.Scanner;
import java.util.ArrayList;


class Flota{
	private ArrayList<NVehiculo> LVehiculos;
	
	public Flota(){
		this.LVehiculos=new ArrayList<NVehiculo>();
	}
	
	public void cargaflota(){
		Scanner arch = new Scanner(System.in);
		//Tipo de Vehiculo, Cliente, Placa, Maxima carga, Filas/Ejes, Puertas/Llantas , 
		//Cantidad de pedidos, Codigo producto, cantidad, peso,
		NVehiculo nodo=new NVehiculo();
		while(arch.hasNext()){
			
			nodo=new NVehiculo();
			nodo.leerDatos(arch);
			LVehiculos.add(nodo);
		}		
		
		
		
	}
	
	public void muestracarga(){
		for(NVehiculo nodo:LVehiculos){
			System.out.println("  Vehiculo :");
			nodo.imprimirDatos();
		}		
	}
	
	
	
}