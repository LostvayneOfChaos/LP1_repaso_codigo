import java.util.Scanner;
import java.util.ArrayList;


class Camion extends Vehiculo{
	private int ejes;
	private int llantas;
	private ArrayList<NPedido> listaPedidos;
	
	
	
	public Camion(int ejes,int llantas){
		this.ejes=ejes;
		this.llantas=llantas;
		this.listaPedidos=new ArrayList<NPedido>();
	}
	public Camion(){
		this.ejes=0;
		this.llantas=0;
		this.listaPedidos=new ArrayList<NPedido>();
	}
	
	public int getEjes(){
		return this.ejes;
	}
	public void setEjes(int ejes){
		this.ejes=ejes;
	}
	public int getLlantas(){
		return this.llantas;
	}
	public void setLlantas(int llantas){
		this.llantas=llantas;
	}
	
	
	@Override
	public void leer(Scanner arch){
		
		//Filas/Ejes, Puertas/Llantas , 
		//Cantidad de pedidos, Codigo producto, cantidad, peso,
		super.leer(arch);// o podrias leer en Nvehiculos y pasar los paramteros leidos en vez de arch y hacer super(parametros)...
		this.ejes=arch.nextInt();
		this.llantas=arch.nextInt();
		
		//leer pedido
		//Cantidad de pedidos, Codigo producto, cantidad, peso,
		int cant= arch.nextInt();
		for(int i=0; i<cant; i++){
			NPedido pedido= new NPedido();
			pedido.leerPedido(arch);
			/*if((pedido.getPeso()+ super.getActcarga())<=(super.getMaxcarga())){
				listaPedidos.add(pedido);
				super.setActcarga(pedido.getPeso()+ super.getActcarga());
			}*/
			double maxcarga = super.getMaxcarga();
			double actcarga = super.getActcarga();
			
			if( maxcarga >=  pedido.getPeso() + actcarga){
				actcarga += pedido.getPeso();
				super.setActcarga(actcarga);
				listaPedidos.add(pedido);
			}
			
		}
	}
	@Override
	public void imprime( ){
		//Filas/Ejes, Puertas/Llantas , 
		super.imprime();
		System.out.println(" Ejes :"+ ejes + "  Llantas: " + llantas);
		//immprimir pedidos
		System.out.println(" Pedidos :");
		//super.imprimirPedidos();
		for(NPedido pedido: listaPedidos)//usa iterator para imprimir en el arrayList
			pedido.imprimirPedido();
		
	}
	
	
}