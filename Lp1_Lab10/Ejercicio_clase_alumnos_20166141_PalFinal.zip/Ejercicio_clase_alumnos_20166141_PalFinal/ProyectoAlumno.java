import java.util.ArrayList;
import java.util.Scanner;

class ProyectoAlumno{
	public static void main(String [] args){
		
		ListaAlumnos lista= new ListaAlumnos();
		lista.leerAlumnos();
		lista.imprimirAlumnos();
		
	}
}