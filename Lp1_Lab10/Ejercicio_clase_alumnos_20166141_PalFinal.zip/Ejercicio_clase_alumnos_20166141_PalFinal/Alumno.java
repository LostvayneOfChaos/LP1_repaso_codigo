
import java.util.ArrayList;
import java.util.Scanner;
abstract class Alumno{
	private char tipo;
	private int codigo;
	private String nombre;
	
	public Alumno(){
		codigo=0;
		nombre=null;
		
	}
	public Alumno(char tipo,int codigo,String nombre){
		this.tipo=tipo;
		this.codigo=codigo;
		this.nombre=nombre;
		
	}
	public char getTipo(){
		return this.tipo;
	}
	
	public void setTipo(char tipo){
		this.tipo=tipo;
	}
	
	
	public String getNombre(){
		return this.nombre;
	}
	
	public void setNombre(String nombre){
		this.nombre=nombre;
	}
	
	public int getCodigo(){
		return this.codigo;
	}
	
	public void setCodigo(int codigo){
		this.codigo=codigo;
	}
	
	 public void leer(Scanner arch){
		this.codigo=arch.nextInt();
		this.nombre=arch.next();
	}
	
	public void imprimir(){
		System.out.print(getCodigo()+"   "+getNombre()+"   ");
	}
	
	
}