import java.util.ArrayList;
import java.util.Scanner;
class AlumnoRegular extends Alumno{
	private String especialidad;
	private String facultad;
	
	public AlumnoRegular(){
		
		especialidad=null;
		
	}
	
	public String getEspecialidad(){
		return this.especialidad;
	}
	
	public void setEspecialidad(String especialidad){
		this.especialidad=especialidad;
	}
	
	public String getFacultad(){
		return this.facultad;
	}
	
	public void setFacultad(String facultad){
		this.facultad=facultad;
	}
	
	
	@Override
	public void leer(Scanner arch){
		super.leer(arch);
		especialidad=arch.next();
		facultad=arch.next();
	}
	
	@Override
	public void imprimir(){
		super.imprimir();
		System.out.println(getEspecialidad()+"   "+getFacultad()+"   ");
	}
}