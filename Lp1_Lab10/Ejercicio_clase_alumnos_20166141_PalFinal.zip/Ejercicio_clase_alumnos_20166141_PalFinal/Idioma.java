import java.util.ArrayList;
import java.util.Scanner;

class Idioma{
	private String nombre;
	
	/*public Alumno(){
		
	}*/
	public String getNombre(){
		return this.nombre;
	}
	
	public void setNombre(String nombre){
		this.nombre=nombre;
	}
	
	
	
}