import java.util.ArrayList;
import java.util.Scanner;
class AlumnoIntercambio extends Alumno{
	private String paisOrigen;
	private ArrayList<Idioma> idiomas;// o tambien arreglo de strings
	private int numSemestres;
	
	public AlumnoIntercambio(){
		
		idiomas=new ArrayList<Idioma>();
		numSemestres=0;
	}
	public String getPaisOrigen(){
		return this.paisOrigen;
	}
	
	public void setPaisOrigen(String paisOrigen){
		this.paisOrigen=paisOrigen;
	}
	
	public int getNumSemestres(){
		return this.numSemestres;
	}
	
	public void setNumSemestres(int numSemestres){
		this.numSemestres=numSemestres;
	}
	
	
	
	@Override
	public void leer(Scanner arch){
		super.leer(arch);
		paisOrigen=arch.next();
		while(!arch.hasNextInt()){
			Idioma id= new Idioma();
			String cadena= arch.next();
			id.setNombre(cadena);
			idiomas.add(id);
		}
		numSemestres=arch.nextInt();
	}
	
	@Override
	public void imprimir(){
		super.imprimir();
		System.out.print(getPaisOrigen()+"   ");
		for(Idioma id: idiomas){
			System.out.print(id.getNombre()+"   ");
		}
		System.out.println(getNumSemestres()+"   ");
	}
}