import java.util.ArrayList;
import java.util.Scanner;
class ListaAlumnos{
	private ArrayList<Alumno> listaAlumno;
	
	public ListaAlumnos(){
		listaAlumno=new ArrayList<Alumno>();
	}
	
	
	public void leerAlumnos(){
		
		
		Scanner arch= new Scanner(System.in);
		while(arch.hasNext()){
			String codigo =arch.next();
			char palabra=codigo.charAt(0);
			Alumno al;
			if(palabra =='R'){
				al=new AlumnoRegular();
				al.setTipo(palabra);
				al.leer(arch);
				listaAlumno.add(al);
			}	
			if(palabra =='I'){
				al=new AlumnoIntercambio();
				al.setTipo(palabra);
				al.leer(arch);
				listaAlumno.add(al);
			}
		}
	}
	
	public void imprimirAlumnos(){
		
		for(Alumno al:listaAlumno){
			System.out.print(al.getTipo()+"   ");
			al.imprimir();
			
		}
		
		
	}
	
}