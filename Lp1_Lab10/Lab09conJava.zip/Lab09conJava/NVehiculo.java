import java.util.Scanner;

class NVehiculo{
	private Vehiculo unidad;
	
	public NVehiculo(){
		unidad = null;
	}
	
	public void leerDatos(Scanner arch){
		String palabra;
		char tipo;
		
		palabra = arch.next();
		tipo = palabra.charAt(0);
		
		if(tipo=='C'){
			unidad = new Camion();				
		}else{
			unidad = new Furgon();				
		}
		unidad.lee(arch);		
	}
	
	public void imprimirDatos(){
		unidad.imprime();
	}
}