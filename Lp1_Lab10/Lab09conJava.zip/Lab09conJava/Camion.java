import java.util.Scanner;
import java.util.ArrayList;

class Camion extends Vehiculo{
	private int ejes;
	private int llantas;
	private ArrayList<NPedido> mdeposito;
	
	public Camion(){
		mdeposito = new ArrayList<NPedido>();
	}
	
	public void setEjes(int ejes){
		this.ejes = ejes;
	}
	
	public int getEjes(){
		return this.ejes;
	}
	
	public void setLlantas(int llantas){
		this.llantas = llantas;
	}
	
	public int getLlantas(){
		return this.llantas;
	}
	
	@Override
	void lee(Scanner arch){
		super.lee(arch);
		ejes = arch.nextInt();	
		llantas = arch.nextInt();
		
		// Lectura de pedidos
		int numped;
		numped = arch.nextInt();
		NPedido pedido = null;
		for(int i=0; i<numped; i++){
			pedido = new NPedido();
			pedido.leerDatos(arch);
			
			cargaDeposito(pedido);
		}
	}
	
	private void cargaDeposito(NPedido pedido){		
		if(mdeposito.size()<5){
			double maxcarga = super.getMaxcarga();
			double actcarga = super.getActcarga();
			
			if( maxcarga >=  pedido.getPeso() + actcarga){
				actcarga += pedido.getPeso();
				super.setActcarga(actcarga);
				mdeposito.add(pedido);
			}
		}				
	}
	
	@Override
	void imprime(){ 
		super.imprime();
		System.out.println("#Ejes:             " + ejes);
		System.out.println("#Llantas:          " + llantas);
		if(mdeposito.size()>0){
			int indice = 0;
			for(NPedido mdep: mdeposito){
				indice++;
				System.out.print(indice + "   ");
				mdep.imprimirDatos();
			}				
		}else{
			System.out.println("   No hay pedidos para el cliente.");
		}
		System.out.println(" ");
	}
}