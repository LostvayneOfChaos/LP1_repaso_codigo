import java.util.Scanner;
import java.util.ArrayList;

class Flota{
	private ArrayList<NVehiculo> vflota;
	
	public Flota(){
		vflota = new ArrayList<NVehiculo>();
	}
	
	public void cargaflota(){
		Scanner arch = new Scanner(System.in);
		NVehiculo nvehiculo = new NVehiculo();
		
		while(arch.hasNext()){		
			nvehiculo = new NVehiculo();
			nvehiculo.leerDatos(arch);
			//nvehiculo.imprimirDatos();
			vflota.add(nvehiculo);
		}
	}
	
	
	public void muestracarga(){
		for(NVehiculo nveh: vflota)
			nveh.imprimirDatos();
		
	}
	
}