import java.util.Scanner;

class NPedido{
	private String codigo;
	private int cantidad;
	private double peso;
	
	public NPedido(){
		codigo = null;
		cantidad = 0;
		peso = 0;
	}
	
	public void setCodigo(String codigo){
		this.codigo = codigo;
	}
	
	public String getCodigo(){
		return this.codigo;
	}
	
	public void setCantidad(int cantidad){
		this.cantidad = cantidad;
	}
	
	public int getCantidad(){
		return this.cantidad;
	}
	
	public void setPeso(double peso){
		this.peso = peso;
	}
	
	public double getPeso(){
		return this.peso;
	}
	
	public void leerDatos(Scanner arch){
		codigo = arch.next();
		cantidad = arch.nextInt();
		peso = arch.nextDouble();
	}
	
	public void imprimirDatos(){
		System.out.println(codigo + " - " + cantidad + " - " + peso);
	}
	
}