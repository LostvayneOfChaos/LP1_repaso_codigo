import java.util.Scanner;

class Vehiculo{
	private int cliente;
	private String placa;
	private double maxcarga;
	private double actcarga;
	
	public Vehiculo(){
		placa = null;
		actcarga = 0;
	}
	
	public void setCliente(int cliente){
		this.cliente = cliente;
	}
	
	public int getCliente(){
		return this.cliente;
	}
	
	public void setPlaca(String placa){
		this.placa = placa;
	}
	
	public String getPlaca(){
		return this.placa;
	}
	
	public void setMaxcarga(double maxcarga){
		this.maxcarga = maxcarga;
	}
	
	public double getMaxcarga(){
		return this.maxcarga;
	}
	
	public void setActcarga(double actcarga){
		this.actcarga = actcarga;
	}
	
	public double getActcarga(){
		return this.actcarga;
	}
	
	void lee(Scanner arch){
		cliente = arch.nextInt();	
		placa = arch.next();
		maxcarga = arch.nextDouble();
	}
	
	void imprime(){
		System.out.println("Codigo de Cliente: " + cliente);
		System.out.println("Placa:             " + placa);
		System.out.println("Carga Maxima:      " + maxcarga);
		System.out.println("Carga Actual:      " + actcarga);
	}
}