import java.util.Scanner;

class Lab09conJava{
	public static void main(String []arg){
		
		Flota Unidades = new Flota();
		
		Unidades.cargaflota();
		Unidades.muestracarga();
	}	
}