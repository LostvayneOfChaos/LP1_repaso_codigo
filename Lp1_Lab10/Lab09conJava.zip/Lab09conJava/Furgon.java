import java.util.Scanner;
import java.util.ArrayList;

class Furgon extends Vehiculo{
	private int filas;
	private int puertas;
	private ArrayList<NPedido> pdeposito;
	
	public Furgon(){
		pdeposito = new ArrayList<NPedido>();
	}
	
	public void setFilas(int filas){
		this.filas = filas;
	}
	
	public int getFilas(){
		return this.filas;
	}
	
	public void setPuertas(int puertas){
		this.puertas = puertas;
	}
	
	public int getPuertas(){
		return this.puertas;
	}
	
	@Override
	void lee(Scanner arch){
		super.lee(arch);
		filas = arch.nextInt();	
		puertas = arch.nextInt();
		
		// Lectura de pedidos
		int numped;
		numped = arch.nextInt();
		NPedido pedido = null;
		for(int i=0; i<numped; i++){
			pedido = new NPedido();
			pedido.leerDatos(arch);
			
			cargaDeposito(pedido);
		}
	}
	
	private void cargaDeposito(NPedido pedido){	
		double maxcarga = super.getMaxcarga();
		double actcarga = super.getActcarga();
		
		if( maxcarga >=  pedido.getPeso() + actcarga){
			actcarga += pedido.getPeso();
			super.setActcarga(actcarga);
			pdeposito.add(0, pedido); // simulando el comportamiento de una pila
		}	
	}
	
	@Override
	void imprime(){ 
		super.imprime();
		System.out.println("#Filas:            " + filas);
		System.out.println("#Puertas:          " + puertas);
		System.out.println("Lista de Pedidos:");
		
		if(pdeposito.size()>0){
			int indice = 0;
			for(NPedido pdep: pdeposito){
				indice++;
				System.out.print(indice + "   ");
				pdep.imprimirDatos();
			}
		}else{
			System.out.println("   No hay pedidos para el cliente.");
		}
		System.out.println(" ");
	}
	
}