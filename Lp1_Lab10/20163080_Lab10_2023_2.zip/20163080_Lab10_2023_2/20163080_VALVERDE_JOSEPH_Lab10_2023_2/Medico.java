import java.util.Scanner;

public class Medico{
	private int codigo;
	private String nombre;
	private String especialidad;
	private double tarifa;
	private double tiempoTotal;
	private double ingresosTotales;
	private int cantidadDeConsultas;
	
	public Medico(){
		codigo = 0;
		tarifa = 0;
		tiempoTotal = 0;
		ingresosTotales = 0;
		cantidadDeConsultas = 0;
	}
	
	public Medico(int cod, String nom, String esp, double tar, double tie, double ing, int can){
		codigo = cod;
		nombre = nom;
		especialidad = esp;
		tarifa = tar;
		tiempoTotal = tie;
		ingresosTotales = ing;
		cantidadDeConsultas = can;
	}
	
	public int getCodigo(){
		return codigo;
	}
	public void setCodigo(int cod){
		codigo = cod;
	}
	
	public String getNombre(){
		return nombre;
	}
	public void setNombre(String nom){
		nombre = nom;
	}
	
	public String getEspecialidad(){
		return especialidad;
	}
	public void setEspecialidad(String esp){
		especialidad = esp;
	}
	
	public double getTarifa(){
		return tarifa;
	}
	public void setTarifa(double tar){
		tarifa = tar;
	}
	
	public double getTiempoTotal(){
		return tiempoTotal;
	}
	public void setTiempoTotal(double tie){
		tiempoTotal = tie;
	}
	
	public double getIngresosTotales(){
		return ingresosTotales;
	}
	public void setIngresosTotales(double ing){
		ingresosTotales = ing;
	}
	
	public int getCantidadDeConsultas(){
		return cantidadDeConsultas;
	}
	public void setCantidadDeConsultas(int can){
		cantidadDeConsultas = can;
	}
	
	public void leerMedico(int cod, Scanner arch){
		codigo = cod;
		nombre = arch.next();
		especialidad = arch.next();
		tarifa = arch.nextDouble();
	}
	
	public void imprimirMedico(){
		System.out.println("Codigo: " + codigo + " - Nombre: " + nombre + " - Especialidad: " + especialidad);
		System.out.println("Tarifa por Hora: " + tarifa);
		System.out.println("Tiempo Total de Atencion: " + tiempoTotal + " horas");
		System.out.println("Ingresos Totales por Consultas: " + ingresosTotales);
		System.out.println("Numero de Consultas: " + cantidadDeConsultas);
		imprimirLinea('-', 55);
	}
	
	public void imprimirLinea(char c, int n){
		for(int i=0; i<n; i++) System.out.print(c);
		System.out.println();
	}
}