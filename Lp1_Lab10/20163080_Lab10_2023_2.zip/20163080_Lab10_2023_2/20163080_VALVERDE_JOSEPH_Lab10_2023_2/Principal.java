// Autor: Joseph Valverde, 20163080
// Compilar y Ejecutar: javac *.java && java Principal < datos.txt
import java.util.Scanner;

class Principal{
	public static void main(String[]arg){
		ClinicaLP1 cli = new ClinicaLP1();
		Scanner arch = new Scanner(System.in);
		
		cli.leerMedicos(arch);
		cli.leerPacientes(arch);
		cli.leerConsultas(arch);
		cli.imprimirReporteDeMedicos();
		System.out.println();
		cli.imprimirReporteDePacientes();
	}
}