import java.util.Scanner;
import java.util.ArrayList;

public class ClinicaLP1{
	private ArrayList<Medico> medicos;
	private ArrayList<Paciente> pacientes;
	
	public ClinicaLP1(){
		medicos = new ArrayList<Medico>();
		pacientes = new ArrayList<Paciente>();
	}
	
	public void agregarMedico(Medico med){
		medicos.add(med);
	}
	public void imprimirMedicos(){
		for(Medico med:medicos)
			med.imprimirMedico();
	}
	
	public void agregarPaciente(Paciente pac){
		pacientes.add(pac);
	}
	public void imprimirPacientes(){
		for(Paciente pac:pacientes)
			pac.imprimirPaciente();
	}
	
	public void leerMedicos(Scanner arch){
		int cod;
		Medico med;
		while(true){
			cod = arch.nextInt();
			if(cod == 0) break;
			med = new Medico();
			med.leerMedico(cod, arch);
			agregarMedico(med);
		}
	}
	
	public void leerPacientes(Scanner arch){
		int dni;
		Paciente pac;
		while(true){
			dni = arch.nextInt();
			if(dni == 0) break;
			pac = new Paciente();
			pac.leerPaciente(dni, arch);
			agregarPaciente(pac);
		}
	}
	
	public void leerConsultas(Scanner arch){
		int dni, cod, hI, mI, sI, hS, mS, sS;
		
		while(arch.hasNext()){
			dni = arch.nextInt();
			cod = arch.nextInt();
			hI = arch.nextInt();
			mI = arch.nextInt();
			sI = arch.nextInt();
			hS = arch.nextInt();
			mS = arch.nextInt();
			sS = arch.nextInt();
			guardarConsulta(dni, cod, hI, mI, sI, hS, mS, sS);
		}
	}
	
	public void guardarConsulta(int dni, int cod, int hI, int mI, int sI, int hS, int mS, int sS){
		double consultaEnHoras = hallarConsultaEnHoras(hI, mI, sI, hS, mS, sS);
		double monto = 0;
		
		for(Medico med:medicos)
			if(med.getCodigo() == cod){
				monto = consultaEnHoras * med.getTarifa();
				med.setTiempoTotal(consultaEnHoras + med.getTiempoTotal());
				med.setIngresosTotales(monto + med.getIngresosTotales());
				med.setCantidadDeConsultas(1 + med.getCantidadDeConsultas());
			}
		
		for(Paciente pac:pacientes)
			if(pac.getDni() == dni){
				pac.setTiempoTotal(consultaEnHoras + pac.getTiempoTotal());
				pac.setGastosTotales(monto + pac.getGastosTotales());
				pac.setCantidadDeConsultas(1 + pac.getCantidadDeConsultas());
			}
		
	}
	
	private double hallarConsultaEnHoras(int hI, int mI, int sI, int hS, int mS, int sS){
		double horas = hS - hI;
		double minutos = mS - mI;
		double segundos = sS - sI;
		
		return horas + minutos/60 + segundos/3600;
	}
	
	public void imprimirReporteDeMedicos(){
		System.out.println("Reporte de Medicos");
		imprimirLinea('=', 55);
		imprimirMedicos();
	}
	
	public void imprimirReporteDePacientes(){
		System.out.println("Reporte de Pacientes");
		imprimirLinea('=', 55);
		imprimirPacientes();
	}
	
	public void imprimirLinea(char c, int n){
		for(int i=0; i<n; i++) System.out.print(c);
		System.out.println();
	}
}