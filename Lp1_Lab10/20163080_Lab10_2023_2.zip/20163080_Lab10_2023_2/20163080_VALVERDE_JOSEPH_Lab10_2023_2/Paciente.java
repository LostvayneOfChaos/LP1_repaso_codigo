import java.util.Scanner;

public class Paciente{
	private int dni;
	private String nombre;
	private String distrito;
	private double tiempoTotal;
	private double gastosTotales;
	private int cantidadDeConsultas;
	
	public Paciente(){
		this.dni = 0;
		tiempoTotal = 0;
		gastosTotales = 0;
		cantidadDeConsultas = 0;
	}
	
	public Paciente(int dni, String nom, String dis, double tie, double gas, int can){
		this.dni = dni;
		nombre = nom;
		distrito = dis;
		tiempoTotal = tie;
		gastosTotales = gas;
		cantidadDeConsultas = can;
	}
	
	public int getDni(){
		return this.dni;
	}
	public void setDni(int dni){
		this.dni = dni;
	}
	
	public String getNombre(){
		return nombre;
	}
	public void setNombre(String nom){
		nombre = nom;
	}
	
	public String getDistrito(){
		return distrito;
	}
	public void setDistrito(String dis){
		distrito = dis;
	}
	
	public double getTiempoTotal(){
		return tiempoTotal;
	}
	public void setTiempoTotal(double tie){
		tiempoTotal = tie;
	}
	
	public double getGastosTotales(){
		return gastosTotales;
	}
	public void setGastosTotales(double gas){
		gastosTotales = gas;
	}
	
	public int getCantidadDeConsultas(){
		return cantidadDeConsultas;
	}
	public void setCantidadDeConsultas(int can){
		cantidadDeConsultas = can;
	}
	
	public void leerPaciente(int dni, Scanner arch){
		this.dni = dni;
		nombre = arch.next();
		distrito = arch.next();
	}
	
	public void imprimirPaciente(){
		System.out.println("DNI: " + dni + " - Nombre: " + nombre + " - Distrito: " + distrito);
		System.out.println("Tiempo Total de Atencion: " + tiempoTotal + " horas");
		System.out.println("Gastos Totales por Consultas: " + gastosTotales);
		System.out.println("Numero de Consultas: " + cantidadDeConsultas);
		imprimirLinea('-', 55);
	}
	
	public void imprimirLinea(char c, int n){
		for(int i=0; i<n; i++) System.out.print(c);
		System.out.println();
	}
}