/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   bibimpresion.h
 * Author: cueva
 *
 * Created on 1 de noviembre de 2021, 01:21 AM
 */
#include <iostream>
#include <fstream>

using namespace std;
#ifndef BIBIMPRESION_H
#define BIBIMPRESION_H
    void imprimirnum(void *,const char*);
    void imprimirped(void *,const char*);
#endif /* BIBIMPRESION_H */
