/* 
 * File:   funciones.h
 * Author: cueva
 *
 * Created on 26 de octubre de 2021, 09:43 AM
 */

#include <iostream>
#include <fstream>

using namespace std;

#ifndef FUNCIONES_H
#define FUNCIONES_H
    void *leenumero(ifstream &);
    void muestranumero(void*,int ,ofstream &);
    void *leepedido(ifstream &);
    void muestrapedido(void*,int , ofstream &);
    void imprimenumero(void*, ofstream &);
    void imprimepedido(void*, ofstream &);
#endif /* FUNCIONES_H */
