/* 
 * File:   funciones.cpp
 * Author: cueva
 * 
 * Created on 26 de octubre de 2021, 09:43 AM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
#include "bibgenerica.h"
using namespace std;
#include "funciones.h"

void *leenumero(ifstream &arch){
    int codigo,*aux;
    
    arch >> codigo;
    if(arch.eof()) return NULL;
    aux = new int;
    *aux = codigo;
    
    return aux;
}

void *leepedido(ifstream &arch){
    void **reg;
    int codigo,*aux;
    char tipo,c,libro[10],*codlibro,nom[100],*nombre,*ctip;
    arch >> codigo;
    if(arch.eof()) return NULL;
    aux = new int;
    *aux = codigo;
    arch >> tipo >>c;
    ctip = new char;
    *ctip = tipo;
    arch.getline(libro,10,',');
    codlibro = new char[strlen(libro)+1];
    strcpy(codlibro,libro);
    arch.getline(nom,100);
    nombre = new char[strlen(nom)+1];
    strcpy(nombre,nom);
    reg = new void*[4];
    reg[0] = aux;
    reg[1] = ctip;
    reg[2] = codlibro;
    reg[3] = nombre;
    
    return reg;
}

void muestranumero(void*dato,int n, ofstream &arch){
    
    int *aux=(int*)dato;
    arch <<setw(3)<<n+1<< setw(10) << *aux <<endl;
}

void muestrapedido(void*dato,int n, ofstream &arch){
    
    void **aux=(void**)dato;
    int *codigo;
    char *libro,*nombre,tipo;
    
    codigo=(int*)aux[0];
    tipo= *(char*)aux[1];
    libro=(char*)aux[2];
    nombre=(char*)aux[3];
    
    arch <<setw(3)<<n+1<<" "<< left<<setw(3)<<tipo << setw(20) << *codigo <<setw(40)<<nombre
            << setw(20)<<libro<<right <<endl;
}



void imprimenumero(void*dato, ofstream &arch){
    int *aux=(int*)dato;
    arch << setw(10) << *aux <<endl;
}

void imprimepedido(void*dato, ofstream &arch){
    void **aux=(void**)dato;
    int *codigo;
    char *libro;
    
    codigo=(int*)aux[0];
    libro=(char*)aux[2];
    
    arch << setw(10) << *codigo<< setw(20)<<libro <<endl;
}