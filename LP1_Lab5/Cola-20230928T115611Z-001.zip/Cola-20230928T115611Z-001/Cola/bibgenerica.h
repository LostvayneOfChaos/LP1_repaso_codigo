/* 
 * File:   bibgenerica.h
 * Author: cueva
 *
 * Created on 26 de octubre de 2021, 09:31 AM
 */

#include <iostream>
#include <fstream>

using namespace std;
#ifndef BIBGENERICA_H
#define BIBGENERICA_H
void creacola(void *&,void*(*)(ifstream&),const char*);
void imprimir(void *,void(*)(void*,ofstream&), const char*);
void *desencola(void *&);
void atiende(void *&,void(*)(void*,int,ofstream&),const char*);
#endif /* BIBGENERICA_H */
