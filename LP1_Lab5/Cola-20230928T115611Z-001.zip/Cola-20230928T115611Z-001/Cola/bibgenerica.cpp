/* 
 * File:   bibgenerica.cpp
 * Author: cueva
 * 
 * Created on 26 de octubre de 2021, 09:31 AM
 */
#include <iostream>
#include <fstream>
#include "funciones.h"
#include "bibgenerica.h"

using namespace std;

void generacola(void *&cola){
    void **dupla = new void*[2];
    dupla[0] = NULL;
    dupla[1] = NULL;
    cola = dupla;
}

int colavacia(void *cola){
    void **dupla = (void**)cola;
    
    if(dupla[0]==NULL)
        return 1;
    return 0;
}

void encola(void *&cola,void*dato){
    void **dupla=(void**)cola;
    void **nuevo,**fin,**aux;
    nuevo = new void*[2];

    nuevo[0] = dato;
    nuevo[1] = NULL;
    if(colavacia(cola)){
        dupla[1]=nuevo;
        dupla[0]=nuevo;
    }
    else{
        aux = (void**)dupla[1];
        aux[1] = nuevo;
        dupla[1] = nuevo;
   }

    
}

void *desencola(void *&cola){
    void**dupla = (void**)cola;
    void**ini = (void**)dupla[0];
    void *aux; 
    if(colavacia(cola)){
        delete dupla;
        return NULL;
    }
    else{
        if(dupla[1]==dupla[0]) dupla[1] = NULL;
        ini = (void**)dupla[0];
        aux = ini[0];
        dupla[0] = ini[1];
        delete ini;
    }
    return aux;
}

void creacola(void *&cola,void*(*lee)(ifstream&),
    const char*archivo){
    void *dato;
    ifstream arch(archivo,ios::in);
    if(!arch){
        cout << "No se puede abrir";
        exit(1);
    }
    generacola(cola);
    while(1){
        dato = lee(arch);
        if(dato==NULL) break;
        encola(cola,dato);
    }
}

void atiende(void *&cola,void(*muestra)(void*,int,ofstream&),
        const char*archivo){
    void *dato;
    int i=0;
    ofstream arch(archivo,ios::out);
    if(!arch){
        cout << "No se puede abrir";
        exit(1);
    }
    while(1){
        dato = desencola(cola);
        if(dato==NULL) break;
        muestra(dato,i,arch);
        i++;
    }
}

void imprimir(void *cola,void(*imprime)(void*,ofstream&),
        const char*archivo){
    void **dupla = (void**)cola;
    void **aux = (void**)dupla[0];
    
    ofstream arch(archivo,ios::out);
    if(!arch){
        cout << "No se puede abrir";
        exit(1);
    }
    while(aux){
        imprime(aux[0],arch); 
        aux = (void**)aux[1];
    }

}