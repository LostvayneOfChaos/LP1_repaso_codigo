/* 
 * File:   main.cpp
 * Author: cueva
 *
 * Created on 26 de octubre de 2021, 09:29 AM
 */
#include "bibgenerica.h"
#include "funciones.h"
#include "bibimpresion.h"

using namespace std;

int main(int argc, char** argv) {
    void *cola;
    creacola(cola, leenumero,"numeros.txt"); 
    imprimirnum(cola,"reporte.txt");
    atiende(cola,muestranumero,"Orden.txt");

    creacola(cola, leepedido,"Pedidos.csv"); 
    imprimirped(cola,"Reppedidos.txt");
    atiende(cola,muestrapedido,"Ordenpedidos.txt");
    
   return 0;
}

