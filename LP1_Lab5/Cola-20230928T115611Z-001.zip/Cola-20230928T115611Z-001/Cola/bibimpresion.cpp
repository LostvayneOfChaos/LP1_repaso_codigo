/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   bibimpresion.cpp
 * Author: cueva
 * 
 * Created on 1 de noviembre de 2021, 01:21 AM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
#include "bibimpresion.h"
#include "bibgenerica.h"
#include "funciones.h"

using namespace std;




void imprimirnum(void *cola,const char*archivo){
    imprimir(cola, imprimenumero,archivo);
}

void imprimirped(void *cola,const char*archivo){
    imprimir(cola, imprimepedido,archivo);    
}