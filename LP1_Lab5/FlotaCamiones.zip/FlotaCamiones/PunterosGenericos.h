/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   PunterosGenericos.h
 * Author: cueva
 *
 * Created on 23 de septiembre de 2023, 21:37
 */

#ifndef PUNTEROSGENERICOS_H
#define PUNTEROSGENERICOS_H
void cargaproductos(void *&);
#endif /* PUNTEROSGENERICOS_H */
