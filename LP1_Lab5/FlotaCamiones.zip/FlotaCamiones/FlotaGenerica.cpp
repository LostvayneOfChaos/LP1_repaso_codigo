
/* 
 * File:   FlotaGenerica.cpp
 * Author: cueva
 * 
 * Created on 23 de septiembre de 2023, 21:46
 */
#include <iostream>
#include <fstream>
#include <iomanip>
#include "FlotaGenerica.h"

using namespace std;


void cargacamiones(void *&flota,int n,double peso,
        void*(*lee)(ifstream&),double(*calcula)(void*), const char*nomarch){

    void**lflota,*auxpila,*auxreg;
    int pila=0;
    lflota = new void*[n];
    double auxpeso,total=0;
    
    ifstream arch(nomarch,ios::in);
    if(!arch){
        cout <<"No se puede leer "<<nomarch;
        exit(1);
    }
    
    for(int i=0;i<n;i++){
        generapila(auxpila);
        lflota[i] = auxpila;
    }
    while(1){
        auxreg = lee(arch);
        auxpeso = calcula(auxreg);
        if(auxpeso==0) break;
        if(auxpeso+total <= peso){
            auxpila = lflota[pila];
            push(auxpila,auxreg,auxpeso);
            total=auxpeso+total;
        }
        else{
            pila++;
            total=0;
            if(pila==n) break;
            auxpila = lflota[pila];
            push(auxpila,auxreg,auxpeso);
            total=auxpeso+total;
        }
        
    }
    flota = lflota;

}

void generapila(void*&pila ){
    double *num;
    void **dupla=new void*[2];
    dupla[0] = NULL;
    num = new double;
    *num = 0;
    dupla[1] = num;
    pila = dupla;
}
int pilavacia(void *pila){
   void **dupla = (void**)pila; 
   
   if(dupla[0]==NULL) return 1;
   return 0;
    
}
void push(void *&pila,void*dato,double peso){
    void **aux = (void**)pila;
    void **nuevo;
    double *sum;
    nuevo = new void*[2];
    nuevo[0] = dato;
    nuevo[1] = NULL;
    
    if(pilavacia(pila))
        aux[0] = nuevo;
    else{
        nuevo[1] = aux[0];
        aux[0] = nuevo;
    }
    sum =(double*) aux[1];
    *sum = *sum + peso;

}

void *pop(void *&pila){
    void *dato=NULL;
    void **dupla=(void**)pila;
    int *cont;
    
    if(!pilavacia(pila)){
        void **aux = (void**) dupla[0];
        dato = aux[0];
        dupla[0] = aux[1];
        aux[1] = NULL;
        cont =(int*) dupla[1];
        (*cont)--;
    }
    return dato;
}

void  muestracamiones(void *flota,int n,void(*imprime)(ofstream&,void*),const char*nomarch){
    void **lflota=(void**)flota;
    double *peso;
    ofstream arch(nomarch,ios::out);
    if(!arch){
        cout <<"No se puede leer "<<nomarch;
        exit(1);
    }    
    for(int i=0;i<n;i++){
        void **dupla = (void**)lflota[i];  
        void**aux = (void**)dupla[0];
        peso = (double*)dupla[1];
        if(*peso==0)break;
        arch << "Camion:  "<<setw(5)<< i+1 <<"  Peso: "<<setw(10)
                <<setprecision(2)<<fixed<<*peso<<endl;
        while(aux){
            imprime(arch,aux[0]); 
            aux=(void**)aux[1];
        }
        
    }
    
}