/* 
 * File:   PilaConEnteros.cpp
 * Author: cueva
 * 
 * Created on 22 de octubre de 2022, 07:28 AM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include "PilaConEnteros.h"


using namespace std;

void * leenumero(ifstream &arch){
    double aux,*num;
    
    arch >> aux;
    if(arch.eof()) return 0;
    num = new double;
    *num =  aux;
    
    return num;
}

double calculanumero(void *dato){
    double *num;
    
    num = (double*)dato;
    return *num;
}

//int cmpnumero(const void*a,const void*b){
//    void**aux1=(void **)a;
//    void**aux2=(void **)b;
//    double *num1,*num2;
// 
//    num1 = (double*)aux1[1];
//    num2 = (double*)aux2[1];
//    
//    return (*num2-*num1);
//}

int cmpnumero(const void*a,const void*b){
    void**aux1=(void **)a;
    void**aux2=(void **)b;
    void**temp1=(void**)(*aux1);
    void**temp2=(void**)(*aux2);
    
    double *num1,*num2;
    
    num1 = (double*)temp1[1];
    num2 = (double*)temp2[1];
    
    return (*num2-*num1);
}

void imprimenumero(ofstream &arch,void* dato){
    double *num;
    
    num = (double*)dato;
    arch << *num << endl;
    
}