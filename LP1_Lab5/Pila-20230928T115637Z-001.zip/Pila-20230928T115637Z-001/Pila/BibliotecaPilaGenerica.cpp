/* 
 * File:   BibliotecaPilaGenerica.cpp
 * Author: cueva
 * 
 * Created on 22 de octubre de 2022, 07:27 AM
 */
#include <fstream>
#include <iostream>
#include <cstdlib>
#include "BibliotecaPilaGenerica.h"

using namespace std;

void cargaarreglo(void *&arreglo,int(*cmp)(const void*,const void*),
        void*(*lee)(ifstream&),const char *nombre){
    void *buffer[200],**aux;
    int i=0;
    
    ifstream arch(nombre,ios::in);
    if(!arch){
        cout << "No se puede abrir el archivo";
        exit(1);
    }
    while(1){
        buffer[i]=lee(arch);
        if(buffer[i]==NULL) break;
        i++;
    }
    aux = new void*[i+1];
    for(int j=0;j<=i;j++)
        aux[j]=buffer[j];  
    
    qsort(aux,i,sizeof(void*),cmp);
    arreglo=aux;
}


void imprimepila(void *pila,
        void(*imprime)(ofstream&,void*),const char *nombre){
   void **dupla = (void**)pila;   
   int i=0;
   
   ofstream arch(nombre,ios::out);
   if(!arch){
        cout << "No se puede abrir el archivo";
        exit(1);
    }
   void**aux = (void**)dupla[0];
    while(aux){
       imprime(arch,aux[0]); 
       aux=(void**)aux[1];
   }
}

void generapila(void*&pila ){
    int *num;
    void **dupla=new void*[2];
    dupla[0] = NULL;
    num = new int;
    *num = 0;
    dupla[1] = num;
    pila = dupla;
}
int pilavacia(void *pila){
   void **dupla = (void**)pila; 
   
   if(dupla[0]==NULL) return 1;
   return 0;
    
}
void push(void *&pila,void*dato){
    void **aux = (void**)pila;
    void **nuevo;
    int *cont;
    nuevo = new void*[2];
    nuevo[0] = dato;
    nuevo[1] = NULL;
    
    if(pilavacia(pila))
        aux[0] = nuevo;
    else{
        nuevo[1] = aux[0];
        aux[0] = nuevo;
    }
    cont =(int*) aux[1];
    (*cont)++;
    
}
void cargapila(void *&pila,void*(*lee)(ifstream&),const char *nombre){
    void *aux;

    generapila(pila);
    ifstream arch(nombre,ios::in);
    if(!arch){
        cout << "No se puede abrir el archivo";
        exit(1);
    }
    while(1){
        aux = lee(arch);
        if(aux ==NULL) break;
        push(pila,aux);
    }

}
void *pop(void *&pila){
    void *dato=NULL;
    void **dupla=(void**)pila;
    int *cont;
    if(!pilavacia(pila)){
        void **aux = (void**) dupla[0];
        dato = aux[0];
        dupla[0] = aux[1];
        aux[1] = NULL;
        cont =(int*) dupla[1];
        (*cont)--;
        delete aux;
    }
    return dato;
}
