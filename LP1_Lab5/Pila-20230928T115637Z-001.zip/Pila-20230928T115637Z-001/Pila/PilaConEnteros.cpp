/* 
 * File:   PilaConEnteros.cpp
 * Author: cueva
 * 
 * Created on 22 de octubre de 2022, 07:28 AM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include "PilaConEnteros.h"


using namespace std;


void *leenumero(ifstream &arch){
    int aux,*num;
    
    arch >> aux;
    if(arch.eof()) return NULL;
    num = new int;
    *num =  aux;
    return num;
}
int cmpnumero(const void*a,const void*b){
    void**aux1=(void **)a;
    void**aux2=(void **)b;
    int *num1,*num2;
 
    num1 = (int*)aux1[0];
    num2 = (int*)aux2[0];
    
    return (*num2-*num1);
}

void imprimenumero(ofstream &arch,void* dato){
    int *num;
    
    num = (int*)dato;
    arch << *num<<endl;
    
}