/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   PilaConRegistros.cpp
 * Author: cueva
 * 
 * Created on 22 de octubre de 2022, 10:53 PM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
#include "PilaConRegistros.h"

using namespace std;

/*
60509,AMPICILINA 125MG SUSP 90ML,58.65
73972,VITAMINA E 400 MG C90 CAPS,54.4
94429,TIAMAZOL 5MG 20T,52.7
 */ 

void *leeregistro(ifstream &arch){
    int aux,*codigo;
    char *nombre, cadena[100];
    double *peso;
    void **registro;
    arch >> aux;
    if(arch.eof()) return NULL;
    codigo = new int;
    *codigo =  aux;
    arch.get();
    arch.getline(cadena,100,',');
    nombre = new char[strlen(cadena)+1];
    strcpy(nombre,cadena);
    peso = new double;
    arch >> *peso;
    registro = new void*[3];
    registro[0] = codigo;
    registro[1] = nombre;
    registro[2] = peso;
    
    return registro;
}

int cmpregistro(const void*a,const void*b){
    void**aux1=(void **)a;
    void**aux2=(void **)b;
    void**temp1=(void**)aux1[0];
    void**temp2=(void**)aux2[0];
    
    double *num1,*num2;
    
    num1 = (double*)temp1[2];
    num2 = (double*)temp2[2];
    
    return (*num2-*num1);
}

void imprimeregistro(ofstream &arch,void* dato){
    void **aux = (void**)dato;
    int *codigo;
    char *nombre;
    double *peso;
    
    codigo = (int*)aux[0];
    nombre = (char*)aux[1];
    peso = (double*)aux[2];
    
    arch <<setw(10)<<*codigo<<setw(40)<<nombre<<setprecision(2)<<
            fixed<<setw(10)<<*peso<<endl;
    
}