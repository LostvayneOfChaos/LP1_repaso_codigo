/* 
 * File:   main.cpp
 * Author: cueva
 *
 * Created on 22 de octubre de 2022, 07:26 AM
 */
#include "BibliotecaPilaGenerica.h"
#include "PilaConEnteros.h"
#include "PilaConRegistros.h"

using namespace std;

int main(int argc, char** argv) {
    void *pila;;

    cargapila(pila,leenumero,"numeros.txt");
    imprimepila(pila,imprimenumero,"repnumeros.txt");

    cargapila(pila,leeregistro,"medicinas.csv");
    imprimepila(pila,imprimeregistro,"repmedicinas.txt");
    

    return 0;
}

