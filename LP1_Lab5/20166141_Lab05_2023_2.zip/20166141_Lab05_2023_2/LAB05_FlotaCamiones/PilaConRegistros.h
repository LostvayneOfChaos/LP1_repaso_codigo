/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   PilaConRegistros.h
 * Author: alulab14
 *
 * Created on 2 de octubre de 2023, 05:54 PM
 */
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>

using namespace std;

#ifndef PILACONREGISTROS_H
#define PILACONREGISTROS_H



#endif /* PILACONREGISTROS_H */

