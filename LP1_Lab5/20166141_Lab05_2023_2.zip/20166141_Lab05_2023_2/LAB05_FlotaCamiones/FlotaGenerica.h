/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   FlotaGenerica.h
 * Author: alulab14
 *
 * Created on 2 de octubre de 2023, 05:54 PM
 */
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>

using namespace std;
#ifndef FLOTAGENERICA_H
#define FLOTAGENERICA_H

void cargacamiones(void* &flota,int numcamiones,
        int pesomaximo,void *(*lee)(ifstream &),
        double *(*calcular)(int , void* &),
        const char* nombreArchivo);
void push(void* &pila,void* dato);
int pilaVacia(void* & pila);





#endif /* FLOTAGENERICA_H */

