/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include <cstdlib>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
#include "PilaConEnteros.h"
#include "PilaConRegistros.h"
#include "FlotaGenerica.h"
using namespace std;






void * leenumero(ifstream & inNumeros){
    
    void*registro;
    double* cantidad;
    int valor;
    cantidad=new double;
    
    inNumeros>>valor;
    if(inNumeros.eof())return nullptr;
    inNumeros.get();
    *cantidad=valor;
    
    registro=cantidad;
    
    return registro;
    
    
    
    
    
    
}

double* calculanumero(int pesomaximo, void* &dato, void* & camion){
    
    //aca se casteara el valor de int y se evaluara para el camion el valor que entrara
    //devuelve null si no entra en el camion y sino si entra al camion
    
    
    *(double*)dato=*(double*)dato;
    
    //evaluar con el peso maximo
    void **auxCamion=(void**)camion;
    double peso=*(double*)auxCamion[1];
    double *valor;
    (valor)=(double*)dato;
    double nuevo;
    if((*valor)+peso <= pesomaximo){
        //push(camion,dato);
        return valor;
    }
    else
        return nullptr;
    
}

void imprimenumero(void*& camion ,ofstream & out){
    
    void**dupla=(void**)camion;
    void**aux=(void**)dupla[0];
    double *total=(double*)dupla[1];
    
    out<<*total<<endl;
    double *peso;
    if(aux==nullptr) exit(1);
    aux=(void**)aux[0];
    while (aux) {
       //imprimir valor o peso
        peso=(double*)aux[1];
        out<<*peso<<endl;
        aux=(void**)aux[0];
    }


    
    
    
}