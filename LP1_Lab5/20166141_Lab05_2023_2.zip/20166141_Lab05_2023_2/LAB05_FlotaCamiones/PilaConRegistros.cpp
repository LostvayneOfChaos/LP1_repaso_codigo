/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include <cstdlib>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
#include "PilaConEnteros.h"
#include "PilaConRegistros.h"
#include "FlotaGenerica.h"
using namespace std;


char* leerCadena(ifstream &inProductos,char delimitador){
    
    char cadena[100];
    char*nombre;
    inProductos.getline(cadena,100,delimitador);
    nombre=new char[strlen(cadena)+1];
    strcpy(nombre,cadena);
    
    return nombre;
    
}


void * leeregistro(ifstream & inNumeros){
    
    //Código Producto,DNI Cliente, Cantidad, Peso del pedido
    void**registro;
    double* cantidad,*peso;
    int *dni;
    dni=new int;
    cantidad=new double;
    peso=new double;
    char*codigo;
    char aux;
    codigo=leerCadena(inNumeros,',');
    if(inNumeros.eof())return nullptr;
    inNumeros>>*dni>>aux>>*cantidad>>aux>>*peso;
    inNumeros.get();
    
    registro=new void*[4];
    registro[0]=codigo;
    registro[1]=dni;
    registro[2]=cantidad;
    registro[3]=peso;
    
    return registro;
    
}




double* calcularegistro(int pesomaximo, void* &dato, void* & camion){
    
    //aca se casteara el valor de int y se evaluara para el camion el valor que entrara
    //devuelve null si no entra en el camion y sino si entra al camion
    
    
    double * contador;
    //evaluar con el peso maximo
    void **auxCamion=(void**)camion;
    double peso=*(double*)auxCamion[1];
    void**auxDato=(void**)dato;
    *(double*)auxDato[3]=*(double*)auxDato[3];
    double *valor=(double*)auxDato[3];
    double nuevo;
    if((*valor)+peso <= pesomaximo){
        //push(camion,dato);
        
        contador=(double*)auxCamion[1];
        double* valor=(double*)auxDato[3];
        (*contador)+=(*valor);
        return valor;
        
    }
    else{
        
        return nullptr;
    }
}



int cmpregistro(const void*a ,const void *b){
    
    void**ai=(void**)a;
    void**bi=(void**)b;
    void**registro_a=(void**)*ai;
    void**registro_b=(void**)*bi;
    
    double*pesoA=(double*)registro_a[1];
    double*pesoB=(double*)registro_b[1];
    
    return (*pesoB)- (*pesoA);

    
    
    
    
    
}


void imprimeregistro(void*& camion ,ofstream & out){
    
    void**dupla=(void**)camion;
    void**aux=(void**)dupla[0];
    double *total=(double*)dupla[1];
    
    out<<*total<<endl;
    /*if(aux==nullptr) exit(1);
    aux=(void**)aux[0];*/
    char*codigo;
    double *cantidad;
    double *peso;
    void**registro;
    while (aux) {
       //imprimir valores
        registro=(void**)aux[1];
        codigo=(char*)registro[0];
        cantidad=(double*)registro[2];
        peso=(double*)registro[3];
        out<<codigo<<"  "<<*cantidad<<"  "<<*peso<<"  "<<endl;
        aux=(void**)aux[0];
    }


    
    
    
}