/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   PilaConEnteros.h
 * Author: alulab14
 *
 * Created on 2 de octubre de 2023, 05:54 PM
 */
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>

using namespace std;

#ifndef PILACONENTEROS_H
#define PILACONENTEROS_H

void * leenumero(ifstream & inNumeros);
double* calculanumero(int pesomaximo, void* & camion);


#endif /* PILACONENTEROS_H */

