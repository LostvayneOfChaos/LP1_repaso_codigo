/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
#include "PilaConEnteros.h"
#include "PilaConRegistros.h"
#include "FlotaGenerica.h"
using namespace std;


int pilaVacia(void* & pila){
    
    void **dupla=(void**)pila;
    if ((*(double*)dupla[1]==0)||(dupla[0]==nullptr)) {
        return 1;
    }
    return 0;
    
} 

void push(void* &pila,void* dato){
    
    void**aux=(void**)pila;
    void**nuevo;
    double *contador;
    nuevo=new void*[2];
    nuevo[1]=dato;
    nuevo[0]=nullptr;
    
    if (pilaVacia(pila)) {
        aux[0]=nuevo;
        
    } else {
        nuevo[0]=aux[0];
        aux[0]=nuevo;
        
    }
    
    //actualizar peso total
    
    contador=(double*)aux[1];
    double* valor=(double*)dato;
    (*contador)+=(*valor);
    
    
    
}


void cargacamiones(void* &flota,int numcamiones,
        int pesomaximo,void *(*lee)(ifstream &),
        double *(*calcular)(int , void* &,void* &),
        const char* nombreArchivo){
    
    void*aux;
    void**camion;
    void**auxCamion;
    //generar pila
    void**auxFlota;
    auxFlota=new void*[numcamiones]{};
    double* num;
    for (int i = 0; i < numcamiones; i++) {
        auxCamion=new void*[2]{};
        auxCamion[0]=nullptr;
        num=new double;
        *num=0;
        auxCamion[1]=num;
        auxFlota[i]=auxCamion;
    }
    flota=auxFlota;
    //fin generar pila
    ifstream inCamiones(nombreArchivo,ios::in);
    if (!inCamiones) {
        
        cout<<"error al abrir el archivo";
        exit(1);
    }
    while (1) {
        aux=lee(inCamiones);
        if(aux==nullptr) break;
        //evaluar para el aux si entra en la pila
        auxFlota=(void**)flota;
        for (int i = 0; i < numcamiones; i++) {
            
            if(pilaVacia(auxFlota[i])){
                
                push(auxFlota[i],aux);//apilas y actualizas el peso total
                break;
                
            }
            else{
                
                double* pesoPaquete=calcular(pesomaximo,aux,auxFlota[i]);
                if(pesoPaquete!=nullptr){
                    push(auxFlota[i],aux);
                    break;
                }
                
            }
            //si es nullptr ,no puedo colocar el pedido en el camion actual
            
        }
        
    }
    
    flota=auxFlota;
    inCamiones.close();
}


void muestracamiones(void* &flota,int numcamiones,void (*imprimir)(void*&,ofstream &),const char* nombreArchivo){
    
    void**camion=(void**)flota;
    void* auxCamion;
    ofstream outCamiones(nombreArchivo,ios::out);
    if (!outCamiones) {
        
        cout<<"error al abrir el archivo";
        exit(1);
    }

    
    
    for (int i = 0; i<numcamiones; i++) {
        auxCamion=camion[i];
        outCamiones<<"Camion "<<i<<": "<<"Peso : ";
        imprimir(auxCamion,outCamiones);
        outCamiones<<endl;
    }
    
    outCamiones.close();
}

