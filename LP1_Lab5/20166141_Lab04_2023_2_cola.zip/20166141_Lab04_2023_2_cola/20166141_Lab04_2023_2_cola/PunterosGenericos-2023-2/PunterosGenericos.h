/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   PunterosGenericos.h
 * Author: alulab14
 *
 * Created on 22 de septiembre de 2023, 08:05 AM
 */
#include <fstream>
#include <iostream>
#include <cstring>
#include <iomanip>

using namespace std;


#ifndef PUNTEROSGENERICOS_H
#define PUNTEROSGENERICOS_H

void cargaproductos(void * &productos);
void * leerProducto(ifstream &inProductos);
char* leerCadena(ifstream &inProductos,char delimitador);
void cargaclientes(void * &clientes);
void * leerCliente(ifstream &in);
void cargapedidos(void*& productos,void* &clientes);
void * leerPedidoYAgregarCliente(ifstream &in,
        void*& productos,void* &clientes);
void imprimirClientesv2(void* &clientes);
void imprimerep(void* &clientes);
void ordenarPedidosXCliente(void* & clientes);
void crearCola(void* &clientes, void*(*)(ifstream &));
void imprimirCola(void* &clientes,void (*imprimirRegistro)
(ofstream &,void *&));
void imprimirClienteFinv2(ofstream &out,void *&cliente);
void eliminarCola(void* &clientes,void* (*eliminarRegistro)(void**&));
void ordenarColaPedidosXCliente(void* & clientes);
#endif /* PUNTEROSGENERICOS_H */

