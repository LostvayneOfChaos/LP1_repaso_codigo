/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Axel mendoza 20166141
 *
 * Created on 22 de septiembre de 2023, 08:03 AM
 */

#include "PunterosGenericos.h"
#include "MuestraPunteros.h"
#include "FuncionesVoid.h"
#include <fstream>
#include <iostream>
#include <cstring>
#include <iomanip>
#include <cstdlib>
using namespace std;

/*
 * 
 */


enum registroCliente{DNICLIENTE,NOMBRECLIENTE,
LINEACREDITOCLIENTE,LISTAPEDIDOSCLIENTE};


int main(int argc, char** argv) {
    
    void *productos,*clientes;
    
    
    cargaproductos(productos);
    imprimeproductos(productos);
    
    
    crearCola(clientes,leerCliente);
    
    //eliminarCola(clientes,desencolar);
    
    cout<<clientes<<endl;
    
    
    /*cargaclientes(clientes);
     imprimirClientesv2(clientes);*/
    
    cargapedidos(productos,clientes);
    ordenarColaPedidosXCliente(clientes);
    
    
    
    //ordenarPedidosXCliente(clientes);
    imprimirCola(clientes,imprimirClienteFinv2);
    
    //imprimerepfinal(clientes);
   
    
    return 0;
}

