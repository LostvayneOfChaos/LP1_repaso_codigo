/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   FuncionesVoid.h
 * Author: alulab14
 *
 * Created on 26 de septiembre de 2023, 07:23 PM
 */

#ifndef FUNCIONESVOID_H
#define FUNCIONESVOID_H

int compararCodigos(const void*a,const void * b);
int compararCodigoPropia(const void*a,const void * b);
void encolar(void*&clientes,void* &dato);
void* desencolar(void**& cola);

#endif /* FUNCIONESVOID_H */

