/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include "PunterosGenericos.h"
#include "MuestraPunteros.h"
#include "FuncionesVoid.h"
#include <fstream>
#include <iostream>
#include <cstring>
#include <iomanip>
#include <cstdlib>


using namespace std;
//memoria exacta
//verificas cuando tienes S solamente.Linea de credito es double
//tipo linea considerar como char

enum registroProd{CODIGOPROD,DESCRIPCIONPROD,PRECIOPROD,LINEAPROD};
enum registroPedido{CODIGOPRODPEDIDO,CANTIDADPRODPEDIDO,
TOTALPRODPEDIDO};
enum registroCliente{DNICLIENTE,NOMBRECLIENTE,
LINEACREDITOCLIENTE,LISTAPEDIDOSCLIENTE};

char* leerCadena(ifstream &inProductos,char delimitador){
    
    char cadena[100];
    char*nombre;
    inProductos.getline(cadena,100,delimitador);
    nombre=new char[strlen(cadena)+1];
    strcpy(nombre,cadena);
    
    return nombre;
    
}


void * leerProducto(ifstream &inProductos){
    
    char*codigo,* descripcion,*linea;
    double* precio;
    char aux;
    void**registroProd;
    precio=new double;
    
    codigo=leerCadena(inProductos,',');
    if(inProductos.eof()) return nullptr;
    descripcion=leerCadena(inProductos,',');
    inProductos>>*precio>>aux;
    linea=new char;
    (*linea)=inProductos.get();
    inProductos.get();
    registroProd=new void*[4];
    registroProd[CODIGOPROD]=codigo;
    registroProd[DESCRIPCIONPROD]=descripcion;
    registroProd[PRECIOPROD]=precio;
    registroProd[LINEAPROD]=linea;
    
    return registroProd;
    
    
    
    
}









void cargaproductos(void * &productos){
    //BIT-434,Campana Extractora modelo Glass,375.09,S
    
    ifstream inProductos("Productos2.csv",ios::in);
    if (!inProductos) {
        cout<<"error al abrir el archivo ";
        exit(1);
    }
    
    void*bufferProd[500]{},*registro,**registroProd;
    int nDatos=0;
    productos=nullptr;
    registroProd=nullptr;
    while (true) {
        registro=leerProducto(inProductos);
        //if(inProductos.eof()) break;
        if(registro==nullptr) break;
        bufferProd[nDatos]=registro;
        nDatos++;
        
        
    }
    //tope
    bufferProd[nDatos]=nullptr;
    nDatos++;
    
    registroProd=new void*[nDatos];
    for (int i = 0; i < nDatos; i++) {
        registroProd[i]=bufferProd[i];
    }
   /* void**re=(void**)registroProd[0];
    cout<<(char*)re[CODIGOPROD]<<endl;*/
    productos=registroProd;
    
    inProductos.close();
}



void * leerCliente(ifstream &in){
    
    char*nombre;
    double* credito;
    //int*credito;
    char aux;
    int *telefono,*dni;
    void**registroCliente;
    
    //credito=new double;
    credito=new double;
    telefono=new int;
    dni=new int;
    //DNI, nombre, telefono y línea de crédito
    
    in>>*dni;
    if(in.eof()) return nullptr;
    in.get();
    nombre=leerCadena(in,',');
    in>>*telefono;
    in.get();
    in>>*credito;
    in.get();
    registroCliente=new void*[4]{};
    
    int *a;
    a=new int;
    *a=5;
    registroCliente[DNICLIENTE]=dni;
    registroCliente[NOMBRECLIENTE]=nombre;
    registroCliente[LINEACREDITOCLIENTE]=credito;
    registroCliente[LISTAPEDIDOSCLIENTE]=nullptr;
    
    return registroCliente;
    
    
    
    
}
void cargaclientes(void * &clientes){
    
    
    ifstream inClientes("Clientes2.csv",ios::in);
    if (!inClientes) {
        cout<<"error al abrir el archivo ";
        exit(1);
    }
    
    void*bufferClientes[500]{},*registro,**registroClientes;
    int nDatos=0;
    clientes=nullptr;
    
    while (true) {
        registro=leerCliente(inClientes);
        //if(inClientes.eof()) break;
        if(registro ==nullptr) break;
        
        bufferClientes[nDatos]=registro;
        nDatos++;
        
        
    }
    //tope
    bufferClientes[nDatos]=nullptr;
    nDatos++;
    
    registroClientes=new void*[nDatos];
    for (int i = 0; i < nDatos; i++) {
        registroClientes[i]=bufferClientes[i];
    }
    
    clientes=registroClientes;
    
    void**reg=(void**)clientes;
    void**re;
    
    for (int i = 0; reg[i]; i++) {
        
        re=(void**)reg[i];
        
        cout<<*(int*)re[DNICLIENTE]<<endl;
        cout<<*(double*)re[LINEACREDITOCLIENTE]<<endl;
        cout<<(char*)re[NOMBRECLIENTE]<<endl;
        cout<< re[LISTAPEDIDOSCLIENTE]<<endl;
        
        
    }
    
    /*void**reg=(void**)clientes;
    void**re=(void**)reg[0];
    
    cout<<*(int*)re[DNICLIENTE]<<endl;
    cout<<*(double*)re[LINEACREDITOCLIENTE]<<endl;
    cout<<(char*)re[NOMBRECLIENTE]<<endl;
    cout<<(char*)re[LISTAPEDIDOSCLIENTE]<<endl;*/
    
    
    inClientes.close();
    
    
}



void * leerPedidoYAgregarCliente(ifstream &in,
        void*& productos,void* &clientes,int* &dniEnviar){
    //Código del producto, DNI del cliente y cantidad.
    
    char*codigo;
    char aux;
    int *cantidad,*dni,pos;
    void**registroPedido;
    void**cliente=(void**)clientes;
    void**prod=(void**)productos;
    double* total;
    total=new double;
    int bandera=0;
    cantidad=new int;
    dni=new int;
    
    codigo=leerCadena(in,',');
    if(in.eof()) return nullptr;
    in>>*dni>>aux>>*cantidad;
    in.get();
    
    for (int i = 0;prod[i]; i++) {
        void**registroProd=(void**)prod[i];
        void**voidCodigo=(void**)registroProd[CODIGOPROD];
        void**voidLinea=(void**)registroProd[LINEAPROD];
        void**voidPrecio=(void**)registroProd[PRECIOPROD];
        
        if((strcmp(codigo,(char*)voidCodigo))==0){
            *total=(*cantidad)*(*(double*)voidPrecio);
            bandera=1;
            if((*(char*)voidLinea)=='N'){
                
                registroPedido=new void*[3];
                registroPedido[CANTIDADPRODPEDIDO]=cantidad;
                registroPedido[CODIGOPRODPEDIDO]=codigo;
                registroPedido[TOTALPRODPEDIDO]=total;
                dniEnviar=dni;
                return registroPedido;
            }
            else break;
            
        }
        
        
    }
    
    if (bandera) {
        //lueogo de comprobar que estado es 'S'  y tengo el  valor total
    while(cliente){
        
        void**registroCliente=(void**)cliente[0];
        if(registroCliente==nullptr) break;
        void**voidCredito=(void**)registroCliente[LINEACREDITOCLIENTE];
        void**voidDni=(void**)registroCliente[DNICLIENTE];
        double* credito=(double*)voidCredito;
        if(((*dni==(*(int*)voidDni)))){
            
            if(((*credito)-(*total))>=0){
                
                double* restante;
                restante= new double;
                *restante=((*credito)-(*total));
                registroCliente[LINEACREDITOCLIENTE]=restante;
                registroPedido=new void*[3];
                registroPedido[CANTIDADPRODPEDIDO]=cantidad;
                registroPedido[CODIGOPRODPEDIDO]=codigo;
                registroPedido[TOTALPRODPEDIDO]=total;
                dniEnviar=dni;
                
                return registroPedido;
            }
            else break;
            
        }
        cliente=(void**)cliente[1];
    }
        return nullptr;
        
        
        
  }

    else return nullptr;
    
    
    
    /*registroPedido=new void*[3];
    registroCliente[CANTIDADPRODPEDIDO]=cantidad;
    registroCliente[CODIGOPRODPEDIDO]=codigo;
    return registroCliente;*/
    
    
    
    
}

void insertarPedido(void * & posicion,void * &registro){
    
    void** registroPedido=(void**) registro;
    void** registroPedidoCliente= new void*[4];
    
    
    registroPedidoCliente[DNICLIENTE]=registroPedido[DNICLIENTE];
    registroPedidoCliente[NOMBRECLIENTE]=registroPedido[NOMBRECLIENTE];
    registroPedidoCliente[LINEACREDITOCLIENTE]=registroPedido[LINEACREDITOCLIENTE];
    registroPedidoCliente[LISTAPEDIDOSCLIENTE]=registroPedido[LISTAPEDIDOSCLIENTE];
    
    
    posicion=registroPedidoCliente;
    
}




void agregarPedido(void* &registro,void* &cliente,
                               int &nPedidos){
    
    void **registroCliente=(void **) cliente;
    void **registroPedido=(void **) registro;
    
    if (nPedidos==0) {
        
        void **bufferPedidos=new void*[500]{};
        registroCliente[LISTAPEDIDOSCLIENTE]=bufferPedidos;
    }
    void**pedido=(void**) registroCliente[LISTAPEDIDOSCLIENTE];
    //insertarPedido(pedido[nPedidos],registro);
    pedido[nPedidos]=registro;
    cliente=registroCliente;
    nPedidos++;
    
}

    
    
void asignarMemoriaExactaEnPedidos(void *& clientes, int* nPedidos){
    int nClientes = 0, i;
    void **auxPedidos, **registroCliente, **auxNuevo;
    void **auxClientes = (void **)clientes;
    for(nClientes; auxClientes[nClientes]; nClientes++){
        registroCliente = (void**) auxClientes[nClientes];
        if(nPedidos[nClientes] > 0){    
            auxPedidos = (void**) registroCliente[LISTAPEDIDOSCLIENTE];
            auxNuevo = new void*[nPedidos[nClientes]+1];
            for(i=0; i<nPedidos[nClientes]; i++)
                auxNuevo[i] = auxPedidos[i];
            auxNuevo[i] = nullptr;
            auxPedidos = auxNuevo;
        } else {
            auxPedidos = nullptr;
        }
        registroCliente[LISTAPEDIDOSCLIENTE] = auxPedidos;
        auxClientes[nClientes] = registroCliente;
    }
    clientes = auxClientes;
}
    
    
    




void cargapedidos(void*& productos,void* &clientes){
    
    ifstream inPedidos("Pedidos2.csv",ios::in);
    if (!inPedidos) {
        cout<<"error al abrir el archivo ";
        exit(1);
    }
    
    void*bufferPedidos[1000]{},
            *registro,**cliente,**registroProd;
    int nDatos=0;
    cliente=(void**)clientes;
    registroProd=(void**)productos;
    int pos;
    int nPedidosXcliente[700]{};
    int *dni;
    dni=nullptr;
    while (true) {
        registro=nullptr;
        dni=nullptr;
        registro=leerPedidoYAgregarCliente(inPedidos,
                productos,clientes,dni);
        //
        if(inPedidos.eof()) break;
        if(registro==nullptr) break;
        
        if (registro && dni) {
            //registro ya se reservo con espacio porque si puedo agregarlo
            //buscaras en cliente para colocarlo
            //cout<<*dni<<endl;
            while(cliente) {
                   
                   void**registroCliente=(void**)cliente[0];
                   if(registroCliente==nullptr) break;
                   void**voidDni=(void**)registroCliente[DNICLIENTE];
                    if(((*dni==(*(int*)voidDni)))){
                       //pos=i; 
                       agregarPedido(registro,cliente[0],
                               nPedidosXcliente[pos]);
                       break;
                    }
                
                   cliente=(void**)cliente[1];
            }
        }
        
    }
    
    //asignarMemoriaExactaEnPedidos(clientes,nPedidosXcliente);
    inPedidos.close();
    
}

void imprimirClienteFin(ofstream &out,void *&cliente){
    
    void **registroCliente,*registro;
    registroCliente=(void**)cliente;
    
    int*codigo,*cantidad,*dni,*fecha;
    char*nombre,aux,*estado;
    double *credito;
    nombre=(char*)registroCliente[NOMBRECLIENTE];
    dni=(int*)registroCliente[DNICLIENTE];
    credito=(double*)registroCliente[LINEACREDITOCLIENTE];
    
    out<<"  "<<*dni
            <<"  "<<nombre<<"  " <<*credito <<endl;
    
}

void imprimirClientesv2(void* &clientes){
    
    
    ofstream outClientes("Clientes.txt",ios::out);
    if (!outClientes) {
        cout<<"error al abrir el archivo ";
        exit (1);
    }
    void **registroClientes,*registro;
    registroClientes=(void**)clientes;
    
    for (int i = 0; registroClientes[i]; i++) {
        //cout<<i<<endl;
        imprimirClienteFin(outClientes,registroClientes[i]);
    }
    
    outClientes.close();
    
    
    
    
}

void imprimirDetallesPedido(ofstream &out,
        void *&pedido){
    
    void **registroPedido,*registro;
    registroPedido=(void**)pedido;
    
    char*codigo;
    int *cantidad;
    double * total;
    char*descripcion,aux;
    //enum registroPedido{CODIGOPRODPEDIDO,CANTIDADPRODPEDIDO,TOTALPRODPEDIDO};
    codigo=(char*)registroPedido[CODIGOPRODPEDIDO];
    cantidad=(int*)registroPedido[CANTIDADPRODPEDIDO];
    total=(double*)registroPedido[TOTALPRODPEDIDO];
    
    out<<"  "<<codigo
            <<"  "<<*cantidad
            <<"  "<<*total<<endl;
    
    
    
}
void imprimirPedidoXCliente
            (ofstream &out,void * & pedido){
    
    void**registroPed=(void**)pedido;
    
    for (int i = 0; registroPed[i]; i++) {
        imprimirDetallesPedido(out,registroPed[i]);
    }
    
    
}


void imprimirClienteFinv2(ofstream &out,void *&cliente){
    
    void **registroCliente,*registro;
    registroCliente=(void**)cliente;
    
    int*codigo,*cantidad,*dni,*fecha;
    char*nombre,aux,*estado;
    double *credito;
    nombre=(char*)registroCliente[NOMBRECLIENTE];
    dni=(int*)registroCliente[DNICLIENTE];
    credito=(double*)registroCliente[LINEACREDITOCLIENTE];
    
    out<<"  "<<*dni
            <<"  "<<nombre<<"  " <<*credito <<endl;
    
    out<<"---------------------------"<<endl;
    if(registroCliente[LISTAPEDIDOSCLIENTE])
    imprimirPedidoXCliente
            (out,registroCliente[LISTAPEDIDOSCLIENTE]);
    else
        out<<" NO hay pedidos "<<endl;
    
    out<<"---------------------------"<<endl;
    
}
void imprimerep(void* &clientes){
    
    
    ofstream outClientes("ReporteClientesConPedidos.txt",ios::out);
    if (!outClientes) {
        cout<<"error al abrir el archivo ";
        exit (1);
    }
    void **registroClientes,*registro;
    registroClientes=(void**)clientes;
    
    for (int i = 0; registroClientes[i]; i++) {
        //cout<<i<<endl;
        imprimirClienteFinv2(outClientes,registroClientes[i]);
    }
    
    outClientes.close();
    
}

void cambiar(void ** arr, int i, int j){
    void* aux;
    aux = arr[i];
    arr[i] = arr[j];
    arr[j] = aux;
}

void ordenarPedidoPropia(void** pedido,
        int limiteIzq,int limiteDer,int(*comparar)(const void*, const void*)){
    
    //void**arreglo=(void**)pedido;
    int limite;
    if (limiteIzq>=limiteDer) {
        return;
    }
    cambiar(pedido,limiteIzq,(limiteIzq+limiteDer)/2);
    limite=limiteIzq;
    
    for (int i = limiteIzq+1; i <= limiteDer; i++) {
        if(comparar(pedido[limiteIzq],pedido[i])>0)
            cambiar(pedido,++limite,i);
        
        
    }
    
    cambiar(pedido,limiteIzq,limite);
    ordenarPedidoPropia(pedido,limiteIzq,limite-1,comparar);
    ordenarPedidoPropia(pedido,limite+1,limiteDer,comparar);

    
    
    
    
}



void ordenarPedidosXCliente(void* & clientes){
    
    
    void**registroClientes=(void**)clientes;
    int nDatos;
    for (int i = 0; registroClientes[i]; i++) {
        nDatos=0;
        void**registroCliente;
        registroCliente=(void**)registroClientes[i];
        void** pedido=(void**)registroCliente[LISTAPEDIDOSCLIENTE];
        
        if(pedido){
            for (int j = 0; pedido[j]; j++) {
            nDatos++;
            }
        
        
            //qsort(pedido,nDatos,sizeof(void*),compararCodigos);
            //
            //ES valido con ambas
            /*ordenarPedidoPropia(registroCliente[LISTAPEDIDOSCLIENTE],
                    0,nDatos-1,compararCodigoPropia);*/
            ordenarPedidoPropia(pedido,
                    0,nDatos-1,compararCodigoPropia);
        }
        
    }
    
}



void crearCola(void* &clientes, void*(*leerRegistro)(ifstream &)){
    
    clientes=nullptr;
    void* dato;
    ifstream inCliente("Clientes2.csv",ios::in);
    if (!inCliente) {
        cout<<"error al abrir el archivo";
        exit(1);
        
    }

    
    while (true) {
        dato=leerRegistro(inCliente);
        if(dato==nullptr) break;
        encolar(clientes,dato);
    }

    
    inCliente.close();
}



void imprimirCola(void* &clientes,void (*imprimirRegistro)
(ofstream &,void *&)){
    
    void* dato;
    ofstream outCliente("ReporteColaClientes.txt",ios::out);
    if (!outCliente) {
        cout<<"error al abrir el archivo";
        exit(1);
        
    }
    void**registroCliente=(void**)clientes;
    
    while (registroCliente) {
        imprimirRegistro(outCliente,registroCliente[0]);
        registroCliente=(void**)registroCliente[1];
    }

    
    outCliente.close();
    
}


void eliminarCola(void* &clientes,void* (*eliminarRegistro)(void**&)){
    
    
    void* dato;
    ofstream outCliente("ReporteEliminarColaClientes.txt",ios::out);
    if (!outCliente) {
        cout<<"error al abrir el archivo";
        exit(1);
        
    }
    void**registroCliente=(void**)clientes;
    
    while (registroCliente) {
        dato=eliminarRegistro(registroCliente);
        if((dato==nullptr)||(registroCliente==nullptr)) break;
        imprimirClienteFinv2(outCliente,dato);
        registroCliente=(void**)registroCliente[1];
    }

    
    outCliente.close();
    
    
    
    
    
}