/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include "PunterosGenericos.h"
#include "MuestraPunteros.h"
#include "FuncionesVoid.h"
#include <fstream>
#include <iostream>
#include <cstring>
#include <iomanip>
#include <cstdlib>

enum registroPedido{CODIGOPRODPEDIDO,CANTIDADPRODPEDIDO,
TOTALPRODPEDIDO};

int compararCodigos(const void*a,const void * b){
    
    void**ai=(void**)a;
    void**registro_ai=(void**)(*ai);
    void**bi=(void**)b;
    void**registro_bi=(void**)(*bi);
    char*codigo_a=(char*)registro_ai[0]; //hace referencia al codigo
    char*codigo_b=(char*)registro_bi[0];
    
    
    return (strcmp(codigo_a,codigo_b));//descendente
    
    
}

int compararCodigoPropia(const void*a,const void * b){
    
    void**registro_ai=(void**)(a);
    void**registro_bi=(void**)(b);
    
    char*codigo_a=(char*)registro_ai[0]; //hace referencia al codigo
    char*codigo_b=(char*)registro_bi[0];
    
    
    return (strcmp(codigo_a,codigo_b));//descendente
    
    
}


void encolar(void* &_cola,void* &dato){
    
    void**cola=(void**)_cola;
    void**anterior=nullptr;
    void**nodo;
    
    nodo=new void*[2]{};
    nodo[0]=dato;
    
    while (cola) {
        if(cola[1]==nullptr) break;
        
        anterior=cola;
        cola=(void**)cola[1];
        
    }
    
    if (cola==nullptr) {
        _cola=nodo;
    }
    else{
        cola[1]=nodo;
        
    }
    
}

void* desencolar(void**& cola){
    
    
    void**recorrido,**ultimo;
    void*registro;
    if (cola !=nullptr) {
        
        recorrido=cola;
        cola=(void**)cola[1];
        registro=recorrido[0];
        delete recorrido;
        return registro;
    }
    else
        return nullptr;
    
    
    
    
}