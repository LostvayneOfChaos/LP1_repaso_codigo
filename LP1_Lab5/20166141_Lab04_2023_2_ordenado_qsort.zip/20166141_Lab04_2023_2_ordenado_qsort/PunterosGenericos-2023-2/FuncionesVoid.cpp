/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include "PunterosGenericos.h"
#include "MuestraPunteros.h"
#include "FuncionesVoid.h"
#include <fstream>
#include <iostream>
#include <cstring>
#include <iomanip>
#include <cstdlib>

enum registroPedido{CODIGOPRODPEDIDO,CANTIDADPRODPEDIDO,
TOTALPRODPEDIDO};

int compararCodigos(const void*a,const void * b){
    
    void**ai=(void**)a;
    void**registro_ai=(void**)(*ai);
    void**bi=(void**)b;
    void**registro_bi=(void**)(*bi);
    char*codigo_a=(char*)registro_ai[0]; //hace referencia al codigo
    char*codigo_b=(char*)registro_bi[0];
    
    
    return (strcmp(codigo_a,codigo_b));//descendente
    
    
}

int compararCodigoPropia(const void*a,const void * b){
    
    void**registro_ai=(void**)(a);
    void**registro_bi=(void**)(b);
    
    char*codigo_a=(char*)registro_ai[0]; //hace referencia al codigo
    char*codigo_b=(char*)registro_bi[0];
    
    
    return (strcmp(codigo_a,codigo_b));//descendente
    
    
}