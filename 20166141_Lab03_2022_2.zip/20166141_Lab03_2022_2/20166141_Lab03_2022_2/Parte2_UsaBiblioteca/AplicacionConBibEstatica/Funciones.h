/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Funciones.h
 * Author: AXEL
 *
 * Created on 30 de agosto de 2023, 06:14 PM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
using namespace std;
#ifndef FUNCIONES_H
#define FUNCIONES_H

void leerMedico(ifstream & inMedicos,StMedico*medicos);
void leerPaciente(ifstream &inPacientes,StPaciente*pacientes);
void leerCita(ifstream &inCitas,StPaciente *pacientes,StMedico*medicos);
void imprimirReporte(ofstream&out,StPaciente *pacientes);
void IncluirEnPaciente(StPaciente *pacientes,StCita cita,int dni);



#endif /* FUNCIONES_H */

