/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: AXEL
 *
 * Created on 30 de agosto de 2023, 06:02 PM
 */

#include <iostream>
#include <iomanip>
#include <fstream>
#include "AperturaDeArchivos.h"
#include "Estructuras.h"
#include "sobrecargas.h"
#include "Funciones.h"

using namespace std;


/*
 * 
 */
int main(int argc, char** argv) {
    
    ifstream inMedicos,inPacientes,inCitas;
    ofstream out;
    AperturaDeUnArchivoDeTextosParaLeer(inMedicos,"MedicosLab3.txt");
    AperturaDeUnArchivoDeTextosParaLeer(inPacientes,"PacientesLab3.txt");
    AperturaDeUnArchivoDeTextosParaLeer(inCitas,"ConsultasLab3.txt");
    AperturaDeUnArchivoDeTextosParaEscribir(out,"Reporte.txt");
    StMedico medicos[100];
    StPaciente pacientes[100];
    
    leerMedico(inMedicos,medicos);
    leerPaciente(inPacientes,pacientes);
    leerCita(inCitas,pacientes,medicos);
    
    imprimirReporte(out,pacientes);
    
    inCitas.close();
    inPacientes.close();
    inMedicos.close();
    out.close();
    return 0;
}

