/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include "AperturaDeArchivos.h"
#include "Estructuras.h"
#include "sobrecargas.h"
#include "Funciones.h"
using namespace std;
void leerMedico(ifstream & inMedicos,StMedico*medicos){
    //506117   EDGAR_MUNOZ_VERGEL_Urologia   337.03
    
    bool result;
    StMedico medico;
    int i=0;
    while(true) {
        result= inMedicos>>medico;
        
        if (result ==false) {
            medicos[i].codigo=0;
            break;
        }
        
        medicos[i]=medico;
        i++;
    }
    
}


void leerPaciente(ifstream &inPacientes,StPaciente*pacientes){
    
    bool result;
    StPaciente paciente;
    int i=0;
    while(true) {
        result= inPacientes>>paciente;
        
        if (result ==false) {
            pacientes[i].dni=0;
            break;
        }
        
        pacientes[i]=paciente;
        i++;
    }
    
    
}
void IncluirEnPaciente(StPaciente *pacientes,StCita cita,int dni){
    
    int i=0;
    while (true) {
        if(pacientes[i].dni==0) break;
        if(pacientes[i].dni==dni){
            pacientes[i]+=cita;
            ++pacientes[i];
            break;
        }
        i++;
        
        
    }

    
    
    
    
}

void leerCita(ifstream &inCitas,StPaciente *pacientes,StMedico*medicos){
    
    
    //(DNI_del_paciente código_del_médico fecha)
    int dni;
    bool result;
    StCita cita;
    while(true) {
        dni= inCitas>>cita;
        
        if (dni ==-1) {
            break;
        }
        result=cita<=medicos;
        
        if(result==true){
            
            IncluirEnPaciente(pacientes,cita,dni);
            
            
        }
    }
    
}



void imprimirReporte(ofstream&out,StPaciente *pacientes){
    
    int i=0;
    cout<<setw(50)<<"EMPRESA PRESTADORA DE SALUD LP1"<<endl;
    cout<<setw(50)<<"PACIENTES QUE FUERON ATENDIDOS"<<endl;
    while (true) {
        cout<<setw(10)<<setfill('-')<<' '<<endl;
        cout<<setfill(' ');
        out<<pacientes[i];
        if(pacientes[i].dni==0) break;
        
        i++;
    }

    
    
    
}