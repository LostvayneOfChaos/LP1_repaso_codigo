/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Nota.cpp
 * Author: AXEL
 * 
 * Created on 24 de octubre de 2023, 11:20 AM
 */

#include "Nota.h"

Nota::Nota() {
}

Nota::Nota(const Nota& orig) {
}

Nota::~Nota() {
}

void Nota::operator &(class AlumnoNota& alumno, 
        class Nota &nota ){
    
    //carga a Nota
    
    nota.SetCiclo(alumno.GetCiclo());
    nota.SetCodCurso(alumno.GetCodcurso());
    nota.SetNota(alumno.GetNota());
    
    
}

void Nota::SetNota(int nota) {
    this->nota = nota;
}

int Nota::GetNota() const {
    return nota;
}

void Nota::SetCiclo(int ciclo) {
    this->ciclo = ciclo;
}

int Nota::GetCiclo() const {
    return ciclo;
}

void Nota::SetCodCurso(char* codCurso) {
    this->codCurso = codCurso;
}

char* Nota::GetCodCurso() const {
    return codCurso;
}

