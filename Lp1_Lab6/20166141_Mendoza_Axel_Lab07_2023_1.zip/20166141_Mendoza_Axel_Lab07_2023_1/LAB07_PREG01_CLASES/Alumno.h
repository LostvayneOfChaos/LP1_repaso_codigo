/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Alumno.h
 * Author: AXEL
 *
 * Created on 24 de octubre de 2023, 11:21 AM
 */
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>
#include "Nota.h"
#include "Funciones.h"
using namespace std;

#ifndef ALUMNO_H
#define ALUMNO_H

class Alumno {
public:
    Alumno();
    Alumno(const Alumno& orig);
    virtual ~Alumno();
    void SetNumTercera(int numTercera);
    int GetNumTercera() const;
    void SetNumSegunda(int numSegunda);
    int GetNumSegunda() const;
    void SetNumPrimera(int numPrimera);
    int GetNumPrimera() const;
    void SetNumAprobados(int numAprobados);
    int GetNumAprobados() const;
    void SetNumCursos(int numCursos);
    int GetNumCursos() const;
    void SetNombre(char* nombre);
    char* GetNombre() const;
    void SetCodigo(int codigo);
    int GetCodigo() const;
    
    void operator +=(class Alumno &,class Nota &);
    
private:
    int codigo;
    char* nombre;
    int numCursos;
    int numAprobados;
    int numPrimera;
    int numSegunda;
    int numTercera;
    Nota lnotas[100];
    //recuerda que los arreglos nunca se set y get.A cada indice se le aplica
};

void operator >>(ifstream &, class Alumno &);



#endif /* ALUMNO_H */

