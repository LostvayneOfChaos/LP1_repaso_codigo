/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   alumnonota.cpp
 * Author: gtorr
 * 
 * Created on October 19, 2023, 12:56 PM
 */

#include "alumnonota.h"

alumnonota::alumnonota() {
    codcurso=nullptr;
}



alumnonota::~alumnonota() {
    if(codcurso!=nullptr)delete codcurso;
}

void alumnonota::SetNota(int nota) {
    this->nota = nota;
}

int alumnonota::GetNota() const {
    return nota;
}

void alumnonota::SetCiclo(int ciclo) {
    this->ciclo = ciclo;
}

int alumnonota::GetCiclo() const {
    return ciclo;
}

void alumnonota::SetCodcurso(char* cadena) {
    if(codcurso!=nullptr)delete codcurso;
    codcurso=new char [strlen(cadena)+1];
    strcpy(codcurso,cadena);
}

void alumnonota::GetCodcurso(char *cadena) const {
    strcpy(cadena,codcurso);
}

void alumnonota::SetCodigo(int codigo) {
    this->codigo = codigo;
}

int alumnonota::GetCodigo() const {
    return codigo;
}
void operator >>(ifstream &arch,class alumnonota &alu){
    int codigo;
    char nombre[500];
    arch>>codigo;
    if(arch.eof())return;
    arch.get();
    arch.getline(nombre,500,',');
    int ciclo,nota;
    arch>>ciclo;
    arch.get();
    arch>>nota;
    alu.SetCiclo(ciclo);
    alu.SetCodigo(codigo);
    alu.SetCodcurso(nombre);
    alu.SetNota(nota);
    
}
void alumnonota::operator &(class nota &NOTA){
    char nombre[400];
    NOTA.SetCiclo(GetCiclo());
    GetCodcurso(nombre);
    NOTA.SetCodcurso(nombre);
    NOTA.SetCantnota(GetNota());
}
void operator <<(ofstream &arch,const class alumnonota &alu){
    
}

