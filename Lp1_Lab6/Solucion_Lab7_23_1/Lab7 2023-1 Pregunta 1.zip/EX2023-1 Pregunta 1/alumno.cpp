/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   alumno.cpp
 * Author: gtorr
 * 
 * Created on October 19, 2023, 12:57 PM
 */

#include "alumno.h"

alumno::alumno() {
    nombre=nullptr;
}


alumno::~alumno() {
    if(nombre!=nullptr)delete nombre;
}

void alumno::SetNumtercera(int numtercera) {
    this->numtercera = numtercera;
}

int alumno::GetNumtercera() const {
    return numtercera;
}

void alumno::SetNumsegunda(int numsegunda) {
    this->numsegunda = numsegunda;
}

int alumno::GetNumsegunda() const {
    return numsegunda;
}

void alumno::SetNumprimero(int numprimero) {
    this->numprimero = numprimero;
}

int alumno::GetNumprimero() const {
    return numprimero;
}

void alumno::SetNumaprobados(int numaprobados) {
    this->numaprobados = numaprobados;
}

int alumno::GetNumaprobados() const {
    return numaprobados;
}

void alumno::SetNumcursos(int numcursos) {
    this->numcursos = numcursos;
}

int alumno::GetNumcursos() const {
    return numcursos;
}

void alumno::SetNombre(char* cadena) {
    if(nombre!=nullptr)delete nombre;
    nombre=new char [strlen(cadena)+1];
    strcpy(nombre,cadena);
}

void alumno::GetNombre(char* cadena) const {
    strcpy(cadena,nombre);
}

void alumno::SetCodigo(int codigo) {
    this->codigo = codigo;
}

int alumno::GetCodigo() const {
    return codigo;
}
void operator >>(ifstream &arch,class alumno &alu){
    int codigo;
    char nombre[400],c;
    int porcentaje,escala;
    arch>>codigo;
    if(arch.eof())return;
    arch.get();
    arch.getline(nombre,400,',');
    arch>>c;
    if(c=='S'){
        arch>>c>>porcentaje>>c>>c>>escala;
        
    }
    else if(c=='V'){
        arch>>c>>c>>escala;
        porcentaje=0;
    }
    else{
        arch>>escala;
        porcentaje=100;
    }
    alu.SetCodigo(codigo);
    alu.SetNombre(nombre);
    alu.SetNumaprobados(0);
    alu.SetNumcursos(0);
    alu.SetNumsegunda(0);
    alu.SetNumprimero(0);
    alu.SetNumtercera(0);
    
}
void operator <<(ofstream &arch,const class alumno &alu){
    arch<<"Codigo del Alumno: "<<alu.GetCodigo()<<endl;
    char nombre[400];
    alu.GetNombre(nombre);
    arch<<"Nombre del Alumno: "<<nombre<<endl;
    arch<<"Detalle de Cursos:"<<endl;
    arch<<left<<setw(10)<<"Cursados"<<setw(10)<<"Aprobados"<<setw(10)<<"1ra Vez"<<
            setw(10)<<"2da Vez"<<"3ra Vez"<<endl;
    arch<<right<<setw(5)<<alu.GetNumcursos()<<setw(10)<<alu.GetNumaprobados()<<
            setw(10)<<alu.GetNumprimero()<<setw(10)<<alu.GetNumsegunda()<<setw(10)<<
            alu.GetNumtercera()<<endl;
}
void alumno::operator +=(class nota &notadealumno){
    int contadorcursos=0;
    char curso[100];
    int notaobtenida=notadealumno.GetCantnota();
    if(notaobtenida>=11){
        numaprobados++;
    }
    notadealumno.GetCodcurso(curso);
    for(int i=0;i<numcursos;i++){
        char cursocompara[100];
        lnotas[i].GetCodcurso(cursocompara);
        if(strcmp(cursocompara,curso)==0){
            contadorcursos++;
        }
    }
    if(contadorcursos==0){
        numprimero++;
    }
    else if(contadorcursos==1){
        numsegunda++;
    }
    else{
        numtercera++;
    }
    lnotas[numcursos].SetCantnota(notadealumno.GetCantnota());
    lnotas[numcursos].SetCodcurso(curso);
    lnotas[numcursos].SetCantnota(notaobtenida);
    numcursos++;
}
