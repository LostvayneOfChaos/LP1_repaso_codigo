/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: gtorr
 *
 * Created on October 19, 2023, 12:55 PM
 */

#include <cstdlib>
using namespace std;
#include "alumno.h"
#include "alumnonota.h"
#include "nota.h"
/*
 * 
 */
int main(int argc, char** argv) {
    ifstream archNotas("Notas.csv",ios::in);
    if(not archNotas.is_open()){
        cout<<"No puede abrirse el archivo Notas.csv"<<endl;
        exit(1);
    }
    ifstream archAlumnos("Alumnos.csv",ios::in);
    if(not archAlumnos.is_open()){
        cout<<"No puede abrirse el archivo Alumnos.csv"<<endl;
        exit(1);
    }
    ofstream archReporte("Reporte.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"No puede abrirse el archivo Reporte.txt"<<endl;
        exit(1);
    }    
    class alumno alumnos[10];
    class alumnonota alunota;
    class nota notaalu;
    archNotas>>alunota;
    for(int i=0;i<10;i++){
        archAlumnos>>alumnos[i];
    }
    alumnos[0].SetCodigo(alunota.GetCodigo());
    alunota&notaalu;
    
    cout<<notaalu.GetCantnota()<<endl;
    cout<<notaalu.GetCiclo()<<endl;
    char codcurso[100];
    notaalu.GetCodcurso(codcurso);
    cout<<codcurso<<endl;
    alumnos[0]+=notaalu;
    notaalu.SetCantnota(9);
    alumnos[0]+=notaalu;
    alumnos[0]+=notaalu;
    cout<<"Lomo"<<endl;
    for(int i=0;i<10;i++){
        archReporte<<alumnos[i];
    }
    return 0;
}

