/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   alumno.h
 * Author: gtorr
 *
 * Created on October 19, 2023, 12:57 PM
 */
#include <cstdlib>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "nota.h"
#ifndef ALUMNO_H
#define ALUMNO_H

class alumno {
public:
    alumno();
    virtual ~alumno();
    void SetNumtercera(int numtercera);
    int GetNumtercera() const;
    void SetNumsegunda(int numsegunda);
    int GetNumsegunda() const;
    void SetNumprimero(int numprimero);
    int GetNumprimero() const;
    void SetNumaprobados(int numaprobados);
    int GetNumaprobados() const;
    void SetNumcursos(int numcursos);
    int GetNumcursos() const;
    void SetNombre(char* cadena);
    void GetNombre(char *cadena) const;
    void SetCodigo(int codigo);
    int GetCodigo() const;
    void operator +=(class nota &);
private:
    int codigo;
    char *nombre;
    int numcursos;
    int numaprobados;
    int numprimero;
    int numsegunda;
    int numtercera;
    class nota lnotas[50];

};
void operator >>(ifstream &arch,class alumno &alu);
void operator <<(ofstream &arch,const class alumno &alu);
#endif /* ALUMNO_H */

