/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   nota.cpp
 * Author: gtorr
 * 
 * Created on October 19, 2023, 12:57 PM
 */

#include "nota.h"

nota::nota() {
    codcurso=nullptr;
}


nota::~nota() {
    if(codcurso!=nullptr)delete codcurso;
}


void nota::SetCiclo(int ciclo) {
    this->ciclo = ciclo;
}

int nota::GetCiclo() const {
    return ciclo;
}

void nota::SetCodcurso(char* cadena) {
    if(codcurso!=nullptr)delete codcurso;
    codcurso=new char [strlen(cadena)+1];
    strcpy(codcurso,cadena);
}

void nota::GetCodcurso(char *cadena) const {
    strcpy(cadena,codcurso);
}

void nota::SetCantnota(int cantnota) {
    this->cantnota = cantnota;
}

int nota::GetCantnota() const {
    return cantnota;
}

