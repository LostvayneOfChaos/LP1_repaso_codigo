/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Funciones.h
 * Author: gtorr
 *
 * Created on October 19, 2023, 2:03 PM
 */
#include <cstdlib>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "alumno.h"
#include "alumnonota.h"
#ifndef FUNCIONES_H
#define FUNCIONES_H

void cargaalumnos(class alumno *lalumnos);
void carganotas(class alumnonota *lnotas);
void actualizanotas(class alumno *lalumnos,class alumnonota *lnotas);
int buscarAlumno(class alumno *lalumnos,int codigo);
void imprimealumnos(class alumno *lalumnos);

#endif /* FUNCIONES_H */

