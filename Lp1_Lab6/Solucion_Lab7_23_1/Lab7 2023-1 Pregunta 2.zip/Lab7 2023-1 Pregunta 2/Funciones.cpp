/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Funciones.cpp
 * Author: gtorr
 *
 * Created on October 19, 2023, 2:03 PM
 */
#include <cstdlib>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "alumno.h"
#include "alumnonota.h"
#include "Funciones.h"
void cargaalumnos(class alumno *lalumnos){
    ifstream archAlumnos("Alumnos.csv",ios::in);
    if(not archAlumnos.is_open()){
        cout<<"No puede abrirse el archivo Alumnos.csv"<<endl;
        exit(1);
    }
    int numAlumnos=0;
    while(true){
        archAlumnos>>lalumnos[numAlumnos];
        if(archAlumnos.eof())break;
        numAlumnos++;
    }
    lalumnos[numAlumnos].SetCodigo(0);
}
void carganotas(class alumnonota *lnotas){
    ifstream archNotas("Notas.csv",ios::in);
    if(not archNotas.is_open()){
        cout<<"No puede abrirse el archivo Notas.csv"<<endl;
        exit(1);
    }
    int numNotas=0;
    while(true){
        archNotas>>lnotas[numNotas];
        if(archNotas.eof())break;
        numNotas++;
    }
    lnotas[numNotas].SetCodcurso("XXXXXXXX");
    
}
void actualizanotas(class alumno *lalumnos,class alumnonota *lnotas){
    int numNotas=0;
    int posAlumno;
    while(true){
        char codigo[100];
        lnotas[numNotas].GetCodcurso(codigo);
        if(strcmp(codigo,"XXXXXXXX")==0)break;
        posAlumno=buscarAlumno(lalumnos,lnotas[numNotas].GetCodigo());
        if(posAlumno!=-1){
            class nota notaalumno;
            lnotas[numNotas]&notaalumno;
            lalumnos[posAlumno]+=notaalumno;
        }
        numNotas++;
    }
}
int buscarAlumno(class alumno *lalumnos,int codigo){
    for(int i=0;lalumnos[i].GetCodigo()!=0;i++){
        if(lalumnos[i].GetCodigo()==codigo){
            return i;
        }
    }
    return -1;
}
void imprimealumnos(class alumno *lalumnos){
    ofstream archReporte("Reporte.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"No puede abrirse el archivo Reporte.txt"<<endl;
        exit(1);
    }  
    for(int i=0;lalumnos[i].GetCodigo()!=0;i++){
        archReporte<<lalumnos[i];
    }
}