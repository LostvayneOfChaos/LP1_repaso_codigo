/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Gustavo Torres Flores
 * Codigo: 20180885
 * Created on October 19, 2023, 2:00 PM
 */

#include <cstdlib>
using namespace std;
#include "Funciones.h"
#include "alumno.h"
#include "alumnonota.h"
/*
 * 
 */
int main(int argc, char** argv) {
    
    alumno lalumnos[100];
    alumnonota lnotas[200];
    
    cargaalumnos(lalumnos);
    carganotas(lnotas);
    actualizanotas(lalumnos,lnotas);
    imprimealumnos(lalumnos);

    return 0;
}

