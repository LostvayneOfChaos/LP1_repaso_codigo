/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   nota.h
 * Author: gtorr
 *
 * Created on October 19, 2023, 12:57 PM
 */
#include <cstdlib>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#ifndef NOTA_H
#define NOTA_H

class nota {
public:
    nota();
    virtual ~nota();
    void SetCiclo(int ciclo);
    int GetCiclo() const;
    void SetCodcurso(char* cadena);
    void GetCodcurso(char *cadena) const;
    void SetCantnota(int cantnota);
    int GetCantnota() const;
private:
    char *codcurso;
    int ciclo;
    int cantnota;

};

#endif /* NOTA_H */

