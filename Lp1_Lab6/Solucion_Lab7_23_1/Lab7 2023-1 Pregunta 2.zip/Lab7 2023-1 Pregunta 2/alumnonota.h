/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   alumnonota.h
 * Author: gtorr
 *
 * Created on October 19, 2023, 12:56 PM
 */
#include <cstdlib>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "nota.h"
#ifndef ALUMNONOTA_H
#define ALUMNONOTA_H

class alumnonota {
public:
    alumnonota();
    virtual ~alumnonota();
    void SetNota(int nota);
    int GetNota() const;
    void SetCiclo(int ciclo);
    int GetCiclo() const;
    void SetCodcurso(char* cadena);
    void GetCodcurso(char *cadena) const;
    void SetCodigo(int codigo);
    int GetCodigo() const;
    void operator &(class nota &);
private:
    int codigo;
    char *codcurso;
    int ciclo;
    int nota;

};
void operator >>(ifstream &arch,class alumnonota &alu);
void operator <<(ofstream &arch,const class alumnonota &alu);
#endif /* ALUMNONOTA_H */

