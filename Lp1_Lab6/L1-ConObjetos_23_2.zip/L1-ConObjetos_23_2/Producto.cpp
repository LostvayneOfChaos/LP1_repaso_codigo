/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Producto.cpp
 * Author: Alexis
 * 
 * Created on 23 de octubre de 2023, 11:22 AM
 */

#include "Producto.h"
#include "Pedido.h"

Producto::Producto() {
    codigo = nullptr;
    descripcion = nullptr;
    precio = 0;
}

//Producto::Producto(const Producto& orig) {
//}

Producto::~Producto() {
    if(codigo!=nullptr) delete codigo;
    if(descripcion!=nullptr) delete descripcion;
}

void Producto::SetStock(int stock) {
    this->stock = stock;
}

int Producto::GetStock() const {
    return stock;
}

void Producto::SetPrecio(double precio) {
    this->precio = precio;
}

double Producto::GetPrecio() const {
    return precio;
}
    
    
      
void Producto::SetDescripcion(char* cadena) {
    if(descripcion != nullptr) delete descripcion;
    descripcion = new char[strlen(cadena)+1];
    strcpy(descripcion,cadena);
}

void Producto::GetDescripcion(char* cadena) const {
    if(descripcion == nullptr) cadena[0]=0;
    strcpy(cadena,descripcion);
}

void Producto::SetCodigo(char* cadena) {
    if(codigo != nullptr) delete codigo;
    codigo = new char[strlen(cadena)+1];
    strcpy(codigo,cadena);
}

void Producto::GetCodigo(char*cadena) const {
    if(codigo == nullptr) cadena[0]=0;
    strcpy(cadena,codigo);
}
void Producto::imprimirInfoClientes(ofstream&arch){
    // Clientes atendidos
    arch<<left<<setw(25)<<"Clientes atendidos:";
    if(cantidadClientesServidos>0){
        for(int i=0; i<cantidadClientesServidos; i++){
            arch<<setw(10)<<clientesServidos[i];
        }
    }else
        arch<<"NO SE ATENDIERON PEDIDOS";
    arch<<endl;
    // Clientes no atendidos
    arch<<left<<setw(25)<<"Clientes no atendidos:";
    if(cantidadClientesNoServidos>0){
        for(int i=0; i<cantidadClientesNoServidos; i++){
            arch<<setw(10)<<clientesNoServidos[i];
        }
    }else
        arch<<"NO HAY CLIENTES SIN ATENDER";
    arch<<endl<<endl;
}
bool Producto::operator+(class Pedido &ped){
    ped.SetPrecioProducto(precio);
    if(stock>0){
        clientesServidos[cantidadClientesServidos] = ped.GetDnicliente();
        cantidadClientesServidos++;
        stock--;
        return true;
    }else{
        clientesNoServidos[cantidadClientesNoServidos] = ped.GetDnicliente();
        cantidadClientesNoServidos++;
        return false;
    }
    
}


bool operator>>(ifstream &arch, class Producto &pro){
    char codigo[10], descripcion[100];
    double precio; int stock;
    arch.getline(codigo,10,',');
    if(arch.eof()) return false;
    arch.getline(descripcion,100,',');
    arch>>precio; arch.get(); arch>>stock; arch.get();

    pro.SetCodigo(codigo);
    pro.SetDescripcion(descripcion);
    pro.SetPrecio(precio);
    pro.SetStock(stock);
    
    return true;
}
void operator<<(ofstream &arch, class Producto &pro){
    char codigo[10], descrip[100];
    pro.GetCodigo(codigo); pro.GetDescripcion(descrip);
    
    arch<<left<<setw(10)<<codigo<<setw(60)<<descrip<<right<<setw(10)<<pro.GetPrecio()<<
            setw(8)<<pro.GetStock()<<endl;
    pro.imprimirInfoClientes(arch);
}