/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Pedido.h
 * Author: Alexis
 *
 * Created on 23 de octubre de 2023, 11:33 AM
 */

#ifndef PEDIDO_H
#define PEDIDO_H
#include <iostream>
#include <cstring>
#include <iomanip>
#include <fstream>
using namespace std;

    
class Pedido {
private:
    char *codigo;
    int dnicliente;
    double precioProducto;
public:
    Pedido();
//    Pedido(const Pedido& orig);
    virtual ~Pedido();
    void SetDnicliente(int dnicliente);
    int GetDnicliente() const;
    void SetCodigo(char* cadena);
    void GetCodigo(char* cadena) const;
    void SetPrecioProducto(double precioProducto);
    double GetPrecioProducto() const;
    
    
};

bool operator>>(ifstream &arch, class Pedido &ped);

#endif /* PEDIDO_H */

