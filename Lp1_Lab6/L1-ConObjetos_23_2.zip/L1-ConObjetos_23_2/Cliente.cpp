/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Cliente.cpp
 * Author: Alexis
 * 
 * Created on 23 de octubre de 2023, 11:20 AM
 */

#include "Cliente.h"
#include "Pedido.h"

Cliente::Cliente() {
    dni = 0;
    nombre = nullptr;
    montoTotal = 0;
    cantidadProductosEntregados = 0;
}

//Cliente::Cliente(const Cliente& orig) {
//}

Cliente::~Cliente() {
    if(nombre!=nullptr) delete nombre;
}

void Cliente::SetTelefono(int telefono) {
    this->telefono = telefono;
}

int Cliente::GetTelefono() const {
    return telefono;
}

void Cliente::SetNombre(char* cadena) {
    if(nombre != nullptr) delete nombre;
    nombre = new char[strlen(cadena)+1];
    strcpy(nombre,cadena);
}

void Cliente::GetNombre(char* cadena) const {
    if(nombre == nullptr) cadena[0]=0;
    strcpy(cadena,nombre);
}

void Cliente::SetDni(int dni) {
    this->dni = dni;
}

int Cliente::GetDni() const {
    return dni;
}

void Cliente::SetMontoTotal(double montoTotal) {
    this->montoTotal = montoTotal;
}

double Cliente::GetMontoTotal() const {
    return montoTotal;
}

void Cliente::SetCantidadProductosEntregados(int cantidadProductosEntregados) {
    this->cantidadProductosEntregados = cantidadProductosEntregados;
}

int Cliente::GetCantidadProductosEntregados() const {
    return cantidadProductosEntregados;
}

void Cliente::operator+(class Pedido &ped){
    char codigo[10]; ped.GetCodigo(codigo); 
//    ProductoEntregado proent;
//    proent.SetCodigo(codigo);
//    proent.SetPrecio(ped.GetPrecioProducto());
//    productosEntregados[cantidadProductosEntregados] = proent;
    productosEntregados[cantidadProductosEntregados].SetCodigo(codigo);
    productosEntregados[cantidadProductosEntregados].SetPrecio(ped.GetPrecioProducto());
    cantidadProductosEntregados++;
    // Actualizando el monto total 
    montoTotal += ped.GetPrecioProducto();
}
void Cliente::imprimirProductosEntregados(ofstream&arch){
    char codigoprod[10];
    arch<<"  Productos entregados: ";
    if(cantidadProductosEntregados>0){
        for(int i=0; i<cantidadProductosEntregados; i++){
            productosEntregados[i].GetCodigo(codigoprod);
            arch<<left<<setw(10)<<codigoprod;
        }        
    }else
        arch<<"NO SE LE ENTREGARON PRODUCTOS";
    
    arch<<endl;
}

bool operator>>(ifstream &arch, class Cliente &cli){
    int dni, telefono;
    char nombre[150];
    arch>>dni;
    if(arch.eof()) return false;
    arch.get();
    arch.getline(nombre,150,',');
    arch>>telefono;
    
    cli.SetDni(dni);
    cli.SetNombre(nombre);
    cli.SetTelefono(telefono);
    return true;
}

void operator<<(ofstream &arch, class Cliente &cli){
    char nombre[100]; cli.GetNombre(nombre);
    arch<<left<<setw(10)<<cli.GetDni()<<setw(50)<<nombre<<right<<
            setw(10)<<cli.GetTelefono()<<setw(10)<<cli.GetMontoTotal();
    cli.imprimirProductosEntregados(arch);
}

