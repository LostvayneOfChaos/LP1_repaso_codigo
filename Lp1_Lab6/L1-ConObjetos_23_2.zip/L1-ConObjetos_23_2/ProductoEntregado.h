/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ProductoEntregado.h
 * Author: Alexis
 *
 * Created on 23 de octubre de 2023, 11:45 AM
 */

#ifndef PRODUCTOENTREGADO_H
#define PRODUCTOENTREGADO_H
#include <iostream>
#include <cstring>
#include <iomanip>
#include <fstream>
using namespace std;

class ProductoEntregado {
private:
    char *codigo;
    double precio;
public:
    ProductoEntregado();
    ProductoEntregado(const ProductoEntregado& orig);
    virtual ~ProductoEntregado();
    void SetPrecio(double precio);
    double GetPrecio() const;
    void SetCodigo(char* );
    void GetCodigo(char*) const;


};

#endif /* PRODUCTOENTREGADO_H */

