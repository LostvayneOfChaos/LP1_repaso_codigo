/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Producto.h
 * Author: Alexis
 *
 * Created on 23 de octubre de 2023, 11:22 AM
 */

#ifndef PRODUCTO_H
#define PRODUCTO_H
#include <iostream>
#include <cstring>
#include <iomanip>
#include <fstream>
using namespace std;

class Producto {
private:
    char *codigo;
    char *descripcion;
    double precio;
    int stock;
    
    int clientesServidos[20];
    int clientesNoServidos[20];
    int cantidadClientesServidos;
    int cantidadClientesNoServidos; 
    
public:
    Producto();
//    Producto(const Producto& orig);
    virtual ~Producto();
    void SetStock(int stock);
    int GetStock() const;
    void SetPrecio(double precio);
    double GetPrecio() const;
    void SetDescripcion(char* descripcion);
    void GetDescripcion(char*) const;
    void SetCodigo(char* codigo);
    void GetCodigo(char*) const;
    
    void imprimirInfoClientes(ofstream&arch);
    bool operator+(class Pedido &ped);
};

bool operator>>(ifstream &arch, class Producto &pro);
void operator<<(ofstream &arch, class Producto &pro);

#endif /* PRODUCTO_H */

