/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   FunAux.cpp
 * Author: Alexis
 * 
 * Created on 23 de octubre de 2023, 03:27 PM
 */

#include "FunAux.h"
#include "Pedido.h"

// Parte a)
void cargarClientes(class Cliente *clientes){
    ifstream arch("Clientes.csv",ios::in);
    if(!arch){
        cout<<"ERROR: No se pudo abrir el archivo Clientes.csv"<<endl;
        exit(1);
    }
    int numCli=0;
    
    while(true){
        if(!(arch>>clientes[numCli])) break;
        numCli++;
    }    
}
// Parte b)
void cargarProductos(class Producto *productos){
    ifstream arch("Productos.csv",ios::in);
    if(!arch){
        cout<<"ERROR: No se pudo abrir el archivo Productos.csv"<<endl;
        exit(1);
    }
    int numDat=0;
    
    while(true){
        if(!(arch>>productos[numDat])) break;
        numDat++;
    }
}

// Parte c)
void procesarPedidos(class Cliente *clientes,class Producto *productos){
    ifstream arch("Pedidos.csv",ios::in);
    if(!arch){
        cout<<"ERROR: No se pudo abrir el archivo Pedidos.csv"<<endl;
        exit(1);
    }
    
    Pedido ped;
    char codigo[10];
    int poscliente, posproducto; 
    
    while(true){
        if(!(arch>>ped)) break;
        ped.GetCodigo(codigo); 
        posproducto = buscarProducto(productos,codigo);
        
        if(posproducto!=-1)            
            if(productos[posproducto]+ped){                
                poscliente = buscarCliente(clientes,ped.GetDnicliente());
                if(poscliente!=-1)                    
                    clientes[poscliente] + ped; 
            }           
    }
}

int buscarCliente(class Cliente* clientes, int dnibuscar){
    for(int i=0; clientes[i].GetDni(); i++)
        if(clientes[i].GetDni()==dnibuscar) return i;
        
    return -1;
}
int buscarProducto(class Producto*productos,char*codigobuscar){
    char codigo[10];
    for(int i=0; productos[i].GetPrecio()>0.001; i++){
        productos[i].GetCodigo(codigo);
        if(strcmp(codigo,codigobuscar)==0) return i;        
    }
    return -1;
}

// Parte d)
void pruebaProductos(class Producto*productos, const char*archnomb){
    ofstream arch(archnomb,ios::out);
    if(!arch){
        cout<<"ERROR: No se pudo abrir el archivo "<<archnomb<<endl;
        exit(1);
    }
    
    for(int i=0; productos[i].GetPrecio()>0.001; i++)
        arch<<productos[i];
    
}
void pruebaClientes(class Cliente*clientes, const char*archnomb){
    ofstream arch(archnomb,ios::out);
    if(!arch){
        cout<<"ERROR: No se pudo abrir el archivo "<<archnomb<<endl;
        exit(1);
    }
    
    arch<<left<<setw(10)<<"DNI"<<setw(50)<<"Nombre"<<right<<
            setw(10)<<"Telefono"<<setw(15)<<"Monto Total"<<endl;
    for(int i=0; clientes[i].GetDni(); i++)
        arch<<clientes[i];    
}