/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Alexis
 *
 * Created on 23 de octubre de 2023, 11:20 AM
 */

#include "FunAux.h"

int main(int argc, char** argv) {
    Cliente clientes[200];
    Producto productos[200];
    
    cargarClientes(clientes);
    cargarProductos(productos);
    pruebaClientes(clientes,"PruebaClientesInicial.txt");
    pruebaProductos(productos,"PruebaProductosInicial.txt");
    
    procesarPedidos(clientes,productos);
    
    pruebaClientes(clientes,"PruebaClientesFinal.txt");
    pruebaProductos(productos,"PruebaProductosFinal.txt");
    
    return 0;
}

