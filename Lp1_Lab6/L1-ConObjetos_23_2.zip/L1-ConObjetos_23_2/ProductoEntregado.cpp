/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ProductoEntregado.cpp
 * Author: Alexis
 * 
 * Created on 23 de octubre de 2023, 11:45 AM
 */

#include "ProductoEntregado.h"

ProductoEntregado::ProductoEntregado() {
    codigo = nullptr;
}

ProductoEntregado::ProductoEntregado(const ProductoEntregado& orig) {
    codigo = nullptr;
    char codigoOrig[10]; orig.GetCodigo(codigoOrig);
    
    (*this).SetCodigo(codigoOrig);
    (*this).SetPrecio(orig.GetPrecio());
}

ProductoEntregado::~ProductoEntregado() {
    if(codigo!=nullptr) delete codigo;
}

void ProductoEntregado::SetPrecio(double precio) {
    this->precio = precio;
}

double ProductoEntregado::GetPrecio() const {
    return precio;
}

void ProductoEntregado::SetCodigo(char* cadena) {
    if(codigo != nullptr) delete codigo;
    codigo = new char[strlen(cadena)+1];
    strcpy(codigo,cadena);
}

void ProductoEntregado::GetCodigo(char* cadena) const {
    if(codigo == nullptr) cadena[0]=0;
    strcpy(cadena,codigo);
}

