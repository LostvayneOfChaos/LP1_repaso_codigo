/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Pedido.cpp
 * Author: Alexis
 * 
 * Created on 23 de octubre de 2023, 11:33 AM
 */

#include "Pedido.h"

Pedido::Pedido() {
    codigo = nullptr;
}

//Pedido::Pedido(const Pedido& orig) {
//}

Pedido::~Pedido() {
    if(codigo!=nullptr) delete codigo;
}

void Pedido::SetDnicliente(int dnicliente) {
    this->dnicliente = dnicliente;
}

int Pedido::GetDnicliente() const {
    return dnicliente;
}

void Pedido::SetCodigo(char* cadena) {
    if(codigo != nullptr) delete codigo;
    codigo = new char[strlen(cadena)+1];
    strcpy(codigo,cadena);
}

void Pedido::GetCodigo(char* cadena) const {
    if(codigo == nullptr) cadena[0]=0;
    strcpy(cadena,codigo);
}

void Pedido::SetPrecioProducto(double precioProducto) {
    this->precioProducto = precioProducto;
}

double Pedido::GetPrecioProducto() const {
    return precioProducto;
}



bool operator>>(ifstream &arch, class Pedido &ped){
    char codigo[10]; int dnicli;
    arch.getline(codigo,10,',');
    if(arch.eof()) return false; 
    arch>>dnicli; arch.get();
    
    ped.SetCodigo(codigo);
    ped.SetDnicliente(dnicli);
    return true;
}