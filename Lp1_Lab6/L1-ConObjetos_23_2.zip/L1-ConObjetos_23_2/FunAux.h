/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   FunAux.h
 * Author: Alexis
 *
 * Created on 23 de octubre de 2023, 03:27 PM
 */

#ifndef FUNAUX_H
#define FUNAUX_H
#include <iostream>
#include <cstring>
#include <iomanip>
#include <fstream>
using namespace std;
#include "Cliente.h"
#include "Producto.h"

void cargarClientes(class Cliente *clientes);
void cargarProductos(class Producto *productos);
void procesarPedidos(class Cliente *clientes,class Producto *productos);
int buscarCliente(class Cliente* clientes, int dnibuscar);
int buscarProducto(class Producto*productos,char*codigobuscar);
void pruebaClientes(class Cliente*clientes, const char*archnomb);
void pruebaProductos(class Producto*productos, const char*archnomb);

#endif /* FUNAUX_H */
