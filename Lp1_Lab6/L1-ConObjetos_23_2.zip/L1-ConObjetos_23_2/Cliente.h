/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Cliente.h
 * Author: Alexis
 *
 * Created on 23 de octubre de 2023, 11:20 AM
 */

#ifndef CLIENTE_H
#define CLIENTE_H
#include <iostream>
#include <cstring>
#include <iomanip>
#include <fstream>
using namespace std;
#include "ProductoEntregado.h"

class Cliente {
private:
    int dni;
    char *nombre;
    int telefono;
    class ProductoEntregado productosEntregados[20];
    int cantidadProductosEntregados;
    double montoTotal;
public:
    Cliente();
//    Cliente(const Cliente& orig);
    virtual ~Cliente();
    void SetTelefono(int telefono);
    int GetTelefono() const;
    void SetNombre(char* cad);
    void GetNombre(char* cad) const;
    void SetDni(int dni);
    int GetDni() const;
    void SetMontoTotal(double montoTotal);
    double GetMontoTotal() const;
    void SetCantidadProductosEntregados(int cantidadProductosEntregados);
    int GetCantidadProductosEntregados() const;
    
    void operator+(class Pedido &ped);
    void imprimirProductosEntregados(ofstream&arch);
};

bool operator>>(ifstream &arch, class Cliente &cli);
void operator<<(ofstream &arch, class Cliente &cli);

#endif /* CLIENTE_H */

