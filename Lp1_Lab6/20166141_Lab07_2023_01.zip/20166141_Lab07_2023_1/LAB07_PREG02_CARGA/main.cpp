/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: alulab14
 *
 * Created on 24 de octubre de 2023, 05:40 PM
 */

#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>
#include "Funciones.h"
#include "Alumno.h"
#include "AlumnoNota.h"

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    
    Alumno lalumnos[100];
    AlumnoNota lnotas[200];
    
    cargaralumnos(lalumnos);
    carganotas(lnotas);
    char buffer[100];
    
    for (int i = 0; (lalumnos[i].GetCodigo())!=0 ; i++) {
        
        lalumnos[i].GetNombre(buffer);
        cout<<buffer<<endl;
     }
    //actualizanotas(lalumnos,lnotas);
    //imprimealumnos(lalumnos);
    
    
    
    return 0;
}

