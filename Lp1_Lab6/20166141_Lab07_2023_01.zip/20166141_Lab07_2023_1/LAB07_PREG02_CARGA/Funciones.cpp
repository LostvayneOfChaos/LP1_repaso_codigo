/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>
#include "Funciones.h"
#include "Alumno.h"
#include "AlumnoNota.h"

using namespace std;

char* leerCadena(ifstream &arch,char parametro){
    
    char*nombre;
    char buffer[100];
    arch.getline(buffer,100,parametro);
    nombre=new char[strlen(buffer)+1];
    strcpy(nombre,buffer);
    return nombre;
    
}

void cargaralumnos(class Alumno *lalumnos){
    
    int n=0;
    class Alumno alumno;
    ifstream archAlumno("Alumnos.csv",ios::in);
    if (!archAlumno) {
        cout<<"error al abrir el archivo";
        exit(1);
    }
    while (1) {
        archAlumno>>alumno;
        if(archAlumno.eof()) break;
        lalumnos[n]=alumno;
        char buffer[100];
        lalumnos[n].GetNombre(buffer);
        cout<<buffer<<endl;
        cout<<lalumnos[n].GetCodigo()<<endl;
        cout<<lalumnos[n].GetNumCursos()<<endl;
        n++;
    }
    class Alumno alumnoFinal;
    alumnoFinal.SetCodigo(0);
    lalumnos[n]=alumnoFinal;
    n++;
    archAlumno.close();
    
    
}


void carganotas(class AlumnoNota*lnotas){
    
    int n=0;
    class AlumnoNota alumno;
    ifstream archNotas("Notas.csv",ios::in);
    if (!archNotas) {
        cout<<"error al abrir el archivo";
        exit(1);
    }
    while (1) {
        archNotas>>alumno;
        if(archNotas.eof()) break;
        lnotas[n]=alumno;
        n++;
    }
    class AlumnoNota alumnoFinal;
    alumnoFinal.SetCodigo(0);
    lnotas[n]=alumnoFinal;
    n++;
    archNotas.close();
    
    
}

int buscar(int codigoAl,class Alumno *lalumnos){
    
    int valor;
    for (int i = 0; (lalumnos[i].GetCodigo())!=0 ; i++) {
        valor=lalumnos[i].GetCodigo();
        if(codigoAl==valor) return i;
        
    }
    return -1;
}




void actualizanotas(class Alumno *lalumnos,class AlumnoNota*lnotas){
    int codigoAl,pos,numCodCurso;
    char codCurso[100];
    class Nota nota;
    int numAp;
    for (int i = 0; (lnotas[i].GetCodigo())!=0 ; i++) {
        
        
        codigoAl=lnotas[i].GetCodigo();
        pos=buscar(codigoAl,lalumnos);
        if(pos!=-1){//encotraste alumno
            (nota=lnotas[i]);
            int valor=nota.GetNota();
            if(valor>10){
                numAp=(lalumnos[pos].GetNumAprobados());
                lalumnos[pos].SetNumAprobados(numAp+1);
            }
            /*nota.GetCodCurso(codCurso);
            numCodCurso=buscarCod(codCurso,lalumnos[pos]);
            if(numCodCurso==0){
                numAp=(lalumnos[pos].GetNumPrimera());
                lalumnos[pos].SetNumPrimera(numAp+1);
            }
            if(numCodCurso==1){
                numAp=(lalumnos[pos].GetNumSegunda());
                lalumnos[pos].SetNumSegunda(numAp+1);
            }
            else if(numCodCurso==2){
                numAp=(lalumnos[pos].GetNumTercera());
                lalumnos[pos].SetNumTercera(numAp+1);
            }*/
            
            lalumnos[pos]+=nota;
        }
        
    }

    
}

void imprimealumnos(class Alumno *lalumnos){
    ofstream outNotas("ReporteAlumnos.txt",ios::out);
    if (!outNotas) {
        cout<<"error al abrir el archivo";
        exit(1);
    }
    
    for (int i = 0; (lalumnos[i].GetCodigo())!=0 ; i++) {
        
        class Alumno al;
        al=lalumnos[i];
        outNotas<<lalumnos[i];
        /*char buffer[100];
        lalumnos[i].GetNombre(buffer);
        cout<<buffer<<endl;*/
     }
     
     
    outNotas.close();
}