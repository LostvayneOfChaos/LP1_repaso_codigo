/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Nota.cpp
 * Author: AXEL
 * 
 * Created on 24 de octubre de 2023, 11:20 AM
 */
#include "Nota.h"
Nota::Nota() {
    codCurso=nullptr;
}

Nota::Nota(const Nota& orig) {
}

Nota::~Nota() {
}

void Nota::SetNota(int nota) {
    this->nota = nota;
}

int Nota::GetNota() const {
    return nota;
}

void Nota::SetCiclo(int ciclo) {
    this->ciclo = ciclo;
}

int Nota::GetCiclo() const {
    return ciclo;
}

void Nota::SetCodCurso(char* name) {
    if(this->codCurso != nullptr) delete(this->codCurso);
    codCurso=new char[strlen(name)+1];
    strcpy(codCurso,name);
    
}

void Nota::GetCodCurso(char* name) const {
    if(codCurso==nullptr) name[0]=0;
    strcpy(name,codCurso);
}

void Nota::operator =(class AlumnoNota& alumnoNota){
    
    //carga a Nota
    this->SetCiclo(alumnoNota.GetCiclo());
    char buffer[100];
    alumnoNota.GetCodcurso(buffer);
    this->SetCodCurso(buffer);
    this->SetNota(alumnoNota.GetNota());
    
    
}
