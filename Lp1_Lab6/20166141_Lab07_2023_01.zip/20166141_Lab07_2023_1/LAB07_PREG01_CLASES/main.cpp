/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: AXEL
 *
 * Created on 24 de octubre de 2023, 11:17 AM
 */

#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>
#include "AlumnoNota.h"
#include "Nota.h"
#include "Alumno.h"
#include "Funciones.h"
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    class Alumno alumno;
    class AlumnoNota alumnoNota;
    class Nota nota;
    
    ifstream archAlumno("Alumnos.csv",ios::in);
    if (!archAlumno) {
        cout<<"error al abrir el archivo";
        exit(1);
    }
    ifstream archNotas("Notas.csv",ios::in);
    if (!archNotas) {
        cout<<"error al abrir el archivo";
        exit(1);
    }
    ofstream outAlumnos("Reporte.txt",ios::out);
    if (!outAlumnos) {
        cout<<"error al abrir el archivo";
        exit(1);
    }
    archAlumno>>alumno;
    archNotas>>alumnoNota;
    char codigoCurso[100];
    char notaCodCurso[100];
    alumnoNota.GetCodcurso(codigoCurso);
    cout<<alumnoNota.GetCodigo()<<endl;
    cout<<codigoCurso<<endl;
    cout<<alumnoNota.GetCiclo()<<endl;
    cout<<"respecto a Nota"<<endl;
    //&(alumnoNota,nota);
    (nota=alumnoNota);
    /*
    nota.SetCiclo(alumnoNota.GetCiclo());
    char buffer[100];
    alumnoNota.GetCodcurso(buffer);
    nota.SetCodCurso(buffer);
    nota.SetNota(alumnoNota.GetNota());
    */
    cout<<nota.GetCiclo()<<endl;
    nota.GetCodCurso(notaCodCurso);
    cout<<notaCodCurso<<endl;
    cout<<nota.GetNota()<<endl;
    alumno+=nota;
    
    outAlumnos<<alumno;
    
    archNotas.close();
    outAlumnos.close();
    archAlumno.close();
    return 0;
}

