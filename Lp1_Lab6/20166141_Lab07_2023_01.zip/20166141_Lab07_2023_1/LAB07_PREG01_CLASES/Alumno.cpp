/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Alumno.cpp
 * Author: AXEL
 * 
 * Created on 24 de octubre de 2023, 11:21 AM
 */
//#include "Funciones.h"
#include "Alumno.h"

Alumno::Alumno() {
    nombre=nullptr;
    
}

Alumno::Alumno(const Alumno& orig) {
}

Alumno::~Alumno() {
}

void Alumno::SetNumTercera(int numTercera) {
    this->numTercera = numTercera;
}

int Alumno::GetNumTercera() const {
    return numTercera;
}

void Alumno::SetNumSegunda(int numSegunda) {
    this->numSegunda = numSegunda;
}

int Alumno::GetNumSegunda() const {
    return numSegunda;
}

void Alumno::SetNumPrimera(int numPrimera) {
    this->numPrimera = numPrimera;
}

int Alumno::GetNumPrimera() const {
    return numPrimera;
}

void Alumno::SetNumAprobados(int numAprobados) {
    this->numAprobados = numAprobados;
}

int Alumno::GetNumAprobados() const {
    return numAprobados;
}

void Alumno::SetNumCursos(int numCursos) {
    this->numCursos = numCursos;
}

int Alumno::GetNumCursos() const {
    return numCursos;
}

void Alumno::SetNombre(char* name) {
    if(this->nombre != nullptr) delete(this->nombre);
    nombre=new char[strlen(name)+1];
    strcpy(nombre,name);
}

void Alumno::GetNombre(char* name) const {
    if(nombre==nullptr) name[0]=0;
    strcpy(name,nombre);
}

void Alumno::SetCodigo(int codigo) {
    this->codigo = codigo;
}

int Alumno::GetCodigo() const {
    return codigo;
}

void Alumno::operator +=(class Nota & nota){
    
    /*alumno.lnotas[0]*/
    this->lnotas[numCursos]=nota;
    numCursos++;
}

void operator >>(ifstream & arch,class Alumno & alumno){
    
    int codigo,porcentaje;
    char*nombre,*escala;
    char modalidad,aux;
    arch>>codigo;
    if(arch.eof()) return;
    arch>>aux;
    nombre=leerCadena(arch,',');
    arch>>modalidad>>aux;
    arch>>porcentaje>>aux;
    escala=leerCadena(arch,'\n');
    
    alumno.SetCodigo(codigo);
    alumno.SetNombre(nombre);
    alumno.SetNumAprobados(0);
    alumno.SetNumCursos(0);
    alumno.SetNumPrimera(0);
    alumno.SetNumSegunda(0);
    alumno.SetNumTercera(0);
    
}

void operator <<(ofstream &arch,class Alumno &alumno){
    char name[100];
    arch<<"Codigo del alumno "<< setw(20)<<alumno.GetCodigo()<<endl;
    alumno.GetNombre(name);
    arch<<"Nombre del alumno "<< setw(20)<<name<<endl;
    arch<<"Detalle de Cursos: "<<endl;
    arch<<"Cursados"<<setw(10)<<"Aprobados"<<setw(10)<<"1ra Vez"<<setw(10)<<
            "2da Vez"<<setw(10)<<"3ra Vez"<<setw(10)<<endl;
    arch<<setw(5)<<alumno.GetNumCursos()<<setw(10)<<alumno.GetNumAprobados()
            <<setw(10)<<alumno.GetNumPrimera()<<setw(10)<<
            alumno.GetNumSegunda()<<setw(10)<<alumno.GetNumTercera()
            <<setw(10)<<endl;
    
    
}