/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   AlumnoNota.cpp
 * Author: AXEL
 * 
 * Created on 24 de octubre de 2023, 11:19 AM
 */

#include "AlumnoNota.h"

AlumnoNota::AlumnoNota() {
    codcurso=nullptr;
}

AlumnoNota::AlumnoNota(const AlumnoNota& orig) {
}

AlumnoNota::~AlumnoNota() {
}

void AlumnoNota::SetNota(int nota) {
    this->nota = nota;
}

int AlumnoNota::GetNota() const {
    return nota;
}

void AlumnoNota::SetCiclo(int ciclo) {
    this->ciclo = ciclo;
}

int AlumnoNota::GetCiclo() const {
    return ciclo;
}

void AlumnoNota::SetCodcurso(char* name) {
    if(this->codcurso != nullptr) delete(this->codcurso);
    codcurso=new char[strlen(name)+1];
    strcpy(codcurso,name);
}

void AlumnoNota::GetCodcurso(char* name) const {
    if(codcurso==nullptr) name[0]=0;
    strcpy(name,codcurso);
}

void AlumnoNota::SetCodigo(int codigo) {
    this->codigo = codigo;
}

int AlumnoNota::GetCodigo() const {
    return codigo;
}

void operator >>(ifstream &arch, class AlumnoNota & alumno){
    
    int codigoAlumno,ciclo,nota;
    char*codigoCurso;
    char aux;
    arch>>codigoAlumno;
    if(arch.eof()) return;
    arch>>aux;
    codigoCurso=leerCadena(arch,',');
    arch>>ciclo>>aux>>nota;
    arch.get();
    
    alumno.SetCodigo(codigoAlumno);
    alumno.SetCodcurso(codigoCurso);
    alumno.SetCiclo(ciclo);
    alumno.SetNota(nota); 
}