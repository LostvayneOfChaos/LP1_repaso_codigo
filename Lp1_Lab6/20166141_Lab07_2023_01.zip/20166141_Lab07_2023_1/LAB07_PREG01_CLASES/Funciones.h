/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Funciones.h
 * Author: AXEL
 *
 * Created on 24 de octubre de 2023, 11:32 AM
 */
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>
using namespace std;

#ifndef FUNCIONES_H
#define FUNCIONES_H

char* leerCadena(ifstream &, char );

#endif /* FUNCIONES_H */

