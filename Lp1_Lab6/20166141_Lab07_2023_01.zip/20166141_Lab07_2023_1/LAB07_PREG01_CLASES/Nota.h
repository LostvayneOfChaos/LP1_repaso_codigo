/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Nota.h
 * Author: AXEL
 *
 * Created on 24 de octubre de 2023, 11:20 AM
 */
#include "AlumnoNota.h"
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>
#include "Funciones.h"
using namespace std;

#ifndef NOTA_H
#define NOTA_H
class Nota {
public:
    Nota();
    Nota(const Nota& orig);
    virtual ~Nota();
    void SetNota(int nota);
    int GetNota() const;
    void SetCiclo(int ciclo);
    int GetCiclo() const;
    void SetCodCurso(char* codCurso);
    void GetCodCurso(char* ) const;
    void operator =(class AlumnoNota &);
private:
    char*codCurso;
    int ciclo;
    int nota;
    
};

#endif /* NOTA_H */

