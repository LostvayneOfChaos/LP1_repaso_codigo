/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Funciones.h
 * Author: alulab14
 *
 * Created on 24 de octubre de 2023, 05:44 PM
 */
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>
using namespace std;

#ifndef FUNCIONES_H
#define FUNCIONES_H

char* leerCadena(ifstream &, char );
void cargaralumnos(class Alumno* lalumnos);
void carganotas(class AlumnoNota*lnotas);
void actualizanotas(class Alumno *lalumnos,class AlumnoNota*lnotas);
void imprimealumnos(class Alumno *lalumnos);
#endif /* FUNCIONES_H */

