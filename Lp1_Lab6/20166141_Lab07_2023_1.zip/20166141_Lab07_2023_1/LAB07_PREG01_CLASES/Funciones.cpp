/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>
#include "Funciones.h"
using namespace std;

char* leerCadena(ifstream &arch,char parametro){
    
    char*nombre;
    char buffer[100];
    arch.getline(buffer,100,parametro);
    nombre=new char[strlen(buffer)+1];
    strcpy(nombre,buffer);
    return nombre;
    
}