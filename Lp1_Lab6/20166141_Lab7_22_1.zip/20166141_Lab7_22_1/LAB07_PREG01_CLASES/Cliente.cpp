/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Cliente.cpp
 * Author: AXEL
 * 
 * Created on 26 de octubre de 2023, 02:22 PM
 */

#include "Cliente.h"

Cliente::Cliente() {
    nombre=nullptr;
    numped=0;
    total=0;
}

Cliente::Cliente(const Cliente& orig) {
}

Cliente::~Cliente() {
}

void Cliente::SetTotal(double total) {
    this->total = total;
}

double Cliente::GetTotal() const {
    return total;
}

void Cliente::SetNumped(int numped) {
    this->numped = numped;
}

int Cliente::GetNumped() const {
    return numped;
}

void Cliente::SetNombre(const char* nombre) {
    if(this->nombre != nullptr) delete(this->nombre);
    this->nombre=new char[strlen(nombre)+1];
    strcpy(this->nombre,nombre);
}

void Cliente::GetNombre(char* name) const {
    if(nombre ==nullptr) name[0]=0;
    strcpy(name,nombre);
    
}

void Cliente::SetCategoria(char categoria) {
    this->categoria = categoria;
}

char Cliente::GetCategoria() const {
    return categoria;
}

void Cliente::SetDni(int dni) {
    this->dni = dni;
}

int Cliente::GetDni() const {
    return dni;
}


void operator>>(ifstream &arch,
        class Cliente &CLIENTE){
    int dni;
    char aux,nombre[100],categoria;
    arch>>dni;
    if(arch.eof()) return;
    CLIENTE.SetDni(dni);
    arch>>aux;
    arch.getline(nombre,100,',');
    categoria=arch.get();
    arch.get();
    CLIENTE.SetCategoria(categoria);
    CLIENTE.SetNombre(nombre);
    CLIENTE.SetNumped(0);
    CLIENTE.SetTotal(0);
}
    
void Cliente::operator =(class Pedido &PEDIDO){
    
    lped[numped]=PEDIDO;
    total=total+(PEDIDO.GetPrecio());
    numped++;
}

void Cliente::operator -=(class Pedido &PEDIDO){
    int pos=-1;
    int codProd,fecha,dni;
    if(numped>1){
        codProd=PEDIDO.GetCodigo();
        fecha=PEDIDO.GetFecha();
        dni=PEDIDO.GetDni();
        for (int i = 0; i < numped; i++) {
            if(((lped[i].GetCodigo())==codProd)
                    &&((lped[i].GetFecha())==fecha)&&
                    ((lped[i].GetDni())==dni)){
                pos=i;
                break;
            }    
        }
        if(pos!=-1){
            
            for (int j = pos; j <numped-1 ; j++) {
                lped[j]=lped[j+1];
            }
            numped--;
            total=total-(PEDIDO.GetPrecio());
        }
        
    }
}

void Cliente::operator /(double descuento){
    double totalNuevo=0;
    for (int i = 0; i < numped; i++) {
        lped[i].SetPrecio((lped[i].GetPrecio()*(100-descuento)*1.0/100));
        totalNuevo+=lped[i].GetPrecio();
    }
    total=totalNuevo;
}

void Cliente::imprimirProductos(ofstream & arch)const {
    int fecha,dia,mes,anio;
    char nombre[100];
    for (int i = 0; i <numped ; i++) {
        //arch<<lped[i];
        fecha=lped[i].GetFecha();
        anio=fecha/10000;
        fecha= fecha%10000;
        mes=fecha/100;
        dia=fecha%100;
        arch<<left<<dia<<"/"<<mes<<"/"<<anio<<right<<
                setw(10)<<lped[i].GetCodigo();
        lped[i].GetNombre(nombre);
        arch<<setw(50)<<nombre<<setw(40)<<lped[i].GetCantidad()
                <<setw(10)<<lped[i].GetPrecio()<<endl;
    }
    arch<<"# de pedidos: "<<numped<<endl;
    arch<<"Monto Total: "<<total<<endl;
}

void operator<<(ofstream & arch,
        class Cliente &CLIENTE){
    char nombre[100];
    
    arch<<setw(8)<<CLIENTE.GetDni();
    CLIENTE.GetNombre(nombre);
    arch<<setw(50)<<nombre<<endl;
    for (int i = 0; i < 100; i++) {
        arch<<"-";
    }
    arch<<endl;
    CLIENTE.imprimirProductos(arch);
}