/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Cliente.h
 * Author: AXEL
 *
 * Created on 26 de octubre de 2023, 02:22 PM
 */

#ifndef CLIENTE_H
#define CLIENTE_H
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>
#include "Pedido.h"
using namespace std;
class Cliente {
public:
    Cliente();
    Cliente(const Cliente& orig);
    virtual ~Cliente();
    void SetTotal(double total);
    double GetTotal() const;
    void SetNumped(int numped);
    int GetNumped() const;
    void SetNombre(const char* nombre);
    void GetNombre(char* ) const;
    void SetCategoria(char categoria);
    char GetCategoria() const;
    void SetDni(int dni);
    int GetDni() const;
    void operator =(class Pedido &);
    void operator -=(class Pedido &);
    void operator /(double);
    void imprimirProductos(ofstream & arch)const ;
private:
    int dni;
    char categoria;
    char* nombre;
    Pedido lped[100];
    int numped;
    double total;
    
};

void operator>>(ifstream &,class Cliente &);
void operator<<(ofstream &,class Cliente &);

#endif /* CLIENTE_H */

