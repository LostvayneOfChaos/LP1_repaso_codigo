/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: AXEL
 *
 * Created on 26 de octubre de 2023, 02:19 PM
 */

#include <cstdlib>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>
#include "Pedido.h"
#include "Cliente.h"
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    
    ifstream archClientes("clientes2.csv",ios::in);
    if(not archClientes.is_open()){
        cout<<"No puede abrirse el archivo Clientes.csv"<<endl;
        exit(1);
    }
    ifstream archPedidos("pedidos2.csv",ios::in);
    if(not archPedidos.is_open()){
        cout<<"No puede abrirse el archivo Pedidos.csv"<<endl;
        exit(1);
    }
    ofstream archReporte("Reporte.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"No puede abrirse el archivo Reporte.txt"<<endl;
        exit(1);
    }    
    class Cliente clientes[10];
    class Pedido pedidos[10];
    for(int i=0;i<10;i++){
        archClientes>>clientes[i];
    }
    for(int i=0;i<10;i++){
        archPedidos>>pedidos[i];

    }
    
    
    for(int j=0;j<10;j++)
        for(int i=0;i<10;i++){
            clientes[j]=pedidos[i];
        }
    
    
    clientes[0]-=pedidos[0];
    clientes[1]-=pedidos[0];
    
    for(int i=4;i<10;i++){
        clientes[i]/25;
    }
    
    for(int i=0;i<10;i++){
        archReporte<<"---------"<<endl;
        archReporte<<"Nuevo cliente"<<i<<endl;
        archReporte<<"---------"<<endl;
        archReporte<<clientes[i];
    }
    
    return 0;
}

