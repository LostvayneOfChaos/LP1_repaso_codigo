/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Pedido.cpp
 * Author: AXEL
 * 
 * Created on 26 de octubre de 2023, 02:23 PM
 */

#include "Pedido.h"

Pedido::Pedido() {
    nombre=nullptr;
}

Pedido::Pedido(const Pedido& orig) {
}

Pedido::~Pedido() {
}

void Pedido::SetFecha(int fecha) {
    this->fecha = fecha;
}

int Pedido::GetFecha() const {
    return fecha;
}

void Pedido::SetDni(int dni) {
    this->dni = dni;
}

int Pedido::GetDni() const {
    return dni;
}

void Pedido::SetPrecio(double precio) {
    this->precio = precio;
}

double Pedido::GetPrecio() const {
    return precio;
}

void Pedido::SetCantidad(int cantidad) {
    this->cantidad = cantidad;
}

int Pedido::GetCantidad() const {
    return cantidad;
}

void Pedido::SetNombre(char* nombre) {
    if(this->nombre != nullptr) delete(this->nombre);
    this->nombre=new char[strlen(nombre)+1];
    strcpy(this->nombre,nombre);
}

void Pedido::GetNombre(char* name) const {
    if(nombre ==nullptr) name[0]=0;
    strcpy(name,nombre);
}

void Pedido::SetCodigo(int codigo) {
    this->codigo = codigo;
}

int Pedido::GetCodigo() const {
    return codigo;
}


void operator>>(ifstream &arch,
        class Pedido &PEDIDO){
    int codigo,cantidad,dni,fecha,dia,mes,anio;
    char aux,nombre[100];
    double precio;
    arch>>codigo;
    if(arch.eof()) return;
    arch>>aux;
    arch.getline(nombre,100,',');
    arch>>cantidad>>aux>>precio>>aux>>dni>>aux>>dia>>aux>>
            mes>>aux>>anio;
    arch.get();
    PEDIDO.SetCodigo(codigo);
    PEDIDO.SetCantidad(cantidad);
    PEDIDO.SetNombre(nombre);
    PEDIDO.SetDni(dni);
    PEDIDO.SetPrecio(precio);
    fecha=anio*10000+mes*100+dia;
    PEDIDO.SetFecha(fecha);
}
