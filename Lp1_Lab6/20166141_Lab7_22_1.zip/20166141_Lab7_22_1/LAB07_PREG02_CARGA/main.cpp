/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: AXEL
 *
 * Created on 26 de octubre de 2023, 05:55 PM
 */

#include <cstdlib>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>
#include "Pedido.h"
#include "Cliente.h"
using namespace std;

/*
 * 
 */
//con numClientes
/*int buscar(int dniPedido,class Cliente clientes[],
        int numClientes){
    
    for (int i = 0; i < numClientes; i++) {
        if (dniPedido==(clientes[i].GetDni())) {
            return i;
        }
    }
    return -1;
    
}
int main(int argc, char** argv) {
    
    ifstream archClientes("clientes2.csv",ios::in);
    if(not archClientes.is_open()){
        cout<<"No puede abrirse el archivo Clientes.csv"<<endl;
        exit(1);
    }
    ifstream archPedidos("pedidos2.csv",ios::in);
    if(not archPedidos.is_open()){
        cout<<"No puede abrirse el archivo Pedidos.csv"<<endl;
        exit(1);
    }
    ifstream archEliminar("eliminar2.csv",ios::in);
    if(not archEliminar.is_open()){
        cout<<"No puede abrirse el archivo eliminar2.csv"<<endl;
        exit(1);
    }
    ofstream archReporte("Reporte.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"No puede abrirse el archivo Reporte.txt"<<endl;
        exit(1);
    }    
    class Cliente clientes[20];
    class Pedido pedidos[200];
    class Pedido pedidosEliminar[20];
    int numClientes=0;
    while (1) {
        archClientes>>clientes[numClientes];
        if(archClientes.eof()) break;
        numClientes++;
    }
    int numPedidos=0;
    while (1) {
        archPedidos>>pedidos[numPedidos];
        if(archPedidos.eof()) break;
        numPedidos++;
    }
    int pos;
    for (int i = 0; i < numPedidos; i++) {
        //cliente=Pedido
        pos=buscar(pedidos[i].GetDni(),clientes,numClientes);
        if (pos!=-1) {
            clientes[pos]=pedidos[i];
        }
    }
    int numPedEliminar=0;
    while (1) {
        archEliminar>>pedidosEliminar[numPedEliminar];
        if(archEliminar.eof()) break;
        numPedEliminar++;
    }
    
    int posEliminar=0;
    for (int i = 0; i < numPedEliminar; i++) {
        //cliente-=Pedido
        posEliminar=buscar(pedidosEliminar[i].GetDni(),clientes,numClientes);
        if (posEliminar!=-1) {
            clientes[posEliminar]-=pedidosEliminar[i];
        }
    }
    char categoriaCliente;
    for (int i = 0; i < numClientes; i++) {
        categoriaCliente=clientes[i].GetCategoria();
        if(categoriaCliente=='A'){
            clientes[i]/10;
        }
    }
    
    for(int i=0;i<10;i++){
        archReporte<<"---------"<<endl;
        archReporte<<"Nuevo cliente"<<i<<endl;
        archReporte<<"---------"<<endl;
        archReporte<<clientes[i];
    }
    return 0;
}*/

//sin numClientes
int buscar(int dniPedido,class Cliente clientes[]){
    int i=0,num=0;
    
    while(1) {
        char nom1[100];
        clientes[i].GetNombre(nom1);
        if((strcmp(nom1,"XXX"))==0) break;
        if (dniPedido==(clientes[i].GetDni())) {
            return i;
        }
        i++;
        
    }
    return -1;
    
}
int main(int argc, char** argv) {
    
    ifstream archClientes("clientes2.csv",ios::in);
    if(not archClientes.is_open()){
        cout<<"No puede abrirse el archivo Clientes.csv"<<endl;
        exit(1);
    }
    ifstream archPedidos("pedidos2.csv",ios::in);
    if(not archPedidos.is_open()){
        cout<<"No puede abrirse el archivo Pedidos.csv"<<endl;
        exit(1);
    }
    ifstream archEliminar("eliminar2.csv",ios::in);
    if(not archEliminar.is_open()){
        cout<<"No puede abrirse el archivo eliminar2.csv"<<endl;
        exit(1);
    }
    ofstream archReporte("Reporte.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"No puede abrirse el archivo Reporte.txt"<<endl;
        exit(1);
    }    
    class Cliente clientes[20]{};
    class Pedido pedidos[200]{};
    class Pedido pedidosEliminar[20]{};
    int numClientes=0;
    while (1) {
        archClientes>>clientes[numClientes];
        if(archClientes.eof()) break;
        numClientes++;
    }
    clientes[numClientes].SetNombre("XXX");
    int numPedidos=0;
    while (1) {
        archPedidos>>pedidos[numPedidos];
        if(archPedidos.eof()) break;
        numPedidos++;
    }
    pedidos[numPedidos].SetNombre("XXX");
    int pos;
    int i=0;
    while(1){
        char nom1[100];
        pedidos[i].GetNombre(nom1);
        if((strcmp(nom1,"XXX"))==0) break;
        //cliente=Pedido
        pos=buscar(pedidos[i].GetDni(),clientes);
        if (pos!=-1) {
            clientes[pos]=pedidos[i];
        }
        i++;
    }
    int numPedEliminar=0;
    while (1) {
        archEliminar>>pedidosEliminar[numPedEliminar];
        if(archEliminar.eof()) break;
        numPedEliminar++;
    }
    pedidosEliminar[numPedEliminar].SetNombre("XXX");
    
    int posEliminar=0;
    int j=0;
    int valor=0;
    while(1){
        char nom1[100];
        pedidosEliminar[j].GetNombre(nom1);
        if((strcmp(nom1,"XXX"))==0) break;
        posEliminar=buscar(pedidosEliminar[j].GetDni(),clientes);
        if (posEliminar!=-1) {
            clientes[posEliminar]-=pedidosEliminar[j];
        }
        j++;
    }
    int k=0;
    int valor2=0;
    char categoriaCliente;
    while(1) {
        char nom1[100];
        clientes[k].GetNombre(nom1);
        if((strcmp(nom1,"XXX"))==0) break;
        categoriaCliente=clientes[k].GetCategoria();
        if(categoriaCliente=='A'){
            clientes[k]/10;
        }
        k++;
    }
    
    int p=0;
    while(1){
        char nom1[100];
        clientes[p].GetNombre(nom1);
        if((strcmp(nom1,"XXX"))==0) break;
        archReporte<<"---------"<<endl;
        archReporte<<"Nuevo cliente"<<p<<endl;
        archReporte<<"---------"<<endl;
        archReporte<<clientes[p];
        p++;
    }
    return 0;
}