/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
#include "AsignacionDinamicaIncrementos.h"
#define INCREMENTO 5
using namespace std;




char *leerCadena(ifstream &inProductos){
    char buffer[100];
    char* nombre;
    inProductos.getline(buffer,100,',');
    nombre=new char[strlen(buffer)+1];
    strcpy(nombre,buffer);
    return nombre;
    
}

void aumentarEspacio(char***& productos, int *&stock, double *&precios,
        int & nd,int &cap){
    
    cap +=INCREMENTO;
    char***auxProd;
    double * auxPrecio;
    int * auxStock;
    
    if (stock == nullptr) {
        
        stock=new int[cap]{};
        precios=new double[cap]{};
        productos=new char**[cap]{};
        nd=1;
        
        
    } else {
        //si ya existe un arreglo de productos  y ya se lleno
        auxStock=new int[cap]{}; 
        auxPrecio=new double[cap]{};
        auxProd=new char**[cap]{};
        
        for (int i = 0; i <  nd; i++) {
            auxProd[i]=productos[i];
            auxPrecio[i]=precios[i];
            auxStock[i]=stock[i];
        }
        //sucede que se guarda todo,pero cuando veo los productos luego de auxProd no se guarda nada,se guarda una direccion cualquiera
        /*for (int i = 0; i <  nd-1; i++) {
            delete productos[i];
        }*/
        delete precios;
        delete stock;
        delete productos;
        
        productos=auxProd;
        precios=auxPrecio;
        stock=auxStock;
        
    }
}






void lecturaDeProductos (const char*nombreArchivo, 
        char***& productos, int *&stock, double *&precios){
    
    ifstream inProductos(nombreArchivo,ios::in);
    if (!inProductos) {
        cout<<"error al abrir el archivo";
        exit(1);
        
    }
    productos=nullptr;
    stock=nullptr;
    precios=nullptr;
    
    int nd=0,cap=0,stockProd=0;
    char*codigo,*descripcion,**producto;
    double precio=0;
    producto=nullptr;
    //YOT-530,Deshumedecedor DM-190H,941.73,13
    while (true) {
        codigo=leerCadena(inProductos);
        if(inProductos.eof()) break;
        descripcion=leerCadena(inProductos);
        inProductos>>precio;
        inProductos.get();
        inProductos>>stockProd;
        inProductos.get();
        if(nd==cap) aumentarEspacio(productos, stock, precios,nd,cap);
        producto=new char*[2]; //creo un producto
        producto[0]=codigo;
        producto[1]=descripcion;
        //
        /*insertarOrdenadoProductos(productos, stock, precios,producto,
                stockProd,precio,nd,cap);*/
        productos[nd-1]=producto;
        stock[nd-1]=stockProd;
        precios[nd-1]=precio;
        nd++;
    }
    
    inProductos.close();
}



void pruebaDeLecturaDeProductos (const char*nombreArchivo, 
        char***& productos, int *&stock, double *&precios){
    
    ofstream outProductos(nombreArchivo,ios::out);
    if (!outProductos) {
        cout<<"error al abrir el archivo";
        exit(1);
        
    }
    
    outProductos<<fixed;
    outProductos<<setprecision(2);
    char** producto;
    for (int i = 0; productos[i]; i++) {
        producto=productos[i];
        outProductos<<setw(10)<<producto[0]<<setw(10)<<producto[1]<<endl;
    }
    for (int i = 0; stock[i]; i++) {
        outProductos<<setw(10)<<stock[i]<<setw(10)<<precios[i]<<endl;
    }

    
    outProductos.close();
    
}



int buscarPosicion(int& fecha,int*&fechaPedidos,int &nd){
    
    for (int i = 0; i < nd; i++) {
        if(fecha==fechaPedidos[i]) return i;
    }
    return -1;
    
}


void aumentarEspacioPedidos(int & fechaPedido, char**& codigoPedidoFecha,
        int**& dniCantPedidoFecha,int**& arregloPersona,
        int &cantDni,char**&arregloCodigo,int &cantCodigo,int &capCodigo,
        int &capDni){
    
    //aca aumentas tamaño de los subarreglos
    capCodigo+=INCREMENTO;
    capDni+=INCREMENTO;
    char**auxCodigo;
    int ** auxDni;
    
    if((codigoPedidoFecha ==nullptr)||(dniCantPedidoFecha == nullptr)){
        //quiere decir que tambien aplicas para dni
        dniCantPedidoFecha=new int*[capCodigo]{};
        codigoPedidoFecha=new char*[capDni]{};
        //arregloPersona=nullptr;
        //arregloCodigo=nullptr;
        cantDni=1;
        cantCodigo=1;
    }
    else{
        auxDni=new int*[capDni]{};
        auxCodigo=new char*[capCodigo]{};
        
        for (int i = 0; i <  cantDni; i++) {
            auxDni[i]=dniCantPedidoFecha[i];
            auxCodigo[i]=codigoPedidoFecha[i];
        }
        
        delete dniCantPedidoFecha;
        delete codigoPedidoFecha;
        
        dniCantPedidoFecha=auxDni;
        codigoPedidoFecha=auxCodigo;
    }
    
    
}

void aumentarValoresFechaExistente(int &pos, int & fechaPedido, char**& codigoPedidoFecha,
        int**& dniCantPedidoFecha,char* &codigo,int &dni,int &fecha,int & cantidad,
        int &cantCodigo,int&cantDni,
        int& capCodigo ,int& capDni){
    
    //por fecha
    int*dato,**arregloPersona;
    char** arregloCodigo;
    arregloCodigo=nullptr;
    arregloPersona=nullptr;
    if(cantCodigo==capCodigo)
        //aca aumentaras tamaño de los sub arreglos
        aumentarEspacioPedidos(fechaPedido,codigoPedidoFecha,dniCantPedidoFecha
            ,arregloPersona,cantDni,arregloCodigo,cantCodigo,capCodigo,capDni);

    
    dato=new int[2]; //creo un producto
    dato[0]=dni;
    dato[1]=cantidad;
    //insertar ordenado
    arregloPersona=dniCantPedidoFecha;
    arregloPersona[cantDni-1]=dato;
    cantDni++;
    arregloCodigo=codigoPedidoFecha;
    arregloCodigo[cantCodigo-1]=codigo;
    cantCodigo++;
    
}

void aumentarEspacioFecha(int *& fechaPedidos, char***& codigoPedidos,
        int***& dniCantPedidos,char* codigo,
                    int dni,int fecha,int cantidad,int &nd,int &cap){
    
    cap+=INCREMENTO;
    int *auxFecha,***auxDni;
    char ***auxCodigo;
    if(fechaPedidos==nullptr){
        
        fechaPedidos=new int[cap]{};
        codigoPedidos=new char**[cap]{};
        dniCantPedidos=new int**[cap]{};
        
        nd=1;
    }
    else{
        auxFecha=new int[cap]{};
        auxCodigo=new char**[cap]{};
        auxDni=new int**[cap]{};
        
        for (int i = 0; i <  nd; i++) {
            auxDni[i]=dniCantPedidos[i];
            auxCodigo[i]=codigoPedidos[i];
            auxFecha[i]=fechaPedidos[i];
            
        }
        
        delete dniCantPedidos;
        delete codigoPedidos;
        delete fechaPedidos;
        
        dniCantPedidos=auxDni;
        codigoPedidos=auxCodigo;
        fechaPedidos=auxFecha;
        
        
    }
    
    
    
    
    
    
    
}

void aumentarValoresFechaOrdenado(int &pos, int & fechaPedido, char**& codigoPedidoFecha,
        int**& dniCantPedidoFecha,char* &codigo,int &dni,int &fecha,int & cantidad,
        int &cantCodigo,int&cantDni,
        int& capCodigo ,int& capDni){
    
    //por fecha
    int*dato,**arregloPersona;
    char** arregloCodigo;
    arregloCodigo=nullptr;
    arregloPersona=nullptr;
    if(cantCodigo==capCodigo)
        //aca aumentaras tamaño de los sub arreglos
        aumentarEspacioPedidos(fechaPedido,codigoPedidoFecha,dniCantPedidoFecha
            ,arregloPersona,cantDni,arregloCodigo,cantCodigo,capCodigo,capDni);

    
    dato=new int[2]; //creo un producto
    dato[0]=dni;
    dato[1]=cantidad;
    //insertar ordenado
    arregloPersona=dniCantPedidoFecha;
    arregloPersona[cantDni-1]=dato;
    cantDni++;
    arregloCodigo=codigoPedidoFecha;
    arregloCodigo[cantCodigo-1]=codigo;
    cantCodigo++;
    
}

void insertarOrdenadoFecha(int *& fechaPedidos, char***& codigoPedidos,
        int***& dniCantPedidos,int fecha, char* & codigo,
                    int dni,int cantidad,
        int cantCodigoPedidosxFecha[]
                   ,int  cantdniPedidosxFecha[],
                    int  capCodigos[],int  capDniPedidosXFecha[],int &nd,int &cap){
    
    int i=0,bandera=0, pos;
    for (i = 0; i < nd-1; i++) {
        if(fechaPedidos[i]>fecha) {
            bandera=1;//se puede insertar en el medio del arreglo
            break;
        }
    }
    if (bandera==1) {
        for (int j = nd-1; j >=i; j--) {
            fechaPedidos[j+1]=fechaPedidos[j];
            codigoPedidos[j+1]=codigoPedidos[j];
            cantCodigoPedidosxFecha[j+1]=cantCodigoPedidosxFecha[j];//nuevo
            capCodigos[j+1]=capCodigos[j];//nuevo
            dniCantPedidos[j+1]=dniCantPedidos[j];
            cantdniPedidosxFecha[j+1]=cantdniPedidosxFecha[j];//nuevo
            capDniPedidosXFecha[j+1]=capDniPedidosXFecha[j];//nuevo
        
        }
        fechaPedidos[i]=fecha;
        codigoPedidos[i]= nullptr;
        dniCantPedidos[i]= nullptr;
        cantdniPedidosxFecha[i]=0;//nuevo
        cantCodigoPedidosxFecha[i]=0;
        capCodigos[i]=0;
        capDniPedidosXFecha[i]=0;
        
        
        
        pos=i;//nuevo
        aumentarValoresFechaOrdenado(pos,fechaPedidos[pos],codigoPedidos[pos]
                    ,dniCantPedidos[pos],codigo,
                    dni,fecha,cantidad,cantCodigoPedidosxFecha[pos],
                cantdniPedidosxFecha[pos],
                    capCodigos[pos],capDniPedidosXFecha[pos]);//nuevo
        /*cantCodigoPedidosxFecha[i]++;
        cantdniPedidosxFecha[i]++;*/
        
        
    }
    else{
        //se inserta fecha al final porque no hay en el medio
        pos=nd-1;
        fechaPedidos[nd-1]=fecha;
        codigoPedidos[nd-1]= nullptr;
        dniCantPedidos[nd-1]= nullptr;
            
        aumentarValoresFechaOrdenado(pos,fechaPedidos[pos],codigoPedidos[pos]
                    ,dniCantPedidos[pos],codigo,
                    dni,fecha,cantidad,cantCodigoPedidosxFecha[pos],
                cantdniPedidosxFecha[pos],
                    capCodigos[pos],capDniPedidosXFecha[pos]);
    }
    nd++;
    
}



void lecturaDePedidos (const char*nombreArchivo, 
        int *& fechaPedidos, char***& codigoPedidos, int***& dniCantPedidos){
    
    
    ifstream inPedidos(nombreArchivo,ios::in);
    if (!inPedidos) {
        cout<<"error al abrir el archivo";
        exit(1);
        
    }
    fechaPedidos=nullptr;
    codigoPedidos=nullptr;
    dniCantPedidos=nullptr;
    int nd=0,cap=0,dni=0,cantidad,dia,mes,anio,fecha,pos,cantCodigoPedidosxFecha[700]{},
           capCodigos[700]{} ,
            cantdniPedidosxFecha[700]{}, capDniPedidosXFecha[700]{};
    char*codigo,c;
    codigo=nullptr;
    char**arregloCodigo;
    int**arregloDni;
    while (true) {
        codigo=leerCadena(inPedidos);
        if(inPedidos.eof()) break;
        inPedidos>>dni>>c>>cantidad>>c>>dia>>c>>mes>>c>>anio;
        inPedidos.get();
        fecha=anio*10000+mes*100+dia;
        pos=buscarPosicion(fecha,fechaPedidos,nd);
        if (pos!=-1) {
            //ya esta la fecha ahi en el arreglo
            
            aumentarValoresFechaExistente(pos,fechaPedidos[pos],codigoPedidos[pos]
                    ,dniCantPedidos[pos],codigo,
                    dni,fecha,cantidad,cantCodigoPedidosxFecha[pos],cantdniPedidosxFecha[pos],
                    capCodigos[pos],capDniPedidosXFecha[pos]);
        }
        else{
            //creas una fecha
            if(nd==cap) aumentarEspacioFecha(fechaPedidos,codigoPedidos
                    ,dniCantPedidos,codigo,
                    dni,fecha,cantidad,nd,cap);
            
            insertarOrdenadoFecha(fechaPedidos,codigoPedidos,
                    dniCantPedidos,fecha,codigo,
                    dni,cantidad,cantCodigoPedidosxFecha,cantdniPedidosxFecha,
                    capCodigos,capDniPedidosXFecha,nd,cap);
            /*pos=nd-1;
            fechaPedidos[nd-1]=fecha;
            codigoPedidos[nd-1]= nullptr;
            dniCantPedidos[nd-1]= nullptr;
            
            aumentarValoresFechaExistente(pos,fechaPedidos[pos],codigoPedidos[pos]
                    ,dniCantPedidos[pos],codigo,
                    dni,fecha,cantidad,cantCodigoPedidosxFecha[pos],cantdniPedidosxFecha[pos],
                    capCodigos[pos],capDniPedidosXFecha[pos]);
              nd++;*/
            //trabajas con capacidad aca porque al crear fecha añades o actualizas nd
        }
        
    }
    
    inPedidos.close();
    
}


void pruebaDeLecturaDePedidos (const char*nombreArchivo, 
        int *& fechaPedidos, char***& codigoPedidos, int***& dniCantPedidos){
    
    
    
    ofstream outPedidos(nombreArchivo,ios::out);
    if (!outPedidos) {
        cout<<"error al abrir el archivo";
        exit(1);
        
    }
    
    outPedidos<<fixed;
    outPedidos<<setprecision(2);
    char** codigo;
    int** dni,*persona;
    for (int i = 0; codigoPedidos[i]; i++) {
        codigo=codigoPedidos[i];
        for (int j = 0; codigo[j]; j++) {
            outPedidos<<setw(10)<<codigo[j]<<"  ";
        }
        cout<<endl;
        
    }
    for (int i = 0; dniCantPedidos[i]; i++) {
        dni=dniCantPedidos[i];
        for (int j = 0; dni[j]; j++) {
            persona=dni[j];
            outPedidos<<setw(10)<<persona[0]<<"  "<<persona[1]<<endl;
            
        }
        cout<<endl;
        
    }
    for (int i = 0; fechaPedidos[i]; i++) {
        outPedidos<<setw(10)<<fechaPedidos[i]<<endl;
    }

    
    outPedidos.close();
    
    
    
}

void reporteDeEnvioDePedidos (const char*nombreArchivo,
        char***& productos, int *&stock, double *&precios,
            int *& fechaPedidos, char***& codigoPedidos,
        int***& dniCantPedidos){
    
    
    ofstream outFinal(nombreArchivo,ios::out);
    if (!outFinal) {
        cout<<"error al abrir el archivo";
        exit(1);
        
    }
    
    outFinal<<fixed;
    outFinal<<setprecision(2);
    
    double suma=0;
    double precio=0;
    char** codigo;
    int** dni,*persona,stockP=0,restanteFecha,anio;
    char*descripcion,**prod;
    descripcion=nullptr;
    
    for (int i = 0; fechaPedidos[i]; i++) {
        anio=fechaPedidos[i]/10000;
        restanteFecha=fechaPedidos[i]%10000;
        outFinal<<left<<"fecha: "<<setw(4)<<anio<<"/"
                <<restanteFecha/100<<"/"<<restanteFecha%100<<endl;
        outFinal<<left<<" No.   DNI      Producto      Cantidad"
                "     Precio     Total de ingresos"<<endl;
                dni=dniCantPedidos[i];
                for (int j = 0; dni[j]; j++) {
                    persona=dni[j];
                    outFinal<<j+1<<") "<<right<<setw(10)<<persona[0];
                    codigo=codigoPedidos[i];
                    outFinal<<setw(20)<<codigo[j];
                    for (int p = 0; productos[p]; p++) {
                        prod=productos[p];
                        if (strcmp(prod[0],codigo[j])==0) {
                            descripcion=prod[1];
                            precio=precios[p];
                            stockP=stock[p];
                            break;
                        }
                    }
                    outFinal<<setw(60)<<descripcion;
                    if(stockP==0){
                        outFinal<<setw(10)<<persona[1]<<setw(20)<<precio<<setw(40)<<"MO HAY STOCK "<<endl;
                    }
                    
                    else
                        outFinal<<setw(10)<<persona[1]<<setw(20)<<precio
                            <<setw(40)<<precio*persona[1]<<endl;
                    
                    
                    
                }
                outFinal<<"Total ingresado: "<<  "AAAAAAAAA"<<endl;
        
    }
    

    
    outFinal.close();
    
    
    
    
    
}