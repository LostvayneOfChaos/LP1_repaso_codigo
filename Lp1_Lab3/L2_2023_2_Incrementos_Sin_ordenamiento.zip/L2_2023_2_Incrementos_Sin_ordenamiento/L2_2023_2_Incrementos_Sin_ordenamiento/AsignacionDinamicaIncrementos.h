/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   AsignacionDinamicaIncrementos.h
 * Author: AXEL
 *
 * Created on 12 de septiembre de 2023, 02:52 PM
 */
#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>

using namespace std;
#ifndef ASIGNACIONDINAMICAINCREMENTOS_H
#define ASIGNACIONDINAMICAINCREMENTOS_H

void lecturaDeProductos (const char*nombreArchivo, 
        char***& productos, int *&stock, double *&precios);
void aumentarEspacio(char***& productos, int *&stock, double *&precios,
        int & nd,int &cap);
char *leerCadena(ifstream &inProductos);
void aumentarEspacio(char***& productos, int *&stock, double *&precios,
        int & nd,int &cap);
void pruebaDeLecturaDeProductos (const char*nombreArchivo, 
        char***& productos, int *&stock, double *&precios);
void lecturaDePedidos (const char*nombreArchivo, 
        int *& fechaPedidos, char***& codigoPedidos, int***& dniCantPedidos);
void aumentarValoresFechaExistente(int &pos, int & fechaPedido, char**& codigoPedidoFecha,
        int**& dniCantPedidoFecha,char* &codigo,int &dni,int &fecha,int & cantidad,
        int &cantCodigo,int&cantDni,
        int& capCodigo ,int& capDni);
int buscarPosicion(int& fecha,int*&fechaPedidos,int &nd);
void aumentarEspacioPedidos(int & fechaPedido, char**& codigoPedidoFecha,
        int**& dniCantPedidoFecha,int**& arregloPersona,
        int &cantDni,char**&arregloCodigo,int &cantCodigo,int &capCodigo,
        int &capDni);
void aumentarEspacioFecha(int *& fechaPedidos, char***& codigoPedidos,
        int***& dniCantPedidos,char* codigo,
                    int dni,int fecha,int cantidad,int &nd,int &cap);

void pruebaDeLecturaDePedidos (const char*nombreArchivo, 
        int *& fechaPedidos, char***& codigoPedidos, int***& dniCantPedidos);

void reporteDeEnvioDePedidos (const char*nombreArchivo,
        char***& productos, int *&stock, double *&precios,
            int *& fechaPedidos, char***& codigoPedidos,
        int***& dniCantPedidos);
#endif /* ASIGNACIONDINAMICAINCREMENTOS_H */

