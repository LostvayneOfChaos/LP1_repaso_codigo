/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: AXEL
 *
 * Created on 12 de septiembre de 2023, 02:43 PM
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
#include "AsignacionDinamicaIncrementos.h"

using namespace std;

int main(int argc, char** argv) {
    
    char ***productos,***codigoPedidos;
    int *stock, *fechaPedidos, ***dniCantPedidos;
    double *precios;
    
    lecturaDeProductos ("Productos.csv",productos, stock, precios);
    pruebaDeLecturaDeProductos ("ReporteDeProductos.txt" ,productos, stock, precios);
    /*lecturaDePedidos ("Pedidos.csv", fechaPedidos, codigoPedidos, dniCantPedidos);
    pruebaDeLecturaDePedidos ("ReporteDePedidos.txt", fechaPedidos, codigoPedidos, dniCantPedidos);
    reporteDeEnvioDePedidos ("ReporteDeEntregaDePedisos.txt", productos, stock, precios,
            fechaPedidos, codigoPedidos, dniCantPedidos);
    pruebaDeLecturaDeProductos ("ReporteDeProductosFinal.txt" ,productos, stock, precios);
    */return 0;
}

