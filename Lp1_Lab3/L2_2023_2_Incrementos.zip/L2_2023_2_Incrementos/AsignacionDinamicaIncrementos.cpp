/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
#include "AsignacionDinamicaIncrementos.h"
#define INCREMENTO 5
using namespace std;




char *leerCadena(ifstream &inProductos){
    char buffer[100];
    char* nombre;
    inProductos.getline(buffer,100,',');
    nombre=new char[strlen(buffer)+1];
    strcpy(nombre,buffer);
    return nombre;
    
}

void aumentarEspacio(char***& productos, int *&stock, double *&precios,
        int & nd,int &cap){
    
    cap +=INCREMENTO;
    char***auxProd;
    double * auxPrecio;
    int * auxStock;
    
    if (stock == nullptr) {
        
        stock=new int[cap]{};
        precios=new double[cap]{};
        productos=new char**[cap]{};
        nd=1;
        
        
    } else {
        //si ya existe un arreglo de productos  y ya se lleno
        auxStock=new int[cap]{}; 
        auxPrecio=new double[cap]{};
        auxProd=new char**[cap]{};
        
        for (int i = 0; i <  nd; i++) {
            auxProd[i]=productos[i];
            auxPrecio[i]=precios[i];
            auxStock[i]=stock[i];
        }
        //sucede que se guarda todo,pero cuando veo los productos luego de auxProd no se guarda nada,se guarda una direccion cualquiera
        /*for (int i = 0; i <  nd-1; i++) {
            delete productos[i];
        }
        delete productos;*/
        delete precios;
        delete stock;
        
        productos=auxProd;
        precios=auxPrecio;
        stock=auxStock;
        
    }
}






void lecturaDeProductos (const char*nombreArchivo, 
        char***& productos, int *&stock, double *&precios){
    
    ifstream inProductos(nombreArchivo,ios::in);
    if (!inProductos) {
        cout<<"error al abrir el archivo";
        exit(1);
        
    }
    productos=nullptr;
    stock=nullptr;
    precios=nullptr;
    
    int nd=0,cap=0,stockProd=0;
    char*codigo,*descripcion,**producto;
    double precio=0;
    producto=nullptr;
    //YOT-530,Deshumedecedor DM-190H,941.73,13
    while (true) {
        codigo=leerCadena(inProductos);
        if(inProductos.eof()) break;
        descripcion=leerCadena(inProductos);
        inProductos>>precio;
        inProductos.get();
        inProductos>>stockProd;
        inProductos.get();
        if(nd==cap) aumentarEspacio(productos, stock, precios,nd,cap);
        producto=new char*[2]; //creo un producto
        producto[0]=codigo;
        producto[0]=descripcion;
        //insertar ordenado
        productos[nd-1]=producto;
        stock[nd-1]=stockProd;
        precios[nd-1]=precio;
        nd++;
    }
    
    inProductos.close();
}



void pruebaDeLecturaDeProductos (const char*nombreArchivo, 
        char***& productos, int *&stock, double *&precios){
    
    ofstream outProductos(nombreArchivo,ios::out);
    if (!outProductos) {
        cout<<"error al abrir el archivo";
        exit(1);
        
    }
    
    outProductos<<fixed;
    outProductos<<setprecision(2);
    char** producto;
    for (int i = 0; productos[i]; i++) {
        producto=productos[i];
        outProductos<<setw(10)<<producto[0]<<setw(10)<<producto[1]<<endl;
    }
    for (int i = 0; stock[i]; i++) {
        outProductos<<setw(10)<<stock[i]<<setw(10)<<precios[i]<<endl;
    }

    
    outProductos.close();
    
}