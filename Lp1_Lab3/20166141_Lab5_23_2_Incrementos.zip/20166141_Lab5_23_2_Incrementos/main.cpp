/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Axel mendoza
 *
 * Created on 14 de septiembre de 2023, 03:53 PM
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>

using namespace std;

#include "MetodoPorIncrementos.h"

int main(int argc, char** argv) {
    char ***cursos_datos, ****cursos_alumnos;
    int *cursos_credito;
    double **cursos_informacion_economica;
    
    cargarCursos ("Matricula.txt", cursos_datos, cursos_credito, cursos_alumnos,cursos_informacion_economica);
    /*pruebaCursos ("PruebaCursos.txt", cursos_datos, cursos_credito, cursos_alumnos, cursos_informacion_economica);
    reporteDeAlumnosPorCurso ("ReporteDeAlumnosPorCurso.txt", cursos_datos, cursos_credito, cursos_alumnos,cursos_informacion_economica);
    */return 0;
}

