/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
#define ValorEscala1 282.3
#define ValorEscala2 362
#define ValorEscala3 454.2
#define ValorEscala4 556.7
#define ValorEscala5 666.9
#define INCREMENTO 5

using namespace std;

#include "MetodoPorIncrementos.h"


char* leerCadena(ifstream &inCursos){
    
    char cadena[100];
    char *nombre;
    inCursos.getline(cadena,100,',');
    nombre=new char[strlen(cadena)+1];
    strcpy(nombre,cadena);
    return nombre;
    
}


void aumentarEspacios(char ***&cursos_datos, 
        int *&cursos_credito,
        char ****&cursos_alumnos,double **&cursos_informacion_economica,
        int &nd,int &cap){
    
    cap+=INCREMENTO;
    char***auxDatos,****auxAlumno;
    int *auxCreditos;
    double **auxInfo;
    if (cursos_credito==nullptr) {
        
        cursos_credito=new int[cap]{};
        cursos_datos=new char**[cap]{};
        cursos_alumnos=new char***[cap]{};
        cursos_informacion_economica=new double*[cap]{};
        nd=1;
        
    } 
    else {
        auxCreditos=new int[cap]{};
        auxDatos=new char**[cap]{};
        auxAlumno=new char***[cap]{};
        auxInfo=new double*[cap]{};
        
        for (int i = 0; i < nd; i++) {
            auxCreditos[i]=cursos_credito[i];
            auxDatos[i]=cursos_datos[i];
            auxInfo[i]=cursos_informacion_economica[i];
            auxAlumno[i]=cursos_alumnos[i];
        }
        
        delete cursos_credito;
        delete cursos_datos;
        delete cursos_alumnos;
        delete cursos_informacion_economica;
        
        cursos_credito=auxCreditos;
        cursos_datos=auxDatos;
        cursos_alumnos=auxAlumno;
        cursos_informacion_economica= auxInfo;
        
        
        
    }

    
    
    
    
    
    
}




void insertarCursos(char ***&cursos_datos, 
        int *&cursos_credito,char* &codigoCurso,
        char* &nombreCurso,int cantCreditos,
        char ****&cursos_alumnos,double **&cursos_informacion_economica,
        int &nd,int &cap){
    
    
    char**arreglo;
    char** dato;
    if(nd==cap)aumentarEspacios(cursos_datos,cursos_credito,
            cursos_alumnos,cursos_informacion_economica,nd,cap);
    
    arreglo=cursos_datos[nd-1];
    dato=new char*[2];
    dato[0]=codigoCurso;
    dato[1]=nombreCurso;
    arreglo=dato;
    cursos_credito[nd-1]=cantCreditos;
    
    nd++;
    
    
    
}


void aumentarEspacioAlumnos(char ***&curso_alumnos,
        double *&curso_informacion_economica,
        int &cantAlumnos,
        int &capAlumnos){
    
    capAlumnos+=INCREMENTO;
    char*** auxAlumno;
    double *auxInfo;
    if (curso_alumnos==nullptr) {
        curso_alumnos=new char**[capAlumnos]{};
        curso_informacion_economica=new double[capAlumnos]{};
        cantAlumnos=1;
        
    } else {
        auxAlumno=new char**[capAlumnos]{};
        auxInfo=new double[capAlumnos]{};
        for (int i = 0; i < cantAlumnos; i++) {
            auxAlumno[i]=curso_alumnos[i];
            auxInfo[i]=curso_informacion_economica[i];
            
        }
        
        delete curso_alumnos;
        delete curso_informacion_economica;

        curso_alumnos=auxAlumno;        
        curso_informacion_economica=auxInfo;        
    }
    
    
    
    
    
    
    
}




void insertarAlumnos(int pos,int curso_creditos,
        char ***&curso_alumnos,
        double *&curso_informacion_economica,
        char *&nombreAlumno,char *&codigoEscala,
        int &cantAlumnos,int& capAlumnos){
    
    
    char**persona;
    double* informacion;
    if (cantAlumnos==capAlumnos) 
        aumentarEspacioAlumnos(curso_alumnos,curso_informacion_economica,cantAlumnos,
                capAlumnos);
    
    
    persona=new char*[2];
    persona[0]=codigoEscala;
    persona[1]=nombreAlumno;
    curso_alumnos[cantAlumnos-1]=persona;
    informacion=new double[2]{};
    informacion[0]=cantAlumnos*1.0;
    char escala=codigoEscala[strlen(codigoEscala)-1];
    if (escala=='1') {
        informacion[1]+=(curso_creditos*ValorEscala1);
    }
    else if (escala=='2') {
        informacion[1]+=(curso_creditos*ValorEscala2);
    }
    else if (escala=='3') informacion[1]+=(curso_creditos*ValorEscala3);
    else if (escala=='4') informacion[1]+=(curso_creditos*ValorEscala4);
    else if (escala=='5') informacion[1]+=(curso_creditos*ValorEscala5);
    
    curso_informacion_economica=informacion;
    
    cantAlumnos++;
    
    
}



void cargarCursos (const char *nombreArchivo, char ***&cursos_datos, 
        int *&cursos_credito, 
        char ****&cursos_alumnos,double **&cursos_informacion_economica){
    
    ifstream inCursos(nombreArchivo,ios::in);
    if (!inCursos) {
        cout<<"error al abrir el archivo ";
        exit(1);
    }
    char *codigoCurso,*nombreCurso,c,*nombreAlumno,*codigoEscala;
    int nd=0,cap=0,cantCreditos;
    int cantAlumnos,capAlumnos;
    //INF281,Lenguajes de Programacion 1,5,Erasmo Gomez,20082060.5,ABD.....
    cursos_datos=nullptr;
    cursos_credito=nullptr;
    cursos_alumnos=nullptr;
    cursos_informacion_economica=nullptr;
    while (true) {
        codigoCurso=leerCadena(inCursos);
        if(inCursos.eof()) break;
        nombreCurso=leerCadena(inCursos);
        inCursos>>cantCreditos>>c;
        insertarCursos(cursos_datos, cursos_credito,codigoCurso,
                nombreCurso,cantCreditos,cursos_alumnos,cursos_informacion_economica,
                nd,cap);
        cantAlumnos=0;
        capAlumnos=0;
        
        
        while (true){
            nombreAlumno=leerCadena(inCursos);
            c=inCursos.get();
            if (c!='\n') {
                //cin>>codigo>>c>>escala>>c;
                codigoEscala=leerCadena(inCursos);
                insertarAlumnos(nd-1,cursos_credito[nd-1],cursos_alumnos[nd-1],
                        cursos_informacion_economica[nd-1],
                        nombreAlumno,codigoEscala,cantAlumnos,capAlumnos);
                
            }
            else{
                delete nombreAlumno;
                break;
            }
        } 
    }

    inCursos.close();
}