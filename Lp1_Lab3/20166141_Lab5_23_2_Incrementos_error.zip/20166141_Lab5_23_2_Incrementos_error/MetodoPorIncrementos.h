/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   MetodoPorIncrementos.h
 * Author: alulab14
 *
 * Created on 14 de septiembre de 2023, 04:16 PM
 */
#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>

using namespace std;

#ifndef METODOPORINCREMENTOS_H
#define METODOPORINCREMENTOS_H


void cargarCursos (const char *nombreArchivo, char ***&cursos_datos, 
        int *&cursos_credito, 
        char ****&cursos_alumnos,double **&cursos_informacion_economica);
char* leerCadena(ifstream &inCursos);
void aumentarEspacios(char ***&cursos_datos, 
        int *&cursos_credito,
        char ****&cursos_alumnos,double **&cursos_informacion_economica,
        int &nd,int &cap);
void insertarCursos(char ***&cursos_datos, 
        int *&cursos_credito,char* &codigoCurso,
        char* &nombreCurso,int cantCreditos,
        char ****&cursos_alumnos,double **&cursos_informacion_economica,
        int &nd,int &cap);
void insertarAlumnos(int pos,int curso_creditos,
        char ***&curso_alumnos,
        double *&curso_informacion_economica,
        char *&nombreAlumno,char *&codigoEscala,
        int &cantAlumnos,int& capAlumnos);
void aumentarEspacioAlumnos(char ***&curso_alumnos,
        double *&curso_informacion_economica,
        int &cantAlumnos,
        int &capAlumnos);
void imprimirLinea(ofstream& arch, char caracter, int repeticiones);
void imprimirDetalleAlumnosCurso(ofstream& arch, char ***infoAlumno,
            int creditos, double& pagoTotalCiclo);
double obtenerPrecioPorEscala(int escala);
void imprimirAlumnoYAcumularTotalCurso(ofstream& arch, int indice, 
        char** detalleAlumno, int creditos, double& pagoTotalCurso);
void pruebaCursos (const char *nombreArch, char ***&cursos_datos, 
        int *&cursos_credito, 
        char ****&cursos_alumnos,double **&cursos_informacion_economica);

#endif /* METODOPORINCREMENTOS_H */

