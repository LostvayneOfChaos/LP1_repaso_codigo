/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   PunterosGenericos.cpp
 * Author: gtorr
 *
 * Created on October 5, 2023, 9:18 AM
 */
#include <cstdlib>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "MuestraPunteros.h"
#include "PunterosGenericos.h"
#define INCREMENTO 5
void cargaproductos(void *&productos){
    ifstream arch("productos2.csv",ios::in);
    if(not arch.is_open()){
        cout<<"No puede abrirse el archivo productos2.csv"<<endl;
        exit(1);
    }
    void **lproductos;
    void *registro;
    lproductos=nullptr;
    int numProductos=0;
    int capProductos=0;
    while(true){
        registro=leeProducto(arch);
        if(arch.eof())break;
        if(numProductos==capProductos){
            agregarEspacioProducto(lproductos,numProductos,capProductos);
        }
       
        lproductos[numProductos-1]=registro;
        lproductos[numProductos]=nullptr;
        numProductos++;
    }
    productos=lproductos;
}
void *leeProducto(ifstream &arch){
    int cod;
    arch>>cod;
    if(arch.eof())return nullptr;
    int *codigo=new int;
    *codigo=cod;
    char *descripcion,aux[300],c;
    arch.get();
    arch.getline(aux,300,',');
    descripcion=new char [strlen(aux)+1];
    strcpy(descripcion,aux);
    double *precio=new double;
    int *cantidad=new int;
    arch>>*precio>>c>>*cantidad;
    void **registro=new void *[4];
    registro[0]=codigo;
    registro[1]=descripcion;
    registro[2]=precio;
    registro[3]=cantidad;
    return registro;
}
void agregarEspacioProducto(void **&lproductos,int &numProductos,
        int &capProductos){
    void **lprodaux;
    capProductos+=INCREMENTO;
    if(lproductos==nullptr){
        lproductos=new void *[capProductos];
        lproductos[0]=nullptr;
        numProductos=1;
    }
    else{
        lprodaux=new void *[capProductos];
        for(int i=0;i<numProductos;i++){
            lprodaux[i]=lproductos[i];
        }
        delete lproductos;
        lproductos=lprodaux;
    }
}
void cargapedidos(void *&pedidos){
    ifstream arch("pedidos2.csv",ios::in);
    if(not arch.is_open()){
        cout<<"No puede abrirse el archivo pedidos2.csv"<<endl;
        exit(1);
    }    
    void **lpedidos;
    void *registro;
    lpedidos=nullptr;
    int numPedidos=0;
    int capPedidos=0;
    while(true){
        registro=leePedido(arch);
        if(arch.eof())break;
        if(numPedidos==capPedidos){
            agregarEspacioPedido(lpedidos,numPedidos,capPedidos);
        }
        insertarOrdenado(lpedidos,numPedidos-1,registro);
        lpedidos[numPedidos]=nullptr;
//        lpedidos[numPedidos-1]=registro;
//        lpedidos[numPedidos]=nullptr;
        numPedidos++;
    }
    pedidos=lpedidos;    
}
void *leePedido(ifstream &arch){
    int cod,dd,mm,aa;
    arch>>cod;
    if(arch.eof())return nullptr;
    int *codigo=new int;
    *codigo=cod;
    char *nombre,aux[200],c,est='N';
    arch.get();
    arch.getline(aux,200,',');
    nombre=new char [strlen(aux)+1];
    strcpy(nombre,aux);  
    int *cantidad=new int;
    int *dni=new int;
    int *fecha=new int;
    arch>>*cantidad>>c>>*dni>>c;
    arch>>dd>>c>>mm>>c>>aa;
    *fecha=dd+mm*100+aa*10000;
    char *estado=new char;
    *estado=est;
    void **registro=new void *[6];
    registro[0]=codigo;
    registro[1]=nombre;
    registro[2]=cantidad;
    registro[3]=dni;
    registro[4]=fecha;
    registro[5]=estado;
    return registro;
}
void agregarEspacioPedido(void **&lpedidos,int &numPedidos,
        int &capPedidos){
    void **lpedaux;
    capPedidos+=INCREMENTO;
    if(lpedidos==nullptr){
        lpedidos=new void *[capPedidos];
        lpedidos[0]=nullptr;
        numPedidos=1;
    }
    else{
        lpedaux=new void *[capPedidos];
        for(int i=0;i<numPedidos;i++){
            
            lpedaux[i]=lpedidos[i];
        }
        delete lpedidos;
        lpedidos=lpedaux;
    }    
}
void insertarOrdenado(void **lpedidos,int numPedidos,void *registro){
    int i,j;
    void **reg=(void **)registro;
    int *codigo=(int *)reg[0];
    int *fecha=(int *)reg[4];
    cout<<*codigo<<endl;
    cout<<*fecha<<endl;
    for(i=0;i<numPedidos;i++){
        if(comparar(lpedidos[i],registro)>0)break;
    }
    for(j=numPedidos;j>=i;j--){
        lpedidos[j+1]=lpedidos[j];
    }
    lpedidos[i]=registro;
//    lpedidos[numPedidos-1]=registro;
//    lpedidos[numPedidos]=nullptr;
}
int comparar(void *lpedidos,void *registro){
    void **registro1=(void **)lpedidos;
    void **registro2=(void **)registro;
    int *fecha1=(int *)registro1[4];
    int *fecha2=(int *)registro2[4];
    return *fecha1-*fecha2;
}
void procesaclientes(void *&productos,void *&pedidos,void *&clientes){
    actualizaPedidos(productos,pedidos);
    llenaclientes(pedidos,clientes);
}
void actualizaPedidos(void *&productos,void *&pedidos){
    void **arrpedidos=(void **)pedidos;
    for(int i=0;arrpedidos[i]!=nullptr;i++){
        actualizaPedido(arrpedidos[i],productos);
    }
}
void actualizaPedido(void *&pedido,void *&productos){
    void **arrproductos=(void **)productos;
    void **registro=(void **)pedido;
    int *codigo=(int *)registro[0];
    char *estado=(char *)registro[5];
    char atendido='A';
    int *cantidad=(int *)registro[2];
    int posProd=buscarProducto(*codigo,productos);
    if(posProd!=-1){
        void **producto=(void **)arrproductos[posProd];
        int *stock=(int *)producto[3];
        cout<<*stock<<endl;
        if(*cantidad<=*stock){
            (*stock)-=(*cantidad);
            *estado=atendido;
        }
    }
}
int buscarProducto(int codigo,void *productos){
    void **arrproductos=(void **)productos;
    for(int i=0;arrproductos[i]!=nullptr;i++){
        void **producto=(void **)arrproductos[i];
        int *codigoprod=(int *)producto[0];
        if(codigo==*codigoprod){
            return i;
        }
    }
    return -1;
}
void llenaclientes(void *pedidos,void *&clientes){
    ifstream arch("clientes2.csv",ios::in);
    if(not arch.is_open()){
        cout<<"No puede abrirse el archivo pedidos2.csv"<<endl;
        exit(1);
    }
    int numClientes=0;
    int capClientes=0;
    void **lclientes=nullptr;
    void *registro;
    while(true){
        registro=leeCliente(arch,pedidos);
        if(arch.eof())break;
        if(numClientes==capClientes){
            agregarEspaciosCliente(lclientes,numClientes,capClientes);
        }
        lclientes[numClientes-1]=registro;
        lclientes[numClientes]=nullptr;
        numClientes++;
    }
    clientes=lclientes;
}
void *leeCliente(ifstream &arch,void *pedidos){
    int dni;
    arch>>dni;
    if(arch.eof())return nullptr;
    int *DNI=new int;
    *DNI=dni;
    arch.get();
    char *nombre,aux[200];
    arch.getline(aux,200,'\n');
    nombre=new char [strlen(aux)+1];
    strcpy(nombre,aux); 
    void **registro=new void *[3];
    registro[0]=DNI;
    registro[1]=nombre;
    registro[2]=llenarPedidos(*DNI,pedidos);
    return registro;
}
void* llenarPedidos(int DNI,void *pedidos){
    void **lpedidos;
    lpedidos=nullptr;
    int numPedidos=0;
    int capPedidos=0;
    void *registro;
    void **arrpedidos=(void **)pedidos;
    for(int i=0;arrpedidos[i]!=nullptr;i++){
        void **pedido=(void **)arrpedidos[i];
        int *dnipedido=(int *)pedido[3];
        char *estado=(char *)pedido[5];
        if(*dnipedido==DNI && *estado=='A'){
            registro=llenaPedido(arrpedidos[i]);
            if(numPedidos==capPedidos){
                agregarEspacioClientePedidos(lpedidos,
                        numPedidos,capPedidos);
            }
            lpedidos[numPedidos-1]=registro;
            lpedidos[numPedidos]=nullptr;
            numPedidos++;
        }
    }
    if(numPedidos==0){
        lpedidos=new void *[1];
        lpedidos[0]=nullptr;
        return lpedidos;
    }
    else{
        return lpedidos;
    }
    
}
void *llenaPedido(void *pedidos){
    void **pedido=(void **)pedidos;
    int *fechapedido=new int;
    int *codpedido=new int;
    char *nombrepedido;
    int *cantpedido=new int;
    int *fecha=(int *)pedido[4];
    int *cantidad=(int *)pedido[2];
    char *nombre=(char *)pedido[1];
    int *codigo=(int *)pedido[0];
    cout<<*cantidad<<endl;
    nombrepedido=new char [strlen(nombre)+1];
    strcpy(nombrepedido,nombre);
    *fechapedido=*fecha;
    *codpedido=*codigo;
    *cantpedido=*cantidad;
    void **registro=new void *[4];
    registro[0]=fechapedido;
    registro[1]=codpedido;
    registro[2]=nombrepedido;
    registro[3]=cantpedido;
    return registro;
}
void agregarEspacioClientePedidos(void **&lpedidos,
                        int &numPedidos,int &capPedidos){
    void **lpedaux;
    capPedidos+=INCREMENTO;
    if(lpedidos==nullptr){
        lpedidos=new void *[capPedidos];
        lpedidos[0]=nullptr;
        numPedidos=1;
    }
    else{
        lpedaux=new void *[capPedidos];
        for(int i=0;i<numPedidos;i++){
            
            lpedaux[i]=lpedidos[i];
        }
        delete lpedidos;
        lpedidos=lpedaux;
    }        
}
void agregarEspaciosCliente(void **&lclientes,int &numClientes,int &capClientes){
    void **lcliaux;
    capClientes+=INCREMENTO;
    if(lclientes==nullptr){
        lclientes=new void *[capClientes];
        lclientes[0]=nullptr;
        numClientes=1;
    }
    else{
        lcliaux=new void *[capClientes];
        for(int i=0;i<numClientes;i++){
            
            lcliaux[i]=lclientes[i];
        }
        delete lclientes;
        lclientes=lcliaux;
    }       
}

void imprimereporte(void *clientes){
    
}
