/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   PunterosGenericos.h
 * Author: gtorr
 *
 * Created on October 5, 2023, 9:18 AM
 */
#include <cstdlib>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#ifndef PUNTEROSGENERICOS_H
#define PUNTEROSGENERICOS_H

void cargaproductos(void *&productos);
void *leeProducto(ifstream &arch);
void agregarEspacioProducto(void **&lproductos,int &numProductos,
        int &capProductos);
void cargapedidos(void *&pedidos);
void *leePedido(ifstream &arch);
void agregarEspacioPedido(void **&lpedidos,int &numPedidos,
        int &capPedidos);
void insertarOrdenado(void **lpedidos,int numPedidos,void *registro);
int comparar(void *lpedidos,void *registro);
void procesaclientes(void *&productos,void *&pedidos,void *&clientes);
void actualizaPedidos(void *&productos,void *&pedidos);
void actualizaPedido(void *&pedido,void *&productos);
int buscarProducto(int codigo,void *productos);
void llenaclientes(void *pedidos,void *&clientes);
void *leeCliente(ifstream &arch,void *pedidos);
void* llenarPedidos(int DNI,void *pedidos);
void *llenaPedido(void *pedidos);
void agregarEspacioClientePedidos(void **&lpedidos,
                        int &numPedidos,int &capPedidos);
void agregarEspaciosCliente(void **&lclientes,int &numClientes,int &capClientes);
void imprimereporte(void *clientes);

#endif /* PUNTEROSGENERICOS_H */

