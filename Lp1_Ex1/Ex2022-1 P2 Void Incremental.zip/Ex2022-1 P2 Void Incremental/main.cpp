/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: gtorr
 *
 * Created on October 5, 2023, 8:53 AM
 */

#include <cstdlib>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "MuestraPunteros.h"
#include "PunterosGenericos.h"
/*
 * 
 */
int main(int argc, char** argv) {
    void *productos,*pedidos,*clientes;
    cargaproductos(productos);
    imprimeproductos(productos);
    cargapedidos(pedidos);
    imprimepedidos(pedidos);
    procesaclientes(productos,pedidos,clientes);
    imprimepedidos(pedidos);
    imprimerepfinal(clientes);
    imprimereporte(clientes);

    return 0;
}

