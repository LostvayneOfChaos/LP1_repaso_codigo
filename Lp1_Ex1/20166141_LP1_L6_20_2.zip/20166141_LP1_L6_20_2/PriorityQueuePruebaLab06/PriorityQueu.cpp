/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
#include "PriorityQueu.h"

using namespace std;


void generarCola(void * &cola){
    void**dupla=new void*[2];
    dupla[0]=nullptr;
    dupla[1]=nullptr;
    
    cola=dupla;
}


void* leerRegistro(ifstream &inNumeros){
    
    int*dato1,*dato2;
    
    dato1=new int;
    dato2=new int;
    
    
    inNumeros>>*dato1;
    if(inNumeros.eof()) return nullptr;
    inNumeros>>*dato2;
    
    inNumeros.get();
    
    void**registro;
    
    registro=new void*[2];
    registro[0]=dato1;
    registro[1]=dato2;
    
    return registro;
    
}

int colaVacia(void * &cola){
    void**dupla=(void**)cola;
    if(dupla[0]==nullptr) return 1;
    return 0;
}




void encolarPrioridad(void* dato,void* &cola){
    
    void **dupla=(void**)cola;
    void**nuevo,**ultimo,**auxUltimo,**aux;
    void**auxDato,**anterior;
    int * datoUltimo1,*datoUltimo2,*datoActual1,*datoActual2;
    nuevo=new void*[3];
    nuevo[0]=dato;
    nuevo[1]=nullptr;
    nuevo[2]=nullptr;
    
    anterior=nullptr;
    
    if (colaVacia(cola)) {
        dupla[0]= nuevo;
        dupla[1]= nuevo;
    } else {
        void**inicio=(void**)dupla[0];
        auxDato=(void**)dato;
        datoActual1=(int*)auxDato[0];
        datoActual2=(int*)auxDato[1];
        void**registro;
        registro=nullptr;
        while (inicio) {
            registro=(void**)inicio[0];
            if((((*(int*)(registro[0]))<(*datoActual1)))
                ||(((*(int*)(registro[0]))==(*datoActual1))&&((*(int*)(registro[1]))<(*datoActual2))))
                break;
            anterior=inicio;
            inicio=(void**)inicio[2];    
        }
        if(anterior==dupla[1]){
            dupla[1]=nuevo;
        }
        /*ultimo=(void**)dupla[1];
            auxUltimo=(void**)ultimo[0];
            datoUltimo1=(int*)auxUltimo[0];
            datoUltimo2=(int*)auxUltimo[1];*/
        nuevo[2]=inicio;
        nuevo[1]=anterior;
        if(anterior==nullptr){
            dupla[0]=nuevo;
        } 
        else anterior[2]=nuevo;
        
        
    }

    
    
    
    
    
    
}

    
    






void crearColaPrioridad(void *& cola){
    
    ifstream inNumeros("Datos.txt",ios::in);
    if (!inNumeros) {
        cout<<"error al abrir el archivo";
        exit(1);
    }
    void*dato;
    
    generarCola(cola);
    while (1) {
        dato=leerRegistro(inNumeros);
        if(dato==nullptr) break;
        
        encolarPrioridad(dato,cola);
        
    }

    
    
    
    
    
    
    inNumeros.close();
}

void* desencolar(void*& cola){
    
    void**dupla=(void**)cola;
    void**ini=(void**)dupla[0];
    void*aux;
    
    
    if (colaVacia(cola)) {
        delete dupla;
        return nullptr;
        
    } else {
        if(dupla[1]==dupla[0])
            dupla[1]=nullptr;
        ini=(void**)dupla[0];
        aux=ini[0];
        dupla[0]=ini[2];
        delete ini;
    }
    return aux;
    
    
}
void imprimirColaPrioridad(void* &cola){
    void**totalCola=(void**)cola;
    void**inicio=(void**)totalCola[0];
    void*dato,**auxDato;
    int*dato1,*dato2;
    while (inicio) {
        dato=desencolar(cola);
        inicio=(void**)inicio[2];
        auxDato=(void**)dato;
        dato1=(int*)auxDato[0];
        dato2=(int*)auxDato[1];
        
        cout<<*dato1<<" "<<*dato2<<endl;
        
    }

    
    
}
