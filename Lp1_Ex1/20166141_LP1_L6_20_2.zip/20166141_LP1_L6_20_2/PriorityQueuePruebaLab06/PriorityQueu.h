/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   PriorityQueu.h
 * Author: AXEL
 *
 * Created on 9 de octubre de 2023, 12:31 PM
 */
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>

using namespace std;

#ifndef PRIORITYQUEU_H
#define PRIORITYQUEU_H
void crearColaPrioridad(void *& cola);
void imprimirColaPrioridad(void* &cola);

#endif /* PRIORITYQUEU_H */

