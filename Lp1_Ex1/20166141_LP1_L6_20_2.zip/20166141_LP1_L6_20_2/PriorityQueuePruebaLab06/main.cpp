/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: AXEL
 *
 * Created on 9 de octubre de 2023, 12:19 PM
 */

#include <cstdlib>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
#include "PriorityQueu.h"

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    
    void*cola;
    
    crearColaPrioridad(cola);
    imprimirColaPrioridad(cola);
    
    return 0;
}

