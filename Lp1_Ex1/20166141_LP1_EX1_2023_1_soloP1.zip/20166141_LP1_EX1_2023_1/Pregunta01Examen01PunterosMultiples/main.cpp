/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: AXEL mendoza 20166141
 *
 * Created on 9 de octubre de 2023, 04:42 PM
 */

#include <cstdlib>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>
#include "Preg1_Funciones_de_cursos_y_alumnos.h"
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    
    char ***cursos, ***alumnos_nom_mod;
    double *cursos_cred, escalas[5];
    int *alumnos_cod, **alumnos;
    
    cargarCursosYEscalas(cursos, cursos_cred, escalas,"Cursos.csv", "Escalas.csv");
    pruebaDeCargaDeCursos(cursos, cursos_cred, "PruebaCursos.txt");
    cargarAlumnos(alumnos_cod, alumnos, alumnos_nom_mod, "Alumnos.csv");
    pruebaDeCargaDeAlumnos(alumnos_cod,alumnos, alumnos_nom_mod, "PruebaAlumnos.txt");

    return 0;
}

