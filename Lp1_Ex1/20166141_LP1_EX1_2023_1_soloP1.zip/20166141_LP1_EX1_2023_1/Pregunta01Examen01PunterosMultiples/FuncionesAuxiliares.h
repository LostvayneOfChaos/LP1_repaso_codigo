/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   FuncionesAuxiliares.h
 * Author: cueva
 *
 * Created on 11 de mayo de 2023, 09:52 PM
 */

#ifndef FUNCIONESAUXILIARES_H
#define FUNCIONESAUXILIARES_H
    void ImprimeAlumno(void *);
    
#endif /* FUNCIONESAUXILIARES_H */
