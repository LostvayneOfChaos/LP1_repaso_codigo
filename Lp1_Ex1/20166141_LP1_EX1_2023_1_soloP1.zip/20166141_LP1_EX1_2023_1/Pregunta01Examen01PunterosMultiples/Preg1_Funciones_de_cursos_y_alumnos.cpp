/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include <cstdlib>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>
#include <cmath>
#include "Preg1_Funciones_de_cursos_y_alumnos.h"
using namespace std;
#define INCREMENTO 5

char* leerCadena(ifstream &inCursos,
        char parametro){
    
    char buffer[100];
    char* nombre;
    inCursos.getline(buffer,100,parametro);
    nombre=new char[strlen(buffer)+1];
    strcpy(nombre,buffer);
    return nombre;
    
}


void incrementarCurso(char***&cursos,
        double* &cursos_cred,
        int &nDatos,int &cap){
    
    cap+=INCREMENTO;
    char***auxCursos;
    double* auxCursosCred;
    if(cursos==nullptr){
        
        cursos=new char**[cap]{};
        cursos_cred=new double[cap]{};
        nDatos=1;
    }
    else{
        auxCursos=new char**[cap]{};
        auxCursosCred=new double[cap]{};
        for (int i = 0; i < nDatos; i++) {
            auxCursos[i]=cursos[i];
            auxCursosCred[i]=cursos_cred[i];
            
        }
        delete cursos;
        delete cursos_cred;
        
        cursos=auxCursos;
        cursos_cred=auxCursosCred;
    }
    
}




void cargarCursos(char***&cursos, 
        double*& cursos_cred,
        double escalas[],
        const char* nombreCursos,
        const char* nombreEscalas){
    
    //incrementos 5
    char aux,*codigo,*nombreCurso,*nombreProfesor;
    double creditos;
    int codigoProfesor,nDatos=0,cap=0;;
    cursos=nullptr;
    ifstream inCursos(nombreCursos,ios::in);
    if (!inCursos) {
        cout<<"error al abrir el archivo";
        exit(1);
    }
    char** registro;
    while(1){
        codigo=leerCadena(inCursos,',');
        if (inCursos.eof()) break;
        nombreCurso=leerCadena(inCursos,',');
        inCursos>>creditos>>aux>>codigoProfesor>>aux;
        nombreProfesor=leerCadena(inCursos,'\n');
        
        if(nDatos==cap){
            incrementarCurso(cursos,cursos_cred,nDatos,cap);
        } 
        
        registro=new char*[3];
        registro[0]=codigo;
        registro[1]=nombreCurso;
        registro[2]=nombreProfesor;
        
        cursos[nDatos-1]=registro;
        cursos_cred[nDatos-1]=creditos;
        
        nDatos++;
    }
    
    inCursos.close();
}

void cargarEscalas(double* escalas,
        const char* nombreEscalas){
    
    ifstream inEscalas(nombreEscalas,ios::in);
    if (!inEscalas) {
        cout<<"error al abrir el archivo";
        exit(1);
    }
    
    double escala;
    char* codigo;
    while (1) {
        codigo=leerCadena(inEscalas,',');
        if(inEscalas.eof()) break;
        inEscalas>>escala;
        inEscalas.get();
        
        if(codigo[1]=='1')
            escalas[0]=escala;
        else if (codigo[1]=='2') {
            escalas[1]=escala;
        }
        else if (codigo[1]=='3') {
            escalas[2]=escala;
        }
        else if (codigo[1]=='4') {
            escalas[3]=escala;
        }    
        else if (codigo[1]=='5') {
            escalas[4]=escala;
        }
        
        
        
    }

    
    
    
    
    
    
    inEscalas.close();
}



void cargarCursosYEscalas(char***&cursos, 
        double* &cursos_cred,
        double * escalas,
        const char* nombreCursos,
        const char* nombreEscalas){
    
    
    cargarCursos(cursos,cursos_cred,escalas, nombreCursos,
            nombreEscalas);
    cargarEscalas(escalas,nombreEscalas);
    
    
    
}


void pruebaDeCargaDeCursos(char***&cursos, 
        double* &cursos_cred, 
        const char* nombreArch){
    
    ofstream outCursos(nombreArch,ios::out);
    if (!outCursos) {
        cout<<"error al abrir el archivo";
        exit(1);
    }
    char**registro;
    outCursos<<"Reporte de prueba de cursos"<<endl;
    for (int i = 0; cursos[i]; i++) {
        registro=cursos[i];
        
        outCursos<<left<<setw(10)<<registro[0]<<setw(50)<<right<<registro[1]<<setw(50)
                <<registro[2]<<setw(10)<<cursos_cred[i]<<endl;
    
    }
    outCursos<<left;
    outCursos.close();
}

void leerDatos(char* &nombre,char &modalidad,
        char *&escala,
                int &porcentaje,
        ifstream &inAlumnos){
    char aux;
    char*prueba;
    nombre=leerCadena(inAlumnos,',');
    modalidad=inAlumnos.get();
    if (modalidad=='G') {
        
        escala=new char[3];
        escala[0]='G';
        escala[1]=inAlumnos.get();;
        escala[3]=0;
        porcentaje=0;
        modalidad='P';
        
        
    }
    else{
        //no es presencial
        inAlumnos.get();
            //modalidad virtual o semipresencial
            if (modalidad=='S') {
                inAlumnos>>porcentaje>>aux;
                escala=leerCadena(inAlumnos,'\n');
            } else {
                escala=leerCadena(inAlumnos,'\n');
                porcentaje=0;
            }
        
    }

        
    
}
void incrementarAlumnos(int *&alumnos_cod,
        int **&alumnos,
        char*** &alumnos_nom_mod,
        int &nDatos,int &cap){
    
    int *auxCod,**auxAlum;
    char*** auxAlNom;
    cap+=INCREMENTO;
    
    if (alumnos_cod==nullptr) {
        alumnos_cod=new int[cap]{};
        alumnos=new int*[cap]{};
        alumnos_nom_mod=new char**[cap]{};
        nDatos=1;
    } 
    else {
        auxCod=new int[cap]{};
        auxAlum=new int*[cap]{};
        auxAlNom=new char**[cap]{};
        
        for (int i = 0; i < nDatos; i++) {
            auxCod[i]=alumnos_cod[i];
            auxAlum[i]=alumnos[i];
            auxAlNom[i]=alumnos_nom_mod[i];
        }
        delete alumnos;
        delete alumnos_cod;
        delete alumnos_nom_mod;
        
        alumnos=auxAlum;
        alumnos_cod=auxCod;
        alumnos_nom_mod=auxAlNom;
        
    }

    
    
    
}


int retornarEscala(char* escala){
    
    if(escala[1]=='1')
        return 1;
        else if (escala[1]=='2') {
            return 2;
        }
        else if (escala[1]=='3') {
            return 3;
        }
        else if (escala[1]=='4') {
            return 4;
        }    
        else if (escala[1]=='5') {
            return 5;
        }
    
    
    
    
    
}

void cargarAlumnos(int *&alumnos_cod,
        int **&alumnos,
        char*** &alumnos_nom_mod,
        const char* nombreArchAl){
    
    /*Código, Nombre, 
     * Modalidad (Virtual [V], 
     * Semi presencial [S] +porcentaje o
     *  presencial [vacío],
     *  Escala*/
    
    alumnos_cod=nullptr;
    alumnos=nullptr;
    alumnos_nom_mod=nullptr;
    int nDatos=0,cap=0,codigoAlumno,porcentaje=0;
    char*nombre,modalidad,*finModalidad,*escala,aux;
    ifstream inAlumnos(nombreArchAl,ios::in);
    if (!inAlumnos) {
        cout<<"error al abrir el archivo";
        exit(1);
    }
    
    while (1) {
        
        inAlumnos>>codigoAlumno>>aux;
        if (inAlumnos.eof()) break;
        leerDatos(nombre,modalidad,escala,
                porcentaje,inAlumnos);
        if (nDatos==cap) incrementarAlumnos(alumnos_cod,
                alumnos,alumnos_nom_mod,nDatos,cap);
        
        alumnos_cod[nDatos-1]=codigoAlumno;
        int*registro;
        registro=new int[3]{};
        registro[0]=codigoAlumno;
        registro[1]=retornarEscala(escala);
        registro[2]=porcentaje;
        alumnos[nDatos-1]=registro;
        char**registroChar;
        registroChar=new char*[2];
        registroChar[0]=nombre;
        finModalidad=new char[2];
        finModalidad[0]=modalidad;
        finModalidad[1]=0;
        registroChar[1]=finModalidad;
        alumnos_nom_mod[nDatos-1]=registroChar;
        
        nDatos++;
    }

    
    inAlumnos.close();
}



void pruebaDeCargaDeAlumnos(int *&alumnos_cod,
        int **&alumnos,
        char*** &alumnos_nom_mod,
        const char* nombreArchAl){
    
    ofstream outAlumnos(nombreArchAl,ios::out);
    if (!outAlumnos) {
        cout<<"error al abrir el archivo";
        exit(1);
    }
    int registro;
    char**registroNom;
    int*registroAl;
    outAlumnos<<"Reporte de prueba de alumnos"<<endl;
    for (int i = 0; alumnos_cod[i]; i++) {
        registro=alumnos_cod[i];
        registroAl=alumnos[i];
        registroNom=alumnos_nom_mod[i];
        outAlumnos<<left<<setw(10)<<registro<<
                setw(50)<<right<<registroNom[0]<<
                setw(4)
                <<registroNom[1]<<
                setw(10)<<registroAl[1]<<
                setw(10)<<registroAl[2]<<endl;
    
    }
    outAlumnos<<left;
    outAlumnos.close();
    
    
    
}