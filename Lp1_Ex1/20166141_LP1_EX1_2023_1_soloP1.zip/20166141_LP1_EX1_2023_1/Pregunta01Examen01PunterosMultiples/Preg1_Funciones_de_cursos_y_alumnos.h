/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Preg1_Funciones_de_cursos_y_alumnos.h
 * Author: AXEL
 *
 * Created on 9 de octubre de 2023, 04:46 PM
 */
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>
using namespace std;

#ifndef PREG1_FUNCIONES_DE_CURSOS_Y_ALUMNOS_H
#define PREG1_FUNCIONES_DE_CURSOS_Y_ALUMNOS_H

void cargarCursosYEscalas(char***&cursos, 
        double* &cursos_cred,
        double * escalas,
        const char* nombreCursos,
        const char* nombreEscalas);
void pruebaDeCargaDeCursos(char***&cursos, 
        double* &cursos_cred, 
        const char* nombreArch);
void cargarAlumnos(int *&alumnos_cod,
        int **&alumnos,
        char*** &alumnos_nom_mod,
        const char* nombreArchAl);
void pruebaDeCargaDeAlumnos(int *&alumnos_cod,
        int **&alumnos,
        char*** &alumnos_nom_mod,
        const char* nombreArchAl);
#endif /* PREG1_FUNCIONES_DE_CURSOS_Y_ALUMNOS_H */

