/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   FuncionesExamen01Pregunta01.h
 * Author: AXEL
 *
 * Created on 6 de octubre de 2023, 09:39 AM
 */

#ifndef FUNCIONESEXAMEN01PREGUNTA01_H
#define FUNCIONESEXAMEN01PREGUNTA01_H



#endif /* FUNCIONESEXAMEN01PREGUNTA01_H */

