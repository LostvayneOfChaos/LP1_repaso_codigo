/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: AXEL
 *
 * Created on 6 de octubre de 2023, 12:09 AM
 */

#include <iostream>
#include <fstream>
#include <cstring>
#include <cstdlib>
#include "ClientesPreg1.h"
#include "FuncionesExamen01Pregunta01.h"


using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    
    char**cli_NombreCategoria,**pro_Descripcion;
    int ***cli_Dni_TelPed,**pro_informacion,**ped_Todo;
    
    CargaDeClientes(cli_Dni_TelPed,cli_NombreCategoria,"ClientesPreg01.csv");
    PruebaDeClientes(cli_Dni_TelPed,cli_NombreCategoria,"PruebaClientes01.txt");
    
    
    CargarProductosPedidos(pro_informacion,pro_Descripcion,ped_Todo,"PedidosPreg01.csv");
    PruebaProductosPedidos(pro_informacion,pro_Descripcion,ped_Todo,"PruebaProductosPedidos01.txt");
    
    ordenarPedidos(ped_Todo);
    PruebaProductosPedidos(pro_informacion,pro_Descripcion,
            ped_Todo,"PruebaProductosPedidos02.txt");
            
    
    asignarPedidos(cli_Dni_TelPed,pro_informacion,ped_Todo);
    PruebaProductosPedidos(pro_informacion,pro_Descripcion,
            ped_Todo,"PruebaProductosPedidos03.txt");
    
    PruebaDeClientes(cli_Dni_TelPed,cli_NombreCategoria,"PruebaClientes02.txt");
    
    
    return 0;
}

