/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include <iostream>
#include <fstream>
#include <cstring>
#include <cstdlib>
#include "ClientesPreg1.h"
#include "FuncionesExamen01Pregunta01.h"


using namespace std;

void CargarProductosPedidos(int** &pro_informacion,
        pro_Descripcion,ped_Todo,
        const char* nombreArch){
    
    
    
    
    
}