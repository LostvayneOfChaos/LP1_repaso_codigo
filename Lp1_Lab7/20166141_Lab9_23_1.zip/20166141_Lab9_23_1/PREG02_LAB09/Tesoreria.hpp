/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Tesoreria.hpp
 * Author: AXEL
 *
 * Created on 2 de noviembre de 2023, 02:08 PM
 */
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>
using namespace std;
#ifndef TESORERIA_HPP
#define TESORERIA_HPP
#include "Boleta.hpp"
#include "Escala.hpp"

class Tesoreria {
public:
    Tesoreria();
    Tesoreria(const Tesoreria& orig);
    virtual ~Tesoreria();
    void cargaescalas();
    void cargaalumnos();
    void imprimeboleta();
    void actualizar();
    
private:
    class Boleta lboleta[100];
    class Escala lescala[100];
    
};

#endif /* TESORERIA_HPP */

