/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Alumno.hpp
 * Author: AXEL
 *
 * Created on 2 de noviembre de 2023, 02:07 PM
 */
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>
using namespace std;
#ifndef ALUMNO_HPP
#define ALUMNO_HPP

class Alumno {
public:
    Alumno();
    Alumno(const Alumno& orig);
    virtual ~Alumno();
    virtual void actualizarAlumno(class Escala * escala)=0;
    virtual void leerAlumno(ifstream &);
    virtual void imprimirAlumno(ofstream &);
    void setTotal(double total);
    double getTotal() const;
    void setCreditos(double creditos);
    double getCreditos() const;
    void setEscala(int escala);
    int getEscala() const;
    void setNombre(char* nombre);
    void getNombre(char* ) const;
    void setCodigo(int codigo);
    int getCodigo() const;
private:
    int codigo;
    char *nombre;
    int escala;
    double creditos;
    double total;
    
    
    
};

#endif /* ALUMNO_HPP */

