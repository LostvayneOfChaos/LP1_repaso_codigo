/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Presencial.hpp
 * Author: AXEL
 *
 * Created on 2 de noviembre de 2023, 02:07 PM
 */
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>
using namespace std;
#ifndef PRESENCIAL_HPP
#define PRESENCIAL_HPP
#include "Alumno.hpp"
class Presencial:public Alumno {
public:
    Presencial();
    Presencial(const Presencial& orig);
    virtual ~Presencial();
    void SetTotal(double total);
    double GetTotal() const;
    void SetRecargo(double recargo);
    double GetRecargo() const;
    void leerAlumno(ifstream &);
    void imprimirAlumno(ofstream &);
    void actualizarAlumno(class Escala * escala);
private:
    double recargo;
    double total;
    
    
};

#endif /* PRESENCIAL_HPP */

