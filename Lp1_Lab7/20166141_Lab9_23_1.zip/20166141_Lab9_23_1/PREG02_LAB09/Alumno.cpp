/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Alumno.cpp
 * Author: AXEL
 * 
 * Created on 2 de noviembre de 2023, 02:07 PM
 */

#include "Alumno.hpp"
#include "Escala.hpp"

Alumno::Alumno() {
    nombre=nullptr;
    
}

void Alumno::setTotal(double total) {
    this->total = total;
}

double Alumno::getTotal() const {
    return total;
}

void Alumno::setCreditos(double creditos) {
    this->creditos = creditos;
}

double Alumno::getCreditos() const {
    return creditos;
}

void Alumno::setEscala(int escala) {
    this->escala = escala;
}

int Alumno::getEscala() const {
    return escala;
}

void Alumno::setNombre(char* nombre) {
    if(this->nombre !=nullptr) delete this->nombre;
    this->nombre=new char[strlen(nombre)+1];
    strcpy(this->nombre,nombre);
    
    
}

void Alumno::getNombre(char* cadena) const {
    if(nombre==nullptr) cadena[0]=0;
    strcpy(cadena,nombre);
    
}

void Alumno::setCodigo(int codigo) {
    this->codigo = codigo;
}

int Alumno::getCodigo() const {
    return codigo;
}

Alumno::Alumno(const Alumno& orig) {
}

Alumno::~Alumno() {
}

void Alumno::leerAlumno(ifstream& inAlumnos){
    int codigo,escala;
    char aux,tipo,nombre[100];
    double creditos,descuento;
    
    inAlumnos>>aux>>codigo>>aux;
    inAlumnos.getline(nombre,100,',');
    inAlumnos>>escala>>aux>>creditos>>aux;
    setCodigo(codigo);
    setCreditos(creditos);
    setEscala(escala);
    setTotal(0);
    setNombre(nombre);
}
void Alumno::imprimirAlumno(ofstream& outAlumnos){
    
    outAlumnos<<fixed;
    outAlumnos<<setprecision(2);
    
    outAlumnos<<setw(10)<<codigo;
    outAlumnos<<setw(50)<<nombre;
    outAlumnos<<setw(10)<<escala;
    outAlumnos<<setw(10)<<creditos;
}
/*void Alumno::actualizarAlumno(class Escala * ESCALA){
    int cod;
    double precio=0;
    for (int i = 0; ESCALA[i].GetCodigo()!=0; i++) {
        cod=ESCALA[i].GetCodigo();
        if(cod==escala) precio=ESCALA[i].GetPrecio();
    }
    
    setTotal(precio*creditos);
    
    
    
    
}*/