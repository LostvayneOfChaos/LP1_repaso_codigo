/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Semipresencial.cpp
 * Author: AXEL
 * 
 * Created on 2 de noviembre de 2023, 02:08 PM
 */

#include "Semipresencial.hpp"
#include "Escala.hpp"

Semipresencial::Semipresencial() {
}

Semipresencial::Semipresencial(const Semipresencial& orig) {
}

Semipresencial::~Semipresencial() {
}

void Semipresencial::SetTotal(double total) {
    this->total = total;
}

double Semipresencial::GetTotal() const {
    return total;
}

void Semipresencial::SetDescuento(double descuento) {
    this->descuento = descuento;
}

double Semipresencial::GetDescuento() const {
    return descuento;
}

void Semipresencial::leerAlumno(ifstream & inAlumnos){
    
    Alumno::leerAlumno(inAlumnos);
    double descuento;
    inAlumnos>>descuento;
    inAlumnos.get();
    SetDescuento(descuento);
    
}

void Semipresencial::imprimirAlumno(ofstream &out){
    Alumno::imprimirAlumno(out);
    double total;
    total= Alumno::getTotal();
    out<<setw(30)<<total;
    
}

void Semipresencial::actualizarAlumno(class Escala * ESCALA){
    
    //Alumno::actualizarAlumno(ESCALA);
    int cod,escala;
    double precio=0;
    for (int i = 0; ESCALA[i].GetCodigo()!=0; i++) {
        cod=ESCALA[i].GetCodigo();
        escala=getEscala();
        if(cod==escala) precio=ESCALA[i].GetPrecio();
    }
    double cred=getCreditos();
    Alumno::setTotal(precio*cred);
    double total;
    total=Alumno::getTotal();
    SetTotal(total*(100-descuento)*1.0/100);
    Alumno::setTotal(total*(100-descuento)*1.0/100);
    
}