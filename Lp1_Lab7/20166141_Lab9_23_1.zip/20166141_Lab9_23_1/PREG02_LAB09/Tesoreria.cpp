/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Tesoreria.cpp
 * Author: AXEL
 * 
 * Created on 2 de noviembre de 2023, 02:08 PM
 */

#include "Tesoreria.hpp"
#include "Presencial.hpp"
#include "Semipresencial.hpp"
#include "Virtual.hpp"

Tesoreria::Tesoreria() {
}

Tesoreria::Tesoreria(const Tesoreria& orig) {
}

Tesoreria::~Tesoreria() {
}

void Tesoreria::imprimeboleta(){
    
    ofstream outAlumnos("reporte.txt",ios::out);
    if (!outAlumnos) {
        cout<<"error al abrir el archivo Alumnos";
        exit(1);
        
    }
    outAlumnos<<"CODIGO"<<setw(50)<<"Nombre"<<setw(15)<<"Escala"<<setw(10)<<"Cred."
            <<setw(20)<<"Licencia"<<setw(10)<<"Total"<<endl;
    
    for (int i = 0; not lboleta[i].ultimo(); i++) {
        lboleta[i].imprime(outAlumnos);
        outAlumnos<<endl;
    }
    outAlumnos<<endl;
    
    outAlumnos.close();
    
    
}

void Tesoreria::cargaalumnos(){
    ifstream inAlumnos("alumnos.csv",ios::in);
    if (!inAlumnos) {
        cout<<"error al abrir el archivo Alumnos";
        exit(1);
        
    }
    int codigo,escala;
    char aux,tipo,nombre[100];
    double creditos,descuento;
    int n=0;
    while (1) {
        tipo=inAlumnos.get();
        if(inAlumnos.eof())break;
        
        if (tipo == 'P') {
            lboleta[n].asignaPresencial();
        }
        else if (tipo == 'S') {
            lboleta[n].asignaSemiPresencial();
            
        }
        else if (tipo == 'V') {
            lboleta[n].asignaVirtual();
        }
        
        lboleta[n].lee(inAlumnos);
        
        n++;
    }
    
    inAlumnos.close();
}

void Tesoreria::cargaescalas(){
    ifstream inEscalas("escalas.csv",ios::in);
    if (!inEscalas) {
        cout<<"error al abrir el archivo Escalas";
        exit(1);
        
    }
    int num;
    char aux;
    double costo;
    int n=0;
    while (1) {
        inEscalas>>num;
        if(inEscalas.eof())break;
        inEscalas>>aux>>costo;
        inEscalas.get();
        
        lescala[n].SetCodigo(num);
        lescala[n].SetPrecio(costo);
        
        n++;
    }
    
    lescala[n].SetCodigo(0);
    
    
    
    
    inEscalas.close();
}

void Tesoreria::actualizar(){
    for (int i = 0; not lboleta[i].ultimo(); i++) {
        lboleta[i].actualizaTotal(lescala);
    }
    
}