/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Semipresencial.cpp
 * Author: AXEL
 * 
 * Created on 2 de noviembre de 2023, 02:08 PM
 */

#include "Semipresencial.hpp"

Semipresencial::Semipresencial() {
}

Semipresencial::Semipresencial(const Semipresencial& orig) {
}

Semipresencial::~Semipresencial() {
}

void Semipresencial::SetTotal(double total) {
    this->total = total;
}

double Semipresencial::GetTotal() const {
    return total;
}

void Semipresencial::SetDescuento(double descuento) {
    this->descuento = descuento;
}

double Semipresencial::GetDescuento() const {
    return descuento;
}

void Semipresencial::leerAlumno(ifstream & inAlumnos){
    
    Alumno::leerAlumno(inAlumnos);
    double descuento;
    inAlumnos>>descuento;
    inAlumnos.get();
    SetDescuento(descuento);
    
}

void Semipresencial::imprimirAlumno(ofstream &out){
    Alumno::imprimirAlumno(out);
    double total;
    total= Alumno::getTotal();
    out<<setw(30)<<total;
    
}