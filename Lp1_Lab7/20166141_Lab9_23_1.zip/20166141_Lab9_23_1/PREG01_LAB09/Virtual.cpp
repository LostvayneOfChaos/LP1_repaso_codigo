/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Virtual.cpp
 * Author: AXEL
 * 
 * Created on 2 de noviembre de 2023, 02:08 PM
 */

#include "Virtual.hpp"

Virtual::Virtual() {
    licencia=nullptr;
}

Virtual::Virtual(const Virtual& orig) {
}

Virtual::~Virtual() {
}

void Virtual::SetTotal(double total) {
    this->total = total;
}

double Virtual::GetTotal() const {
    return total;
}

void Virtual::SetLicencia(char* licencia) {
    if(this->licencia !=nullptr) delete this->licencia;
    this->licencia=new char[strlen(licencia)+1];
    strcpy(this->licencia,licencia);
}

void Virtual::GetLicencia(char* cadena) const {
    if(licencia==nullptr) cadena[0]=0;
    strcpy(cadena,licencia);
}

void Virtual::leerAlumno(ifstream & inAlumnos){
    Alumno::leerAlumno(inAlumnos);
    char licencia[50];
    inAlumnos.getline(licencia,50,'\n');
    SetLicencia(licencia);
    
}

void Virtual::imprimirAlumno(ofstream &out){
    
    Alumno::imprimirAlumno(out);
    double total;
    total= Alumno::getTotal();
    out<<setw(20)<<licencia<<setw(10)<<total;
    
}