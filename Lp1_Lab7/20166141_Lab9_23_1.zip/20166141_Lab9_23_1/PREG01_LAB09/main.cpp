/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: AXEL
 *
 * Created on 2 de noviembre de 2023, 02:07 PM
 */

#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>

#include "Tesoreria.hpp"

using namespace std;
/*
 * 
 */
int main(int argc, char** argv) {
    
    Tesoreria OTeso;
    OTeso.cargaescalas();
    OTeso.cargaalumnos();
    //OTeso.actualizaboleta();
    OTeso.imprimeboleta();
    
    
    
    return 0;
}

