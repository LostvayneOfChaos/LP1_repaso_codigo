/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Presencial.cpp
 * Author: AXEL
 * 
 * Created on 2 de noviembre de 2023, 02:07 PM
 */

#include "Presencial.hpp"

Presencial::Presencial() {
}

Presencial::Presencial(const Presencial& orig) {
}

Presencial::~Presencial() {
}

void Presencial::SetTotal(double total) {
    this->total = total;
}

double Presencial::GetTotal() const {
    return total;
}

void Presencial::SetRecargo(double recargo) {
    this->recargo = recargo;
}

double Presencial::GetRecargo() const {
    return recargo;
}

void Presencial::leerAlumno(ifstream &inAlumnos){
    Alumno::leerAlumno(inAlumnos);
    double recarga;
    inAlumnos>>recarga;
    inAlumnos.get();
    SetRecargo(recarga);
    
}

void Presencial::imprimirAlumno(ofstream & out){
    Alumno::imprimirAlumno(out);
    double total;
    total= Alumno::getTotal();
    out<<setw(30)<<total;
}