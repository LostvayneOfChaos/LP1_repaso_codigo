/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Boleta.cpp
 * Author: AXEL
 * 
 * Created on 2 de noviembre de 2023, 02:08 PM
 */

#include "Boleta.hpp"
#include "Presencial.hpp"
#include "Semipresencial.hpp"
#include "Virtual.hpp"

Boleta::Boleta() {
    pboleta=nullptr;
}

Boleta::Boleta(const Boleta& orig) {
}

Boleta::~Boleta() {
}

void Boleta::asignaPresencial(){
    pboleta=new Presencial;
    
}
void Boleta::asignaSemiPresencial(){
    pboleta=new Semipresencial;
}
void Boleta::asignaVirtual(){
    pboleta=new Virtual;
    
}

void Boleta::lee(ifstream & in){
    
    pboleta->leerAlumno(in);
    
}
void Boleta::imprime(ofstream &out) const{
    
    pboleta->imprimirAlumno(out);
}

bool Boleta::ultimo() const{
    return pboleta==nullptr;
}