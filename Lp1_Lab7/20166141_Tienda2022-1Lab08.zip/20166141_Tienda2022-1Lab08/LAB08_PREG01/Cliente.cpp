/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Cliente.cpp
 * Author: AXEL
 * 
 * Created on 31 de octubre de 2023, 05:08 PM
 */

#include "Cliente.hpp"

Cliente::Cliente() {
    nombre=nullptr;
}

Cliente::Cliente(const Cliente& orig) {
}

Cliente::~Cliente() {
}

void Cliente::SetNombre(char* nombre) {
    if(this->nombre !=nullptr) delete this->nombre;
    this->nombre=new char[strlen(nombre)+1];
    strcpy(this->nombre,nombre);
}

void Cliente::GetNombre(char* cadena) const {
    if(nombre!=nullptr) cadena[0]=0;
    strcpy(cadena,nombre);  
}

void Cliente::SetCategoria(char categoria) {
    this->categoria = categoria;
}

char Cliente::GetCategoria() const {
    return categoria;
}

void Cliente::SetDni(int dni) {
    this->dni = dni;
}

int Cliente::GetDni() const {
    return dni;
}

