/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Producto.hpp
 * Author: AXEL
 *
 * Created on 31 de octubre de 2023, 05:09 PM
 */
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>
using namespace std;

#ifndef PRODUCTO_HPP
#define PRODUCTO_HPP

class Producto {
public:
    Producto();
    Producto(const Producto& orig);
    virtual ~Producto();
    void SetStock(int stock);
    int GetStock() const;
    void SetPrecio(double precio);
    double GetPrecio() const;
    void SetNombre(char* nombre);
    void GetNombre(char*) const;
    void SetCodprod(int codprod);
    int GetCodprod() const;
private:
    int codprod;
    char* nombre;
    double precio;
    int stock;
};

#endif /* PRODUCTO_HPP */

