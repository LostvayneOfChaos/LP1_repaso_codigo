/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Tienda.hpp
 * Author: AXEL
 *
 * Created on 31 de octubre de 2023, 05:12 PM
 */
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>
using namespace std;
#ifndef TIENDA_HPP
#define TIENDA_HPP
#include "Pedido.hpp"
#include "Cliente.hpp"
class Tienda {
public:
    Tienda();
    Tienda(const Tienda& orig);
    virtual ~Tienda();
    void carga();
    void muestra() const ;
    void actualiza(int num);
    char buscarCategoria(class Pedido &) const;
    double buscarPrecio(class Pedido & ,int ,ifstream &) const;
private:
    class Pedido lpedidos[200];
    class Cliente lclientes[100];
    
};

#endif /* TIENDA_HPP */

