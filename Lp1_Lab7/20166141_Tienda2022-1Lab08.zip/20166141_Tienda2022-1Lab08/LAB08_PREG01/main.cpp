/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: AXEL
 *
 * Created on 31 de octubre de 2023, 05:06 PM
 */

#include <cstdlib>
#include "Tienda.hpp"
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    Tienda tien;
    ofstream outPedidos("ReportePedidos.txt",ios::out);
    if(!outPedidos){
        cout<<"error al abrir el archivo";
        exit(1);
    }
    
    tien.carga();
    tien.actualiza(20);
    tien.muestra();
    return 0;
}

