/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Pedido.hpp
 * Author: AXEL
 *
 * Created on 31 de octubre de 2023, 05:09 PM
 */
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>
#ifndef PEDIDO_HPP
#define PEDIDO_HPP
#include "Producto.hpp"
using namespace std;

class Pedido:public Producto{
public:
    Pedido();
    Pedido(const Pedido& orig);
    virtual ~Pedido();
    void SetObs(const char* obs);
    void GetObs(char*) const;
    void SetTotal(double total);
    double GetTotal() const;
    void SetFecha(int fecha);
    int GetFecha() const;
    void SetDni(int dni);
    int GetDni() const;
    void SetCantidad(int cantidad);
    int GetCantidad() const;
    void SetCodigo(int codigo);
    int GetCodigo() const;
private:
    int codigo;
    int cantidad;
    int dni;
    int fecha;
    double total;
    char*obs;
    
    
};

#endif /* PEDIDO_HPP */

