/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Tienda.cpp
 * Author: AXEL
 * 
 * Created on 31 de octubre de 2023, 05:12 PM
 */

#include "Tienda.hpp"

Tienda::Tienda() {
    
    
    
}

Tienda::Tienda(const Tienda& orig) {
}

Tienda::~Tienda() {
}

char Tienda::buscarCategoria(class Pedido &PEDIDO) const {
    
    int dni=PEDIDO.GetDni();
    char categoria='D';
    
    for (int i = 0; lclientes[i].GetDni()!=0; i++) {
        if(dni==lclientes[i].GetDni()){
            categoria=lclientes[i].GetCategoria();
            return categoria;
        }
    }
    return categoria;
    
}



void Tienda::actualiza(int num){
    /* descuentos se 
     * aplican solo a los productos que cuentan
     *  con
     * cantidad de stock mayor igual a num,*/
    int cod;
    int stock;
    char categoria;
    double total;
    for (int i = 0; lpedidos[i].GetCodigo()!=0; i++) {
        cod=lpedidos[i].GetCodigo();
        stock=lpedidos[i].GetStock();
        categoria=buscarCategoria(lpedidos[i]);
        if((cod/100000 == 4)&&(stock>= num)){
            if(categoria=='A'){
                total=lpedidos[i].GetPrecio();
                total=total/2*1.0;
                lpedidos[i].SetPrecio(total);
                lpedidos[i].SetObs("   Descuento Especial de 50%");
            }
            else if(categoria=='B'){
                total=lpedidos[i].GetPrecio();
                lpedidos[i].SetPrecio(total*7*1.0/10);
                lpedidos[i].SetObs("   Descuento Especial de 30%");
            }
            else  if(categoria=='C'){
                total=lpedidos[i].GetPrecio();
                lpedidos[i].SetPrecio(total*9.0/10);
                lpedidos[i].SetObs("  Descuento Especial de 10%");
            }
            else lpedidos[i].SetObs("  ");
            
        }
        else lpedidos[i].SetObs(" ");
    }

    
    
    
    
    
    
    
}
void Tienda::muestra() const{
    char nombre[100];
    char desc[100];
    int cod;
    ofstream outPedidos("ReportePedidos.txt",ios::out);
    if(!outPedidos){
        cout<<"error al abrir el archivo";
        exit(1);
    }
    int fecha,dia,mes,anio;
    for (int i = 0; lpedidos[i].GetCodigo()!=0; i++) {
        fecha=lpedidos[i].GetFecha();
        anio=fecha/10000;
        fecha=fecha%10000;
        mes=fecha/100;
        dia=fecha%100;
        outPedidos.fill('0');
        outPedidos<<setw(2)<<dia<<"/"<<setw(2)<<
                mes<<"/"<<setw(2)<<anio;
        outPedidos.fill(' ');
        outPedidos<<setw(10)<<lpedidos[i].GetCodigo();
        lpedidos[i].GetNombre(nombre);
        cod=lpedidos[i].GetCodigo();
        outPedidos<<setw(50)<<nombre;
        outPedidos<<setw(5)<<lpedidos[i].GetCantidad();
        outPedidos<<setw(10)<<lpedidos[i].GetPrecio();
        outPedidos<<setw(10)<<lpedidos[i].GetTotal();
        lpedidos[i].GetObs(desc);
        outPedidos<<setw(10)<<desc<<endl;
        
        
        
        
        
        
    }

    
    
    
    
    outPedidos.close();
    
}
double Tienda::buscarPrecio(class Pedido & PEDIDO, int codPed,ifstream &inProductos) const{
    char aux;
    char nombre[100];
    int cod,stock;
    double precio;
    while(1){
        inProductos>>cod;
        if(inProductos.eof()) break;
        inProductos>>aux;
        inProductos.getline(nombre,100,',');
        inProductos>>precio>>aux>>stock;
        if(cod==codPed) {
            PEDIDO.SetCodprod(cod);
            PEDIDO.SetNombre(nombre);
            PEDIDO.SetPrecio(precio);
            PEDIDO.SetStock(stock);
            
            return precio;
        }
        inProductos.get();
    }
    return -1;
    
}

void Tienda::carga(){
    //pedidos 118050,8,79475585,16/12/2019
    //clientes 71984468,IPARRAGUIRRE VILLEGAS NICOLAS EDILBERTO,A
    //productos 459032,GELATINA DANY LIMON 125GR,5.38,24
    
    ifstream inPedidos("pedidos3.csv",ios::in);
    if(!inPedidos){
        cout<<"error al abrir el archivo";
        exit(1);
    }
    ifstream inProductos("productos3.csv",ios::in);
    if(!inProductos){
        cout<<"error al abrir el archivo";
        exit(1);
    }
    ifstream inClientes("clientes2.csv",ios::in);
    if(!inClientes){
        cout<<"error al abrir el archivo";
        exit(1);
    }
    
    
    class Pedido pedido;
    class Cliente cliente;
    int codPed,dni,cantPedido,fecha,dia,mes,anio;
    double total;
    char aux,categoria,nombre[50];
    int npedidos=0,nClientes=0;
    
    while(1){
        inPedidos>>codPed;
        if(inPedidos.eof()) break;
        inPedidos>>aux>>cantPedido>>aux>>dni>>aux>>dia
                >>aux>>mes>>aux>>anio;
        inPedidos.get();
        
        lpedidos[npedidos].SetCodigo(codPed);
        lpedidos[npedidos].SetCantidad(cantPedido);
        lpedidos[npedidos].SetDni(dni);
        fecha=anio*10000+mes*100+dia;
        lpedidos[npedidos].SetFecha(fecha);
        
        lpedidos[npedidos].SetObs("XXX");
        
        inProductos.seekg(0,inProductos.beg);
        total=buscarPrecio(lpedidos[npedidos], codPed,inProductos);
        if(total!=-1){
            lpedidos[npedidos].SetTotal(total*cantPedido);
        }
        else 
            lpedidos[npedidos].SetTotal(0);
        
        //lpedidos[npedidos]=pedido;
        npedidos++;
    }
    
    lpedidos[npedidos].SetCodigo(0);
     //clientes 71984468,IPARRAGUIRRE 
    //VILLEGAS NICOLAS EDILBERTO,A
    while(1){
        inClientes>>dni;
        if(inClientes.eof()) break;
        inClientes>>aux;
        inClientes.getline(nombre,50,',');
        categoria=inClientes.get();
        inClientes.get();
        
        lclientes[nClientes].SetDni(dni);
        lclientes[nClientes].SetCategoria(categoria);
        lclientes[nClientes].SetNombre(nombre);
        
        //lclientes[nClientes]=cliente;
        nClientes++;
    }
    lclientes[nClientes].SetDni(-1);
    
    
    
    
    inPedidos.close();
    inProductos.close();
    inClientes.close();
}