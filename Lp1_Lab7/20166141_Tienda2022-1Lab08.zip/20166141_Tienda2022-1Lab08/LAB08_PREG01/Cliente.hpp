/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Cliente.hpp
 * Author: AXEL
 *
 * Created on 31 de octubre de 2023, 05:08 PM
 */
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>
using namespace std;
#ifndef CLIENTE_HPP
#define CLIENTE_HPP

class Cliente {
public:
    Cliente();
    Cliente(const Cliente& orig);
    virtual ~Cliente();
    void SetNombre(char* nombre);
    void GetNombre(char*) const;
    void SetCategoria(char categoria);
    char GetCategoria() const;
    void SetDni(int dni);
    int GetDni() const;
private:
    int dni;
    char categoria;
    char* nombre;
};

#endif /* CLIENTE_HPP */

