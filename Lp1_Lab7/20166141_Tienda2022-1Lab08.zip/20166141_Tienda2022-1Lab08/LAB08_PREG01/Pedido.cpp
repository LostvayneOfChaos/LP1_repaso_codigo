/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Pedido.cpp
 * Author: AXEL
 * 
 * Created on 31 de octubre de 2023, 05:09 PM
 */

#include "Pedido.hpp"

Pedido::Pedido() {
    obs=nullptr;
    
}

Pedido::Pedido(const Pedido& orig) {
}

Pedido::~Pedido() {
}

void Pedido::SetObs(const char* obs) {
    if(this->obs !=nullptr) delete this->obs;
    this->obs=new char[strlen(obs)+1];
    strcpy(this->obs,obs);
    
    
}

void Pedido::GetObs(char* cadena) const {
    if(obs!=nullptr) cadena[0]=0;
    strcpy(cadena,obs);    
}

void Pedido::SetTotal(double total) {
    this->total = total;
}

double Pedido::GetTotal() const {
    return total;
}

void Pedido::SetFecha(int fecha) {
    this->fecha = fecha;
}

int Pedido::GetFecha() const {
    return fecha;
}

void Pedido::SetDni(int dni) {
    this->dni = dni;
}

int Pedido::GetDni() const {
    return dni;
}

void Pedido::SetCantidad(int cantidad) {
    this->cantidad = cantidad;
}

int Pedido::GetCantidad() const {
    return cantidad;
}

void Pedido::SetCodigo(int codigo) {
    this->codigo = codigo;
}

int Pedido::GetCodigo() const {
    return codigo;
}

