/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: AXEL
 *
 * Created on 21 de septiembre de 2023, 05:06 PM
 */

#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>

#include "PunterosGenericos.h"
#include "Funciones_de_cursos_y_alumnos.h"
    
using namespace std;
int main(int argc, char** argv) {
    
    void *alumnoveces;
    char **alumnos_nom_mod;
    int *alumnos_cod, **alumnos;
    
    cargarAlumnos (alumnos_cod, alumnos, alumnos_nom _mod, "Alumnos.csv");
    CargaCursos(alumnos_cod,alumnoveces,"HistoriaDeNotas.csv");
    ActualizaVeces(alumnoveces);
    ImprimeAlumno(alumnoveces);
    return 0;
    
}