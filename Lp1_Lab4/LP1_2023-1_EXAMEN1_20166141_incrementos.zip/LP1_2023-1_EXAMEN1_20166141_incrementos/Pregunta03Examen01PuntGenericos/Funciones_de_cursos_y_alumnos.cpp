/* 
 * File:   Funciones_de_cursos_y_alumnos.cpp
 * Author: cueva.r
 * 
 * Created on 5 de septiembre de 2023, 11:37 AM
 */
#include <iostream>
#include <fstream>
#include <cstring>
#include "AperturaDeArchivos.h"
#include "Funciones_de_cursos_y_alumnos.h"
#define INCREMENTO 5

using namespace std;

void leecursos(char ***&cursos,double *&cursos_cred,ifstream &archcursos){
    int capacidad=0,numdat=0;
    char **registro;
    double creditos;
    
    cursos=nullptr;
    while(1){
        registro = leecurso(archcursos,creditos);
        if(archcursos.eof()) break;
        if(numdat==capacidad)
            aumentarmemoria(cursos,cursos_cred,numdat,capacidad);
        cursos[numdat-1] = registro;
        cursos[numdat] = nullptr;
        cursos_cred[numdat-1] = creditos;
        cursos_cred[numdat] = -1;
        numdat++;
    }

}

/*
INF263,Algoritmia,3.75,35030611,INGA FLORES CESAR ADOLFO
MEC270,Procesos De Manufactura,4,83265244,PAIRAZAMAN ALAMO MOISES MIGUEL
 */

char** leecurso(ifstream &archcursos,double &creditos){
   char buffcad[200],c,**curso;  
   char *codcurso,*nomcurso,*nomprof;
   int codprof;
   
   archcursos.getline(buffcad,200,',');
   if(archcursos.eof()) return nullptr;
   codcurso = new char[strlen(buffcad)+1];
   strcpy(codcurso,buffcad);
   archcursos.getline(buffcad,200,',');
   nomcurso = new char[strlen(buffcad)+1];
   strcpy(nomcurso,buffcad);
   archcursos >> creditos >> c >> codprof >> c;
   archcursos.getline(buffcad,200);
   nomprof = new char[strlen(buffcad)+1];
   strcpy(nomprof,buffcad);
   curso = new char*[3];
   curso[0] = codcurso;
   curso[1] = nomcurso;
   curso[2] = nomprof;
   
   return curso;
}

void aumentarmemoria(char ***&cursos,double *&cursos_cred,int &numdat,
        int &capacidad){
    char ***auxcurso;
    double *auxcred;
    
    capacidad+=INCREMENTO;
    if(cursos==nullptr){
        cursos = new char**[capacidad];
        cursos_cred = new double[capacidad];
        cursos[0] = nullptr;
        cursos_cred[0] = -1;
        numdat = 1;
    }
    else{
        auxcurso = new char**[capacidad];
        auxcred = new double[capacidad];
        for(int i=0;i<numdat;i++){
            auxcurso[i] = cursos[i];
            auxcred[i] = cursos_cred[i];
        }
        delete cursos;
        delete cursos_cred;
        
        cursos = auxcurso;
        cursos_cred = auxcred;
    }
}

void cargarCursosYEscalas (char ***&cursos, double *&cursos_cred,
        double *escalas,const char *nomcur,const char *nomesc){
    ifstream archcursos,archescala;
    
    AperturaDeUnArchivoDeTextosParaLeer(archcursos,nomcur);
    AperturaDeUnArchivoDeTextosParaLeer(archescala,nomesc);
    
    leecursos(cursos,cursos_cred,archcursos);
    leescalas(escalas,archescala);
}
/*
G5,666.90
G1,282.30
G3,454.20
 */
void leescalas(double *escalas, ifstream &archescala){
    char c;
    int posi;
    double valor;
    
    for(int i=0;i<5;i++){
        archescala >> c >> posi >> c >> valor;
        escalas[posi-1] = valor;        
    }
}

void pruebaDeCargaDeCursos(char***cursos, double *cursos_cred,
        const char*nombre){
    ofstream archrep;
    
    AperturaDeUnArchivoDeTextosParaEscribir(archrep,nombre);
    for(int i=0;cursos[i]!=nullptr;i++)    
        imprimecurso(archrep,cursos[i],cursos_cred[i]);
}

void imprimecurso(ofstream &archrep,char **cursos,double cred){
    archrep <<left<< setw(10) << cursos[0] << setw(60) << cursos[1]
            <<right<< setprecision(2) << fixed << setw(10) 
            << cred <<" "<<left<< setw(40) << cursos[2] << endl;
   
}
