/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Funciones_de_cursos_y_alumnos.h
 * Author: cueva.r
 *
 * Created on 5 de septiembre de 2023, 11:37 AM
 */

#include <fstream>

using namespace std;


#ifndef FUNCIONES_DE_CURSOS_Y_ALUMNOS_H
#define FUNCIONES_DE_CURSOS_Y_ALUMNOS_H

char** leecurso(ifstream &,double &);
void leecursos(char ***&,double *&,ifstream &);
void aumentarmemoria(char ***&,double *&,int &,int &);
void cargarCursosYEscalas (char ***&, double *&,double *,const char *,const char *);
void leescalas(double *, ifstream &);
void imprimecurso(ofstream &,char **,double );
void pruebaDeCargaDeCursos(char***, double *,const char*);
#endif /* FUNCIONES_DE_CURSOS_Y_ALUMNOS_H */
