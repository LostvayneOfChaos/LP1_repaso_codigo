/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Axel mendoza 20166141
 *
 * Created on 22 de septiembre de 2023, 08:03 AM
 */

#include "PunterosGenericos.h"
#include "MuestraPunteros.h"
#include <fstream>
#include <iostream>
#include <cstring>
#include <iomanip>
#include <cstdlib>
using namespace std;

/*
 * 
 */


enum registroCliente{DNICLIENTE,NOMBRECLIENTE,
LINEACREDITOCLIENTE,LISTAPEDIDOSCLIENTE};


int main(int argc, char** argv) {
    
    void *productos,*clientes;
    
    cargaproductos(productos);
    imprimeproductos(productos);
    cargaclientes(clientes);
    
    /*void**reg=(void**)clientes;
    void**re;
    
    cout<<"nuevo"<<endl;
    cout<<"-------------"<<endl;
    for (int i = 0; reg[i]; i++) {
        
        re=(void**)reg[i];
        
        cout<<*(int*)re[DNICLIENTE]<<endl;
        cout<<*(double*)re[LINEACREDITOCLIENTE]<<endl;
        cout<<(char*)re[NOMBRECLIENTE]<<endl;
        //cout<< *(int*)re[LISTAPEDIDOSCLIENTE]<<endl;
        
        
    }
    */
    imprimirClientesv2(clientes);
    //imprimeclientes(clientes);
    cargapedidos(productos,clientes);
    imprimerep(clientes);
    
    //ordenarPedidosXCliente(clientes);
    //imprimerepfinal(clientes);
   
    
    return 0;
}

